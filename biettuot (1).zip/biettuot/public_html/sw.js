var V='bt-v4',PRE=['/assets/style.css','/assets/app.js','/assets/icon-192.png','/offline'];
self.addEventListener('install',function(e){e.waitUntil(caches.open(V).then(function(c){return c.addAll(PRE);}).then(function(){return self.skipWaiting();}));});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(x){return x!==V;}).map(function(x){return caches.delete(x);}));}).then(function(){return self.clients.claim();}));});
self.addEventListener('fetch',function(e){
  var r=e.request;if(r.method!=='GET')return;var u=new URL(r.url);if(u.origin!==location.origin)return;
  if(u.pathname.indexOf('/assets/')===0){e.respondWith(caches.match(r).then(function(h){
    var n=fetch(r).then(function(res){var cp=res.clone();caches.open(V).then(function(c){c.put(r,cp);});return res;}).catch(function(){return h;});return h||n;}));return;}
  if(r.mode==='navigate'){e.respondWith(fetch(r).catch(function(){return caches.match('/offline');}));}
});
self.addEventListener('push',function(e){
  e.waitUntil(fetch('/api/thong-bao-moi',{credentials:'include'}).then(function(r){return r.json();}).catch(function(){return {title:'Biết Tuốt',body:'Bạn có thông báo mới',url:'/thong-bao'};})
    .then(function(d){return self.registration.showNotification(d.title||'Biết Tuốt',{body:d.body,icon:'/assets/icon-192.png',badge:'/assets/icon-192.png',data:{url:d.url||'/thong-bao'}});}));
});
self.addEventListener('notificationclick',function(e){e.notification.close();e.waitUntil(clients.openWindow((e.notification.data&&e.notification.data.url)||'/thong-bao'));});
