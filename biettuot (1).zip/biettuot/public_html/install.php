<?php
// Trình cài đặt / nâng cấp CSDL - an toàn chạy nhiều lần. Cần "setup_key" (hoặc "cron_key") trong app/config.local.php.
// SAU KHI HOÀN TẤT: hãy xóa file này hoặc xóa setup_key khỏi config.
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8'); header('Cache-Control: no-store'); header('X-Robots-Tag: noindex');
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$cfgFile = __DIR__.'/app/config.local.php';
echo '<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cài đặt CSDL - Biết Tuốt</title>
<body style="font-family:system-ui,sans-serif;max-width:760px;margin:30px auto;padding:0 16px;line-height:1.6"><h1>🛠 Cài đặt / nâng cấp cơ sở dữ liệu</h1>';
if (!is_file($cfgFile)) { echo '<p style="color:#b91c1c">Thiếu <code>app/config.local.php</code>. Hãy sao chép <code>config.sample.php</code> thành <code>config.local.php</code> và điền thông tin DB.</p>'; exit; }
$CFG = require $cfgFile; $key = (string)($CFG['setup_key'] ?? ($CFG['cron_key'] ?? ''));
if ($key === '') { echo '<p>Hãy thêm vào <code>app/config.local.php</code> dòng: <code>\'setup_key\' =&gt; \'mot-chuoi-ngau-nhien-dai\',</code> rồi tải lại trang này.</p>'; exit; }
$given = (string)($_POST['key'] ?? $_GET['key'] ?? '');
if (!hash_equals($key, $given) || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
  echo '<p>Nhập khóa cài đặt (giá trị <code>setup_key</code> trong config) rồi bấm chạy. Có thể bấm nhiều lần, không làm mất dữ liệu.</p>';
  if ($given !== '' && !hash_equals($key, $given)) echo '<p style="color:#b91c1c">Khóa không đúng.</p>';
  echo '<form method="post"><input type="password" name="key" style="padding:8px;width:100%;max-width:360px" placeholder="setup_key" required> <button style="padding:9px 16px">Chạy cài đặt</button></form>'; exit;
}
require __DIR__.'/app/schema.php';
try { $c = $CFG['db']; $pdo = new PDO("mysql:host={$c['host']};dbname={$c['name']};charset=utf8mb4", $c['user'], $c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]); }
catch (Throwable $e) { echo '<p style="color:#b91c1c">Không kết nối được CSDL: '.$h($e->getMessage()).'<br>Kiểm tra mục <code>db</code> trong config.local.php.</p>'; exit; }
@set_time_limit(120); $log = schema_sync($pdo); $fail = count(array_filter($log, fn($l) => str_starts_with($l, '✘')));
echo '<p><b>'.($fail ? "Hoàn tất nhưng có $fail lỗi - xem các dòng ✘ bên dưới và gửi cho người hỗ trợ." : 'Hoàn tất, không có lỗi.').'</b></p><pre style="background:#f4f4f8;padding:12px;border-radius:10px;white-space:pre-wrap;font-size:.85rem">'.$h(implode("\n", $log)).'</pre>';
echo '<p>Tiếp theo: <a href="/">Trang chủ</a> · <a href="/admin">Quản trị</a>. <b>Hãy xóa file <code>install.php</code> khỏi máy chủ</b> (hoặc xóa setup_key) khi đã xong.</p>';
