<?php
define('ROOT', __DIR__);
require ROOT.'/app/core.php';
require ROOT.'/app/util.php';
require ROOT.'/app/schema.php';
require ROOT.'/app/features.php';
require ROOT.'/app/ai.php';
require ROOT.'/app/points.php';
require ROOT.'/app/jobs.php';
require ROOT.'/app/social.php';
require ROOT.'/app/pay.php';
require ROOT.'/app/content2.php';
require ROOT.'/app/totp.php';
require ROOT.'/app/og.php';
require ROOT.'/app/newsletter.php';
require ROOT.'/app/health.php';
if (page_cacheable()) { $cf = cache_file(); if (is_file($cf) && time() - filemtime($cf) < 120) { readfile($cf); exit; } }
// Chạy tác vụ nền sau khi đã trả trang cho người dùng (nếu máy chủ hỗ trợ); nếu không, cron/polling sẽ xử lý.
register_shutdown_function(function () {
  if (function_exists('fastcgi_finish_request')) fastcgi_finish_request(); elseif (function_exists('litespeed_finish_request')) litespeed_finish_request(); else return;
  ignore_user_abort(true); set_time_limit(60);
  try { if (mt_rand(1, 3) === 1) jobs_run(2); } catch (Throwable $e) {}
});
require ROOT.'/app/routes.php';
