(function(){
  var $=function(s){return document.querySelector(s);},esc=function(x){return String(x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});};
  // Gợi ý câu hỏi tương tự khi gõ tiêu đề
  var t=$('#title'),s=$('#sim'),h;
  if(t&&s)t.addEventListener('input',function(){clearTimeout(h);h=setTimeout(function(){
    var v=t.value.trim();if(v.length<8){s.innerHTML='';return;}
    fetch('/api/tuong-tu?q='+encodeURIComponent(v)).then(function(r){return r.json();}).then(function(d){
      s.innerHTML=d.length?'<b>Câu hỏi tương tự (có thể đã có câu trả lời):</b><ul>'+d.map(function(x){return '<li><a target="_blank" href="'+esc(x.u)+'">'+esc(x.t)+'</a></li>';}).join('')+'</ul>':'';
    }).catch(function(){});},400);});
  var f=$('#askf');
  if(f)f.addEventListener('submit',function(){var b=f.querySelector('button.btn');if(b){b.disabled=true;b.textContent='Đang gửi…';}});
  // Xác nhận trước khi gửi form nguy hiểm
  document.querySelectorAll('form[data-confirm]').forEach(function(fm){fm.addEventListener('submit',function(e){if(!confirm(fm.dataset.confirm))e.preventDefault();});});
  // Chờ AI trả lời (hàng đợi): hỏi trạng thái mỗi 3 giây
  var w=$('#aiwait');
  if(w){var n=0,poll=function(){fetch('/api/ai-trang-thai?id='+w.dataset.qid).then(function(r){return r.json();}).then(function(d){
    if(d.done){location.reload();return;}
    if(d.failed||++n>25){w.textContent='AI đang bận hoặc hết hạn mức. Hãy bấm "Nhờ AI trả lời" lại sau ít phút.';return;}
    setTimeout(poll,3000);}).catch(function(){setTimeout(poll,5000);});};poll();}
  // Đóng menu thả xuống khi bấm ra ngoài
  document.addEventListener('click',function(e){document.querySelectorAll('details.dd[open]').forEach(function(d){if(!d.contains(e.target))d.open=false;});});
  // Chia sẻ: sao chép liên kết / chia sẻ gốc của thiết bị
  document.querySelectorAll('.share [data-copy]').forEach(function(b){b.addEventListener('click',function(){try{navigator.clipboard.writeText(b.dataset.copy);b.textContent='✔ Đã chép';}catch(e){}});});
  if(navigator.share)document.querySelectorAll('.share [data-share]').forEach(function(b){b.hidden=false;b.addEventListener('click',function(){navigator.share({title:b.dataset.title,url:b.dataset.share}).catch(function(){});});});
  // Nút có xác nhận (data-confirm-btn)
  document.querySelectorAll('button[data-confirm-btn]').forEach(function(b){b.addEventListener('click',function(e){if(!confirm(b.dataset.confirmBtn))e.preventDefault();});});
  // PWA: service worker (chỉ khi tính năng PWA bật), nút cài đặt, thông báo đẩy
  if('serviceWorker' in navigator){if(document.body.dataset.pwa==='1')navigator.serviceWorker.register('/sw.js').catch(function(){});else navigator.serviceWorker.getRegistrations().then(function(rs){rs.forEach(function(r){r.unregister();});}).catch(function(){});}
  var dp,ib=$('#install');
  window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();dp=e;if(ib)ib.hidden=false;});
  if(ib)ib.addEventListener('click',function(){if(dp){dp.prompt();dp=null;ib.hidden=true;}});
  var pb=$('#pushbtn');
  if(pb&&'serviceWorker' in navigator&&'PushManager' in window){
    pb.hidden=false;
    pb.addEventListener('click',async function(){
      try{var k=(await (await fetch('/push/khoa')).json()).key;if(!k){alert('Quản trị viên chưa bật thông báo đẩy.');return;}
        if(await Notification.requestPermission()!=='granted')return;
        var raw=atob(k.replace(/-/g,'+').replace(/_/g,'/')),key=new Uint8Array(raw.length);for(var i=0;i<raw.length;i++)key[i]=raw.charCodeAt(i);
        var reg=await navigator.serviceWorker.ready,sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:key}),fd=new FormData();
        fd.append('endpoint',sub.endpoint);fd.append('_csrf',pb.dataset.csrf);await fetch('/push/dang-ky',{method:'POST',body:fd});pb.textContent='✔ Đã bật thông báo đẩy';pb.disabled=true;
      }catch(e){alert('Không thể bật thông báo đẩy trên thiết bị này.');}
    });
  }
})();
