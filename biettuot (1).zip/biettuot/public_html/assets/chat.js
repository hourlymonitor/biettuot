(function(){
  var root=document.getElementById('chat');if(!root)return;
  var $=function(s){return root.querySelector(s);},msgsEl=$('#msgs'),welcome=$('#welcome'),input=$('#cin'),form=$('#cform'),sendBtn=$('#csend'),hist=$('#hist'),hlist=$('#hlist'),fieldSel=$('#cfield'),KEY='bt_chats',PREF='bt_pref';
  var SYNC=root.dataset.sync==='1',CSRF=root.dataset.csrf||'',SHARE=root.dataset.share==='1';
  var state={mode:'smart',field:'chung',id:null,thread:null,msgs:[],busy:false,image:null},TS=root.dataset.ts||'';
  function esc(x){return String(x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function md(t){var h=esc(t).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>'),out='',list=false;
    h.split(/\n/).forEach(function(l){var m=l.match(/^\s*[-*\u2022]\s+(.*)$/);if(m){if(!list){out+='<ul>';list=true;}out+='<li>'+m[1]+'</li>';return;}if(list){out+='</ul>';list=false;}if(l.trim())out+='<p>'+l.replace(/^#+\s*/,'')+'</p>';});
    return out+(list?'</ul>':'');}
  function loadLocal(){try{return JSON.parse(localStorage.getItem(KEY)||'[]');}catch(e){return [];}}
  function saveLocal(l){try{localStorage.setItem(KEY,JSON.stringify(l.slice(0,30)));}catch(e){}}
  function savePref(){try{localStorage.setItem(PREF,JSON.stringify({mode:state.mode,field:state.field}));}catch(e){}}
  function persistLocal(){if(SYNC||!state.msgs.length)return;var l=loadLocal().filter(function(c){return c.id!==state.id;});l.unshift({id:state.id,title:state.msgs[0].content.slice(0,60),ts:Date.now(),msgs:state.msgs,mode:state.mode,field:state.field});saveLocal(l);renderHist();}
  function post(path,data){var fd=new FormData();for(var k in data)fd.append(k,data[k]);fd.append('_csrf',CSRF);return fetch(path,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json();});}
  async function renderHist(){
    if(SYNC){
      try{var d=await (await fetch('/api/chat/threads',{credentials:'same-origin'})).json(),l=d.threads||[];
        hlist.innerHTML=l.length?l.map(function(t){return '<div class="hitem" data-id="'+t.id+'"><button type="button" class="hopen">'+esc(t.title)+'</button>'+(SHARE?'<button type="button" class="hshare" title="'+(t.shared?'Đang chia sẻ - bấm để tắt':'Tạo liên kết chia sẻ')+'">'+(t.shared?'🔗':'↗')+'</button>':'')+'<button type="button" class="hdel" aria-label="Xóa">\u2715</button></div>';}).join(''):'<p class="muted">Chưa có cuộc trò chuyện nào.</p>';
      }catch(e){hlist.innerHTML='<p class="muted">Không tải được lịch sử.</p>';}
      return;}
    var l2=loadLocal();hlist.innerHTML=l2.length?l2.map(function(c){return '<div class="hitem" data-id="'+esc(c.id)+'"><button type="button" class="hopen">'+esc(c.title)+'</button><button type="button" class="hdel" aria-label="Xóa">\u2715</button></div>';}).join(''):'<p class="muted">Chưa có cuộc trò chuyện nào.</p>';}
  var attach=$('#cattach'),fileIn=$('#cimg'),prev=$('#cprev');
  function clearImg(){state.image=null;if(prev){prev.hidden=true;prev.innerHTML='';}if(fileIn)fileIn.value='';}
  function resizeImg(file){return new Promise(function(ok,fail){var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var k=Math.min(1,1280/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);ok(c.toDataURL('image/jpeg',0.8));};im.onerror=function(){fail(new Error('Không đọc được ảnh.'));};im.src=r.result;};r.onerror=function(){fail(new Error('Không đọc được ảnh.'));};r.readAsDataURL(file);});}
  if(attach){attach.onclick=function(){fileIn.click();};fileIn.onchange=async function(){var f=fileIn.files[0];if(!f)return;try{var d=await resizeImg(f);if(d.length>2800000){alert('Ảnh quá lớn, hãy chọn ảnh nhỏ hơn.');return;}state.image=d;prev.hidden=false;prev.innerHTML='<img src="'+d+'" alt="ảnh đính kèm"><button type="button" class="link" id="cprevx">✕ Bỏ ảnh</button>';$('#cprevx').onclick=clearImg;}catch(e){alert(e.message);}};}
  function setMode(m){state.mode=m;root.querySelectorAll('.mode').forEach(function(b){b.classList.toggle('on',b.dataset.mode===m);});savePref();}
  function scroll(){msgsEl.scrollTop=msgsEl.scrollHeight;}
  function bubble(role,content,html){var d=document.createElement('div');d.className='msg '+role;d.innerHTML=(role==='assistant'?'<div class="av">🤖</div>':'')+'<div class="bub">'+(html||(role==='assistant'?md(content):'<p>'+esc(content).replace(/\n/g,'<br>')+'</p>'))+'</div>';msgsEl.appendChild(d);scroll();return d;}
  function addAnswer(text,related,note,q,sources){
    var extra='<div class="bub-actions"><button type="button" class="cp">📋 Sao chép</button><a href="/hoi-moi?title='+encodeURIComponent((q||'').slice(0,200))+'">💬 Hỏi cộng đồng</a></div>';
    if(sources&&sources.length)extra+='<div class="srcs"><b>📚 Nguồn tham khảo trên Biết Tuốt:</b>'+sources.map(function(r,i){return '<a href="'+esc(r.u)+'">'+esc(r.t)+'</a>';}).join('')+'</div>';
    if(related&&related.length)extra+='<div class="rel"><b>Có thể liên quan:</b>'+related.map(function(r){return '<a href="'+esc(r.u)+'">'+esc(r.t)+'</a>';}).join('')+'</div>';
    if(note)extra+='<div class="note">'+esc(note)+'</div>';
    var d=bubble('assistant',text,md(text)+extra);d.querySelector('.cp').onclick=function(){try{navigator.clipboard.writeText(text);this.textContent='✔ Đã chép';}catch(e){}};}
  function reset(){state.id=null;state.thread=null;state.msgs=[];msgsEl.querySelectorAll('.msg').forEach(function(n){n.remove();});welcome.hidden=false;}
  function showChat(c){reset();state.id=c.id;state.thread=c.thread||null;state.msgs=c.msgs.slice();welcome.hidden=true;setMode(c.mode||'smart');state.field=c.field||'chung';fieldSel.value=state.field;
    var lastUser='';c.msgs.forEach(function(m){if(m.role==='user'){lastUser=m.content;bubble('user',m.content);}else addAnswer(m.content,null,null,lastUser);});hist.hidden=true;}
  async function ask(){
    var fd=new FormData();fd.append('messages',JSON.stringify(state.msgs.slice(-10)));fd.append('mode',state.mode);fd.append('field',state.field);fd.append('_csrf',CSRF);if(state.thread)fd.append('thread',state.thread);if(state.image)fd.append('image',state.image);var data;
    try{var res=await fetch('/api/chat',{method:'POST',body:fd,credentials:'same-origin'});data=await res.json();}catch(e){data={error:'net',message:'Không kết nối được máy chủ.'};}
    if(data.reply)return data;
    if(data.error==='verify'){var g=document.getElementById('tsgate');if(g){g.hidden=false;form.hidden=true;}}
    throw new Error(data.message||'Có lỗi xảy ra.');}
  async function send(text){
    text=(text||'').trim();if(state.busy||!text)return;state.busy=true;sendBtn.disabled=true;welcome.hidden=true;if(!state.id)state.id='c'+Date.now();
    state.msgs.push({role:'user',content:text});bubble('user',(state.image?'📷 [ảnh] ':'')+text);input.value='';autosize();
    var typing=bubble('assistant','','<span class="dots"><i></i><i></i><i></i></span>');
    try{var r=await ask();clearImg();typing.remove();addAnswer(r.reply,r.related,r.note,text,r.sources);state.msgs.push({role:'assistant',content:r.reply});if(r.thread)state.thread=r.thread;persistLocal();if(SYNC)renderHist();}
    catch(e){typing.remove();state.msgs.pop();bubble('assistant',e.message||'Có lỗi xảy ra, hãy thử lại.').classList.add('err');}
    state.busy=false;sendBtn.disabled=false;input.focus();}
  function autosize(){input.style.height='auto';input.style.height=Math.min(input.scrollHeight,140)+'px';}
  input.addEventListener('input',autosize);
  input.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();send(input.value);}});
  form.addEventListener('submit',function(e){e.preventDefault();send(input.value);});
  root.querySelectorAll('.mode').forEach(function(b){b.onclick=function(){setMode(b.dataset.mode);};});
  fieldSel.onchange=function(){state.field=fieldSel.value;savePref();};
  root.querySelectorAll('.sug').forEach(function(b){b.onclick=function(){send(b.textContent);};});
  $('#cnew').onclick=function(){reset();hist.hidden=true;input.focus();};
  $('#chist').onclick=function(){hist.hidden=!hist.hidden;renderHist();};
  $('#hclear').onclick=async function(){if(!confirm('Xóa toàn bộ lịch sử trò chuyện?'))return;if(SYNC){await post('/api/chat/delete',{all:1});reset();}else saveLocal([]);renderHist();};
  hlist.addEventListener('click',async function(e){var it=e.target.closest('.hitem');if(!it)return;var id=it.dataset.id,c=e.target.classList;
    if(c.contains('hdel')){if(SYNC){await post('/api/chat/delete',{id:id});if(String(state.thread)===String(id))reset();}else saveLocal(loadLocal().filter(function(x){return x.id!==id;}));renderHist();}
    else if(c.contains('hshare')){var d=await post('/api/chat/share',{id:id});if(d.url){try{navigator.clipboard.writeText(d.url);}catch(x){}prompt('Liên kết chia sẻ (đã chép; ai có liên kết đều xem được):',d.url);}else alert('Đã tắt chia sẻ cuộc trò chuyện này.');renderHist();}
    else if(c.contains('hopen')){if(SYNC){try{var t=await (await fetch('/api/chat/thread?id='+encodeURIComponent(id),{credentials:'same-origin'})).json();if(t.messages)showChat({id:'t'+id,thread:parseInt(id,10),msgs:t.messages,mode:t.mode,field:t.field});}catch(x){}}
      else{var f=loadLocal().filter(function(x){return x.id===id;})[0];if(f)showChat(f);}}});
  try{var p=JSON.parse(localStorage.getItem(PREF)||'{}');if(p.mode)setMode(p.mode);if(p.field){state.field=p.field;fieldSel.value=p.field;}}catch(e){}
  if(root.dataset.login!=='1'&&state.mode==='deep')setMode('smart');
  if(TS){form.hidden=true;}
  window.btTs=function(tok){post('/api/chat/verify',{'cf-turnstile-response':tok}).then(function(d){if(d.ok){var g=document.getElementById('tsgate');if(g)g.hidden=true;form.hidden=false;input.focus();}});};
  renderHist();
  if(root.dataset.q)send(root.dataset.q);else input.focus();
})();
