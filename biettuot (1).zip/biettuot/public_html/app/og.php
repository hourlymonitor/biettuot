<?php
// Ảnh xem trước khi chia sẻ (Open Graph 1200x630) tạo bằng GD + phông DejaVu (hỗ trợ tiếng Việt).
function og_available(): bool { return function_exists('imagecreatetruecolor') && function_exists('imagettftext') && function_exists('imagettfbbox') && is_file(ROOT.'/assets/fonts/DejaVuSans-Bold.ttf'); }
function og_wrap(string $text, string $font, float $size, int $maxw, int $maxLines): array {
  $words = preg_split('/\s+/u', trim($text), -1, PREG_SPLIT_NO_EMPTY) ?: []; $lines = []; $cur = ''; $i = 0; $n = count($words);
  for (; $i < $n; $i++) {
    $try = $cur === '' ? $words[$i] : $cur.' '.$words[$i]; $bb = imagettfbbox($size, 0, $font, $try);
    if ($cur === '' || ($bb[2] - $bb[0]) <= $maxw) { $cur = $try; continue; }
    $lines[] = $cur; $cur = $words[$i]; if (count($lines) >= $maxLines) break;
  }
  if (count($lines) < $maxLines && $cur !== '') { $lines[] = $cur; $i = $n; }
  if ($i < $n || count($lines) > $maxLines) {   // còn chữ chưa vẽ: cắt và thêm …
    $lines = array_slice($lines, 0, $maxLines); $last = rtrim((string)end($lines), " .,;:!?");
    while ($last !== '') { $bb = imagettfbbox($size, 0, $font, $last.'…'); if (($bb[2] - $bb[0]) <= $maxw) break; $last = mb_substr($last, 0, -1); }
    $lines[count($lines) - 1] = $last.'…';
  }
  return $lines;
}
// Trả về dữ liệu PNG hoặc null nếu không tạo được
function og_png(string $title, string $sub = '', string $tag = ''): ?string {
  if (!og_available()) return null;
  $W = 1200; $H = 630; $fb = ROOT.'/assets/fonts/DejaVuSans-Bold.ttf'; $fr = ROOT.'/assets/fonts/DejaVuSans.ttf';
  $im = imagecreatetruecolor($W, $H); if (!$im) return null;
  $c1 = [124, 58, 237]; $c2 = [236, 72, 153];
  for ($y = 0; $y < $H; $y++) { $t = $y / $H; $col = imagecolorallocate($im, (int)($c1[0] + ($c2[0] - $c1[0]) * $t), (int)($c1[1] + ($c2[1] - $c1[1]) * $t), (int)($c1[2] + ($c2[2] - $c1[2]) * $t)); imageline($im, 0, $y, $W, $y, $col); }
  $white = imagecolorallocate($im, 255, 255, 255); $soft = imagecolorallocatealpha($im, 255, 255, 255, 40); $card = imagecolorallocatealpha($im, 20, 10, 50, 85);
  imagealphablending($im, true); imagefilledrectangle($im, 50, 190, $W - 50, 520, $card);
  imagefilledrectangle($im, 60, 56, 140, 136, $white); $pur = imagecolorallocate($im, 124, 58, 237); imagettftext($im, 54, 0, 78, 118, $pur, $fb, 'B');
  imagettftext($im, 36, 0, 165, 112, $white, $fb, 'Biết Tuốt');
  if ($tag !== '') { $bb = imagettfbbox(24, 0, $fr, $tag); $w = $bb[2] - $bb[0]; imagefilledrectangle($im, $W - 60 - $w - 40, 66, $W - 60, 126, $soft); imagettftext($im, 24, 0, $W - 60 - $w - 20, 106, $white, $fr, $tag); }
  $lines = og_wrap($title, $fb, 50, $W - 160, 4); $y = 270; foreach ($lines as $l) { imagettftext($im, 50, 0, 80, $y, $white, $fb, $l); $y += 66; }
  if ($sub !== '') imagettftext($im, 26, 0, 80, 580, $soft, $fr, mb_substr($sub, 0, 70));
  $host = (string)parse_url((string)cfg('base_url'), PHP_URL_HOST); $bb = imagettfbbox(26, 0, $fr, $host); imagettftext($im, 26, 0, $W - 60 - ($bb[2] - $bb[0]), 580, $white, $fr, $host);
  ob_start(); imagepng($im, null, 6); $png = (string)ob_get_clean(); imagedestroy($im);
  return $png !== '' ? $png : null;
}
