<p class="crumb"><a href="/">Trang chủ</a> › <a href="/c/<?=e($r['cslug'])?>"><?=e($r['cat'])?></a></p>
<h1><?=e($r['title'])?></h1>
<div class="meta">Hỏi bởi <b><a href="/u/<?=e($r['username'])?>"><?=e($r['username'])?></a></b> <?=tier_badge($r)?> · <?=e(ago($r['created_at']))?> · <?=(int)$r['views']?> lượt xem<?=$r['edited_at'] ? ' · đã chỉnh sửa' : ''?></div>
<?php if ($isQotd): ?><div class="flash ok">📌 Đây là câu hỏi của ngày - trả lời để nhận thêm điểm!</div><?php endif; ?>
<?php if ($r['status'] !== 'published'): ?><div class="flash info">Câu hỏi này đang chờ duyệt hoặc đã bị ẩn.</div><?php endif; ?>
<?php if (!empty($r['csens'])): ?><div class="flash info">⚠️ Lĩnh vực nhạy cảm (sức khỏe, pháp luật, tài chính, tâm lý): thông tin chỉ mang tính tham khảo, không thay thế tư vấn của chuyên gia.</div><?php endif; ?>
<?php if ($tags): ?><nav class="chips tags"><?php foreach ($tags as $t): ?><a href="/the/<?=e($t['slug'])?>">#<?=e($t['name'])?></a><?php endforeach; ?></nav><?php endif; ?>
<?php if ($r['body'] !== ''): ?><div class="body"><?=md_lite($r['body'])?></div><?php endif; ?>
<div class="acts"><?=follow_button('question', (int)$r['id'], 'Theo dõi')?>
<?php if (can_edit($r)): ?><a class="btn sm ghost" href="/sua/cau-hoi/<?=(int)$r['id']?>">✏️ Sửa</a>
<form method="post" action="/xoa/cau-hoi" class="inline" data-confirm="Xóa câu hỏi này?"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><button class="btn sm ghost">🗑 Xóa</button></form><?php endif; ?>
<?php if (me()): ?><details class="rep"><summary>Báo cáo</summary><?=report_form('question', (int)$r['id'])?></details><?php endif; ?></div>

<?=$r['status'] === 'published' ? share_buttons(qurl($r), $r['title']) : ''?>
<?php if (!empty($r['ai_summary'])): ?><section class="card sum"><b>🤖 Tóm tắt từ các câu trả lời</b><?=md_lite($r['ai_summary'])?><small class="muted">Do AI tổng hợp, chỉ mang tính tham khảo.</small></section><?php endif; ?>
<?php if ($jobPending && $noAi): ?><div class="flash info">🤖 Hệ thống chưa bật AI trả lời tự động. Bạn vẫn có thể <a href="/tro-ly?q=<?=e(urlencode($r['title']))?>">hỏi Trợ lý AI miễn phí</a> hoặc chờ cộng đồng trả lời.</div>
<?php elseif ($jobPending): ?><div id="aiwait" class="flash info" data-qid="<?=(int)$r['id']?>">🤖 AI đang soạn câu trả lời… <span class="spin"></span></div><?php endif; ?>

<h2><?=count($answers)?> câu trả lời</h2>
<?php foreach ($answers as $i => $a): $mv = (int)($myvotes[$a['id']] ?? 0); ?>
<article class="ans<?=$a['is_best'] ? ' best' : ''?>" id="a<?=(int)$a['id']?>">
  <?php if ($canVote): ?><form method="post" action="/vote" class="vote"><?=csrf_field()?><input type="hidden" name="answer_id" value="<?=(int)$a['id']?>">
    <button name="value" value="1" class="<?=$mv > 0 ? 'on' : ''?>" title="Hữu ích" aria-label="Hữu ích">▲</button><b><?=(int)$a['score']?></b>
    <button name="value" value="-1" class="<?=$mv < 0 ? 'on' : ''?>" title="Chưa chính xác" aria-label="Chưa chính xác">▼</button></form><?php else: ?><div class="vote"><b><?=(int)$a['score']?></b></div><?php endif; ?>
  <div class="ac">
    <div class="who"><?php if ($a['is_ai']): ?><span class="badge ai">🤖 Do AI trả lời · chỉ mang tính tham khảo</span><?php else: ?><b><a href="/u/<?=e($a['username'])?>"><?=e($a['username'])?></a></b> <?=tier_badge($a)?><?php endif; ?>
      <?php if ($a['is_best']): ?><span class="badge ok">✔ Tốt nhất</span><?php endif; ?> · <?=e(ago($a['created_at']))?><?=$a['edited_at'] ? ' · đã sửa' : ''?></div>
    <?=md_lite($a['body'])?>
    <div class="acts">
      <?php if ($own && !$a['is_best']): ?><form method="post" action="/chon-tot-nhat" class="inline"><?=csrf_field()?><input type="hidden" name="answer_id" value="<?=(int)$a['id']?>"><button class="btn sm">Chọn là tốt nhất</button></form><?php endif; ?>
      <?php if (can_edit($a)): ?><a class="btn sm ghost" href="/sua/tra-loi/<?=(int)$a['id']?>">✏️ Sửa</a>
      <form method="post" action="/xoa/tra-loi" class="inline" data-confirm="Xóa câu trả lời này?"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$a['id']?>"><button class="btn sm ghost">🗑</button></form><?php endif; ?>
      <?php if (me()): ?><details class="rep"><summary>Báo cáo</summary><?=report_form('answer', (int)$a['id'])?></details><?php endif; ?>
    </div>
    <div class="cmts"><?php foreach ($comments[$a['id']] ?? [] as $c): ?><div class="cmt"><b><a href="/u/<?=e($c['username'])?>"><?=e($c['username'])?></a></b> <?=e($c['body'])?> <span class="muted"><?=e(ago($c['created_at']))?></span>
      <?php if (me() && ((int)me()['id'] === (int)$c['user_id'] || $isMod)): ?><form method="post" action="/binh-luan/xoa" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$c['id']?>"><button class="link" title="Xóa">✕</button></form><?php endif; ?></div><?php endforeach; ?>
      <?php if (me() && $canComment && $r['status'] === 'published'): ?><form method="post" action="/binh-luan" class="inline wide"><?=csrf_field()?><input type="hidden" name="answer_id" value="<?=(int)$a['id']?>"><input type="text" name="hp_note" class="hp" tabindex="-1" autocomplete="off"><input name="body" maxlength="500" placeholder="Viết bình luận…" required><button class="btn sm ghost">Gửi</button></form><?php endif; ?></div>
  </div></article>
<?php if ($i === 0): ?><?=ad_slot('inline')?><?=affiliate_box((int)$r['category_id'])?><?php endif; ?>
<?php endforeach; ?>
<?php if (!$hasAi && !$jobPending && !$noAi && $r['status'] === 'published' && me()): ?>
<form method="post" action="/ai-tra-loi"><?=csrf_field()?><input type="hidden" name="question_id" value="<?=(int)$r['id']?>"><button class="btn">🤖 Nhờ AI trả lời câu hỏi này</button></form><?php endif; ?>

<?php if ($r['status'] === 'published'): ?><h2>Câu trả lời của bạn</h2>
<?php if (me()): ?>
<form method="post" action="/tra-loi" class="form"><?=csrf_field()?><input type="hidden" name="question_id" value="<?=(int)$r['id']?>">
  <input type="text" name="hp_note" class="hp" tabindex="-1" autocomplete="off">
  <textarea name="body" rows="5" maxlength="5000" required placeholder="Chia sẻ hiểu biết của bạn…"></textarea><button class="btn">Đăng câu trả lời</button></form>
<?php else: ?><p><a href="/dang-nhap">Đăng nhập</a> hoặc <a href="/dang-ky">đăng ký</a> để trả lời, bình luận và bình chọn.</p><?php endif; endif; ?>

<?php if ($related): ?><h2>Có thể bạn cũng muốn biết</h2><?php foreach ($related as $x): ?><article class="card"><a class="qt" href="<?=e(qurl($x))?>"><?=e($x['title'])?></a><div class="meta"><?=(int)$x['answers_count']?> trả lời</div></article><?php endforeach; endif; ?>

<?php if ($isMod): ?><details class="card"><summary><b>🛠 Công cụ kiểm duyệt</b></summary>
  <p class="muted">Gộp câu hỏi này vào một câu hỏi tương tự (chuyển câu trả lời sang câu hỏi đích):</p>
  <?php foreach ($related as $x): ?><form method="post" action="/admin/gop" class="inline wide" data-confirm="Gộp câu hỏi này vào câu hỏi được chọn?"><?=csrf_field()?><input type="hidden" name="source" value="<?=(int)$r['id']?>"><input type="hidden" name="target" value="<?=(int)$x['id']?>"><span><?=e($x['title'])?></span><button class="btn sm">Gộp vào đây</button></form><?php endforeach; ?>
  <?php if ($edits): ?><p class="muted">Lịch sử chỉnh sửa:</p><?php foreach ($edits as $ed): ?><div class="cmt"><b><?=e($ed['old_title'] ?? '')?></b> <?=e(mb_substr($ed['old_body'], 0, 200))?> <span class="muted"><?=e(ago($ed['created_at']))?></span></div><?php endforeach; endif; ?></details><?php endif; ?>
