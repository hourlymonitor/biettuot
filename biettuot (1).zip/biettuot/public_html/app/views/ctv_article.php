<h1><?=$art ? 'Sửa bài viết' : 'Viết bài mới'?></h1>
<?php if (!$cats): ?><div class="flash err">Bạn chưa được phân công lĩnh vực nào để viết bài. Hãy liên hệ quản trị viên.</div><?php endif; ?>
<form method="post" class="form"><?=csrf_field()?>
<label>Lĩnh vực<select name="category_id" required><option value="">- Chọn lĩnh vực -</option><?php foreach ($cats as $c): ?><option value="<?=(int)$c['id']?>" <?=($art && (int)$art['category_id'] === (int)$c['id']) ? 'selected' : ''?>><?=e($c['icon'].' '.$c['name'])?></option><?php endforeach; ?></select></label>
<label>Tiêu đề (tối thiểu 10 ký tự)<input name="title" maxlength="200" required value="<?=e($art['title'] ?? '')?>"></label>
<label>Nội dung (tối thiểu 100 ký tự)<textarea name="body" rows="18" required><?=e($art['body'] ?? '')?></textarea></label>
<p class="muted">Định dạng: <code>## Tiêu đề mục</code>, <code>### Tiểu mục</code>, <code>**đậm**</code>, gạch đầu dòng bắt đầu bằng <code>- </code>. Không chép nguyên văn nội dung có bản quyền; ghi rõ nguồn khi trích dẫn. Lĩnh vực sức khỏe/pháp luật/tài chính: chỉ viết thông tin tổng quát, không chẩn đoán hay tư vấn cá nhân.</p>
<div class="acts"><button class="btn ghost" name="act" value="save">💾 Lưu<?=$art && $art['status'] === 'published' ? ' thay đổi' : ' nháp'?></button><button class="btn" name="act" value="publish"><?=$direct ? '🚀 Đăng bài' : '📨 Gửi duyệt'?></button><a class="btn ghost" href="/ctv">Hủy</a></div></form>
<?php if (!empty($edits)): ?><h2>Lịch sử chỉnh sửa</h2><?php foreach ($edits as $ed): ?><div class="cmt"><b><?=e($ed['username'] ?? '')?></b> · <?=e(ago($ed['created_at']))?> · bản cũ: <?=e(mb_substr((string)$ed['old_title'], 0, 80))?></div><?php endforeach; endif; ?>
