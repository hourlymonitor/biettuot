<?php $t = tier_of((int)$p['xp']); $defs = badge_defs(); ?>
<div class="prof"><div class="avatar"><?=e(mb_strtoupper(mb_substr($p['username'], 0, 1)))?></div>
<div><h1><?=e($p['username'])?> <?=tier_badge($p)?></h1><div class="meta">Tham gia <?=e(date('m/Y', strtotime($p['created_at'])))?> · <?=(int)$followers?> người theo dõi · Chuỗi <?=(int)$p['streak']?> ngày</div>
<?=follow_button('user', (int)$p['id'], 'Theo dõi')?><?php if (me() && (int)me()['id'] === (int)$p['id']): ?><a class="btn sm ghost" href="/cai-dat">Chỉnh sửa hồ sơ</a><?php endif; ?></div></div>
<?php if ($p['bio'] !== ''): ?><p><?=e($p['bio'])?></p><?php endif; ?>
<?php if (!empty($pcats)): ?><p>Phụ trách: <?php foreach ($pcats as $c): ?><a class="badge big" href="/c/<?=e($c['slug'])?>"><?=e($c['icon'])?> <?=e($c['name'])?></a> <?php endforeach; ?></p><?php endif; ?>
<?php if (!empty($parts)): ?><h2>Bài viết nổi bật</h2><?php foreach ($parts as $a): ?><article class="card"><a class="qt" href="/bai-viet/<?=e($a['slug'])?>-<?=(int)$a['id']?>"><?=e($a['title'])?></a></article><?php endforeach; endif; ?>
<div class="stats"><div class="stat"><small>Câu trả lời</small><b><?=(int)$st['answers']?></b></div><div class="stat"><small>Tốt nhất</small><b><?=(int)$st['best']?></b></div>
<div class="stat"><small>Bình chọn nhận</small><b><?=(int)$st['upvotes']?></b></div><div class="stat"><small>Câu hỏi</small><b><?=(int)$st['questions']?></b></div></div>
<?php if ($badges): ?><h2>Huy hiệu</h2><div class="chips"><?php foreach ($badges as $b): if (!isset($defs[$b])) continue; ?><span class="badge big" title="<?=e($defs[$b][1])?>"><?=$defs[$b][0]?> <?=e($defs[$b][1])?></span><?php endforeach; ?></div><?php endif; ?>
<?php if ($best): ?><h2>Câu trả lời tốt nhất</h2><?php foreach ($best as $x): ?><article class="card"><a class="qt" href="/hoi/<?=e($x['slug'])?>-<?=(int)$x['qid']?>#a<?=(int)$x['id']?>"><?=e($x['title'])?></a></article><?php endforeach; endif; ?>
<?php if ($recA): ?><h2>Trả lời gần đây</h2><?php foreach ($recA as $x): ?><article class="card"><a class="qt" href="/hoi/<?=e($x['slug'])?>-<?=(int)$x['qid']?>#a<?=(int)$x['id']?>"><?=e($x['title'])?></a><div class="meta"><?=(int)$x['score']?> bình chọn</div></article><?php endforeach; endif; ?>
<?php if ($recQ): ?><h2>Câu hỏi gần đây</h2><?php foreach ($recQ as $x): ?><article class="card"><a class="qt" href="/hoi/<?=e($x['slug'])?>-<?=(int)$x['id']?>"><?=e($x['title'])?></a><div class="meta"><?=(int)$x['answers_count']?> trả lời</div></article><?php endforeach; endif; ?>
