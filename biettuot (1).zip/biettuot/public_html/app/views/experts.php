<h1>🎓 Chuyên gia & cộng tác viên</h1><p class="muted">Những người được Biết Tuốt giao phụ trách và/hoặc xác minh chuyên môn trong từng lĩnh vực.</p>
<nav class="chips"><a href="/chuyen-gia">Tất cả</a><?php foreach (cats() as $c): ?><a href="/chuyen-gia?c=<?=e($c['slug'])?>"><?=e($c['icon'])?> <?=e($c['name'])?></a><?php endforeach; ?></nav>
<?php foreach ($rows as $r): ?><article class="card"><a class="qt" href="/u/<?=e($r['username'])?>"><?=e($r['username'])?></a> <?=tier_badge($r)?>
<div class="meta"><?=e($r['cats'] ?: 'Chưa gán lĩnh vực')?> · <?=(int)$r['arts']?> bài viết</div><?php if ($r['bio'] !== ''): ?><p class="muted"><?=e($r['bio'])?></p><?php endif; ?></article>
<?php endforeach; if (!$rows): ?><p class="muted">Chưa có ai trong mục này. <a href="/cong-tac-vien">Ứng tuyển cộng tác viên</a></p><?php endif; ?>
