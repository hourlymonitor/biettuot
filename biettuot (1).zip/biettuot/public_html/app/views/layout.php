<!doctype html><html lang="vi"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=e($title)?></title><meta name="description" content="<?=e($desc)?>">
<?php $noidx = !empty($opt['noindex']) || cfg('noindex'); $cu = me(); if ($noidx): ?><meta name="robots" content="noindex,nofollow"><?php endif; ?>
<link rel="canonical" href="<?=e(url((string)strtok($_SERVER['REQUEST_URI'], '?')))?>">
<?php if (!$noidx): $og = $opt['og'] ?? []; ?><meta property="og:site_name" content="<?=e(cfg('site_name'))?>"><meta property="og:type" content="<?=e($og['type'] ?? 'website')?>"><meta property="og:title" content="<?=e($og['title'] ?? $title)?>"><meta property="og:description" content="<?=e($og['desc'] ?? $desc)?>">
<meta property="og:image" content="<?=e($og['image'] ?? url('/assets/og-default.png'))?>"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:url" content="<?=e(url((string)strtok($_SERVER['REQUEST_URI'], '?')))?>"><meta name="twitter:card" content="summary_large_image"><?php endif; ?>
<meta name="theme-color" content="#7c3aed"><?php if (feature('pwa')): ?><link rel="manifest" href="/manifest.webmanifest"><?php endif; ?><link rel="apple-touch-icon" href="/assets/icon-192.png">
<link rel="stylesheet" href="/assets/style.css">
<?php if (!$noidx): $ldx = [];
  if (isset($r, $answers)) {
    $ld = ['@context' => 'https://schema.org', '@type' => 'QAPage', 'mainEntity' => ['@type' => 'Question', 'name' => $r['title'], 'text' => $r['body'] ?: $r['title'],
      'answerCount' => count($answers), 'dateCreated' => date('c', strtotime($r['created_at'])), 'author' => ['@type' => 'Person', 'name' => $r['username']]]];
    $sug = [];
    foreach ($answers as $a) { $x = ['@type' => 'Answer', 'text' => strip_tags($a['body']), 'dateCreated' => date('c', strtotime($a['created_at'])), 'upvoteCount' => (int)$a['score']];
      if ($a['is_best']) $ld['mainEntity']['acceptedAnswer'] = $x; else $sug[] = $x; }
    if ($sug) $ld['mainEntity']['suggestedAnswer'] = $sug; $ldx[] = $ld;
    $ldx[] = ['@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => [
      ['@type' => 'ListItem', 'position' => 1, 'name' => 'Trang chủ', 'item' => url('/')], ['@type' => 'ListItem', 'position' => 2, 'name' => $r['cat'], 'item' => url('/c/'.$r['cslug'])],
      ['@type' => 'ListItem', 'position' => 3, 'name' => $r['title']]]];
  }
  if (isset($art)) $ldx[] = ['@context' => 'https://schema.org', '@type' => 'Article', 'headline' => $art['title'], 'datePublished' => date('c', strtotime($art['published_at'] ?: $art['created_at'])), 'inLanguage' => 'vi'];
  if (!empty($opt['home'])) $ldx[] = ['@context' => 'https://schema.org', '@type' => 'WebSite', 'name' => cfg('site_name'), 'url' => url('/'),
    'potentialAction' => ['@type' => 'SearchAction', 'target' => url('/tim').'?q={search_term_string}', 'query-input' => 'required name=search_term_string']];
  foreach ($ldx as $x): ?><script type="application/ld+json"><?=json_encode($x, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP)?></script>
<?php endforeach; endif; ?></head><body data-pwa="<?=feature('pwa') ? '1' : '0'?>">
<header class="top"><div class="wrap bar">
  <a class="logo" href="/"><span class="logo-mark">B</span>Biết<span>Tuốt</span></a>
  <nav class="dnav mainnav" aria-label="Menu chính">
    <a href="/">Hỏi đáp</a>
    <details class="dd"><summary>Lĩnh vực</summary><div class="pop cols2"><?php foreach (cats() as $c): ?><a href="/c/<?=e($c['slug'])?>"><?=e($c['icon'])?> <?=e($c['name'])?></a><?php endforeach; ?></div></details>
    <?php if (feature('articles')): ?><a href="/bai-viet">Bài viết</a><?php endif; ?>
    <?php if (feature('chat')): ?><a class="hl" href="/tro-ly">🤖 Trợ lý AI</a><?php endif; ?>
    <?php if (feature('quiz') || feature('leaderboard') || feature('rewards') || feature('ctv') || feature('premium')): ?><details class="dd"><summary>Cộng đồng</summary><div class="pop">
      <?php if (feature('quiz')): ?><a href="/do-vui">🎯 Đố vui</a><?php endif; ?><?php if (feature('leaderboard')): ?><a href="/xep-hang">🏅 Xếp hạng</a><?php endif; ?><?php if (feature('rewards')): ?><a href="/qua-tang">🎁 Đổi quà</a><?php endif; ?>
      <?php if (feature('ctv')): ?><a href="/cong-tac-vien">🤝 Cộng tác viên</a><?php endif; ?><?php if (feature('premium')): ?><a href="/goi-thanh-vien">💎 Premium</a><?php endif; ?></div></details><?php endif; ?>
  </nav>
  <form class="search" action="/tim" role="search"><input name="q" placeholder="Tìm câu hỏi…" value="<?=e($_GET['q'] ?? '')?>" aria-label="Tìm kiếm"></form>
  <div class="right">
  <?php if ($cu): ?>
    <?php if (feature('ask')): ?><a class="btn dnav" href="/hoi-moi">+ Hỏi</a><?php endif; ?>
    <?php if (feature('points')): ?><a class="pill" href="/vi" title="Điểm khả dụng">⭐ <?=number_format((int)$cu['points'])?></a><?php endif; ?>
    <?php if (feature('notifications')): ?><a class="bell" href="/thong-bao" aria-label="Thông báo">🔔<?php if (unread_count()): ?><i class="dot"><?=min(99, unread_count())?></i><?php endif; ?></a><?php endif; ?>
    <details class="dd dnav um"><summary><?=e($cu['username'])?></summary><div class="pop right-pop">
      <?php if (feature('profiles')): ?><a href="/u/<?=e($cu['username'])?>">👤 Hồ sơ</a><?php endif; ?><?php if (feature('points')): ?><a href="/vi">⭐ Ví điểm & thử thách</a><?php endif; ?><a href="/cai-dat">⚙️ Cài đặt</a>
      <?php if (feature('ctv') && is_ctv($cu)): ?><a href="/ctv">✍️ Khu vực CTV</a><?php endif; ?><?php if (is_admin() || $cu['role'] === 'collab'): ?><a href="/admin">🛠 Quản trị</a><?php endif; ?>
      <form method="post" action="/dang-xuat"><?=csrf_field()?><button>🚪 Đăng xuất</button></form></div></details>
  <?php else: ?><a class="dnav" href="/dang-nhap">Đăng nhập</a><?php if (feature('registration')): ?><a class="btn" href="/dang-ky">Đăng ký</a><?php endif; ?><?php endif; ?>
  </div></div></header>
<main class="wrap">
<?php if (is_admin() && !schema_current()): ?><div class="flash err">⚠️ Cơ sở dữ liệu chưa được cập nhật lên phiên bản mới. <a href="/install.php">Chạy trình cài đặt CSDL</a> (hoặc Admin → Hệ thống → Cập nhật cơ sở dữ liệu).</div><?php endif; ?>
<?php if ($cu && !$cu['email_verified'] && (feature('require_verified') || feature('rewards'))): ?><div class="flash info">📧 Hãy xác minh email để đổi quà và dùng đầy đủ tính năng. <a href="/cai-dat">Gửi lại thư xác minh</a></div><?php endif; ?>
<?php foreach (flash() as [$t, $m]): ?><div class="flash <?=e($t)?>"><?=e($m)?></div><?php endforeach; ?>
<?=$content?>
</main>
<?php if (empty($opt['chat']) && feature('chat') && feature('fab')): ?><a class="fab" href="/tro-ly" aria-label="Hỏi trợ lý AI">🤖 <span>Hỏi trợ lý</span></a><?php endif; ?>
<footer class="foot"><div class="wrap">
<div class="fgrid">
  <div><b>Lĩnh vực</b><?php foreach (cats() as $c): ?><a href="/c/<?=e($c['slug'])?>"><?=e($c['name'])?></a><?php endforeach; ?></div>
  <div><b>Khám phá</b><a href="/">Hỏi đáp</a><?php if (feature('articles')): ?><a href="/bai-viet">Bài viết</a><?php endif; ?><?php if (feature('chat')): ?><a href="/tro-ly">Trợ lý AI</a><?php endif; ?><?php if (feature('quiz')): ?><a href="/do-vui">Đố vui hằng ngày</a><?php endif; ?><?php if (feature('leaderboard')): ?><a href="/xep-hang">Xếp hạng</a><?php endif; ?><?php if (feature('rewards')): ?><a href="/qua-tang">Đổi quà</a><?php endif; ?></div>
  <div><b>Cộng đồng</b><?php if (feature('ctv')): ?><a href="/cong-tac-vien">Cộng tác viên</a><?php endif; ?><?php if (feature('premium')): ?><a href="/goi-thanh-vien">Gói Premium</a><?php endif; ?><?php if (feature('experts')): ?><a href="/chuyen-gia">Chuyên gia</a><?php endif; ?><a href="/trang/quy-dinh">Quy định cộng đồng</a><?php if (feature('ask')): ?><a href="/hoi-moi">Đặt câu hỏi</a><?php endif; ?></div>
  <div><b>Về Biết Tuốt</b><a href="/trang/gioi-thieu">Giới thiệu</a><a href="/trang/bao-mat">Bảo mật</a><a href="/trang/dieu-khoan">Điều khoản</a><a href="/sitemap.xml">Sơ đồ trang</a></div>
</div>
<?php if (feature('newsletter')): ?><form class="nlform" method="post" action="/ban-tin/dang-ky"><input type="text" name="hp_note" class="hp" tabindex="-1" autocomplete="off"><input type="hidden" name="back" value="<?=e($_SERVER['REQUEST_URI'] ?? '/')?>"><input type="email" name="email" placeholder="Email nhận bản tin hằng tuần" required aria-label="Email"><button class="btn sm">Đăng ký</button></form><?php endif; ?>
<p>Nội dung do AI tạo chỉ mang tính tham khảo; hãy kiểm chứng trước khi áp dụng, nhất là về sức khỏe, pháp luật, tài chính.</p>
<p><button id="install" class="btn sm" hidden>📲 Cài ứng dụng</button></p></div></footer>
<nav class="tabbar" aria-label="Điều hướng chính">
  <a href="/"><b>🏠</b><span>Trang chủ</span></a>
  <?php if (feature('chat')): ?><a href="/tro-ly"><b>🤖</b><span>Trợ lý</span></a><?php else: ?><a href="/tim"><b>🔍</b><span>Tìm</span></a><?php endif; ?>
  <?php if (feature('ask')): ?><a class="tab-ask" href="/hoi-moi"><b>➕</b><span>Hỏi</span></a><?php endif; ?>
  <?php if (feature('notifications')): ?><a href="/thong-bao"><b>🔔<?php if ($cu && unread_count()): ?><i class="dot"><?=min(99, unread_count())?></i><?php endif; ?></b><span>Thông báo</span></a><?php elseif (feature('articles')): ?><a href="/bai-viet"><b>📰</b><span>Bài viết</span></a><?php endif; ?>
  <a href="/menu"><b>☰</b><span>Menu</span></a>
</nav>
<script src="/assets/app.js" defer></script></body></html>
