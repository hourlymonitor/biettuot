<?php if (!empty($hero)): ?><section class="hero"><h1>Hỏi gì cũng có câu trả lời</h1><p>Đặt câu hỏi, AI trả lời ngay, cộng đồng bổ sung và bình chọn.</p><?php if (feature('chat')): ?><form class="askbox" action="/tro-ly" method="get" role="search"><input name="q" maxlength="500" placeholder="Hỏi trợ lý AI bất cứ điều gì…" aria-label="Hỏi trợ lý AI" required><button class="btn big">🤖 Hỏi ngay</button></form><?php endif; ?>
<p class="muted"><?php if (feature('ask')): ?><a href="/hoi-moi">Đặt câu hỏi cho cộng đồng</a><?php endif; ?><?php if (feature('ctv')): ?> · <a href="/cong-tac-vien">Trở thành cộng tác viên</a><?php endif; ?></p></section>
<div class="cards2">
<?php if (!empty($qotd)): ?><a class="card feat" href="<?=e(qurl($qotd))?>"><small>📌 Câu hỏi của ngày · trả lời nhận thêm điểm</small><b><?=e($qotd['title'])?></b></a><?php endif; ?>
<?php if (!empty($quiz)): ?><a class="card feat" href="/do-vui"><small>🎯 Đố vui hôm nay · trả lời đúng nhận điểm</small><b><?=e($quiz['question'])?></b></a><?php endif; ?></div>
<?=ad_slot('top')?><?php endif; ?>
<?php if (!empty($searchbox)): ?><form class="form" action="/tim" role="search"><input name="q" value="<?=e($q_text ?? '')?>" placeholder="Nhập từ khóa…" autofocus><button class="btn">Tìm</button></form><?php endif; ?>
<nav class="chips"><?php foreach (cats() as $c): ?><a href="/c/<?=e($c['slug'])?>"><?=e($c['icon'])?> <?=e($c['name'])?></a><?php endforeach; ?></nav>
<?php if (!empty($ptags)): ?><nav class="chips tags"><?php foreach ($ptags as $t): ?><a href="/the/<?=e($t['slug'])?>">#<?=e($t['name'])?></a><?php endforeach; ?></nav><?php endif; ?>
<div class="hrow"><h2><?=e($heading)?></h2><?=$followBtn ?? ''?></div><?php if (!empty($sub)): ?><p class="muted"><?=e($sub)?></p><?php endif; ?>
<?php if (!empty($landing)): ?>
<?php if (trim((string)$landing['long']) !== ''): ?><div class="body"><?=md_doc($landing['long'])?></div><?php endif; ?>
<?php if ($landing['ctvs']): ?><p class="muted">Cộng tác viên phụ trách: <?php foreach ($landing['ctvs'] as $v): ?><a href="/u/<?=e($v['username'])?>"><?=e($v['username'])?></a><?=$v['expert_title'] ? ' ('.e($v['expert_title']).')' : ''?> · <?php endforeach; ?><a href="/chuyen-gia">Tất cả</a></p><?php endif; ?>
<?php if ($landing['articles']): ?><h3>📰 Bài viết nổi bật</h3><?php foreach ($landing['articles'] as $a): ?><article class="card"><a class="qt" href="/bai-viet/<?=e($a['slug'])?>-<?=(int)$a['id']?>"><?=e($a['title'])?></a></article><?php endforeach; endif; ?>
<?php if ($landing['unanswered']): ?><h3>🙋 Cần thêm câu trả lời</h3><?php foreach ($landing['unanswered'] as $a): ?><article class="card"><a class="qt" href="<?=e(qurl($a))?>"><?=e($a['title'])?></a></article><?php endforeach; endif; ?>
<h3>Câu hỏi mới</h3>
<?php endif; ?>
<?php foreach ($qs as $i => $r): ?>
<article class="card"><a class="qt" href="<?=e(qurl($r))?>"><?=e($r['title'])?></a>
<div class="meta"><a href="/c/<?=e($r['cslug'])?>"><?=e($r['cat'])?></a> · <?=e($r['username'])?> · <?=e(ago($r['created_at']))?> · <?=(int)$r['answers_count']?> trả lời · <?=(int)$r['views']?> lượt xem</div></article>
<?php if ($i === 2) echo ad_slot('inline'); endforeach; if (!$qs): ?><p class="muted">Chưa có câu hỏi nào. <a href="/hoi-moi">Hãy là người đầu tiên!</a></p><?php endif; ?>
<?php $sep = str_contains($base, '?') ? '&' : '?'; ?>
<div class="pager"><?php if ($page > 1): ?><a class="btn ghost" href="<?=e($base.$sep.'page='.($page - 1))?>">← Trước</a><?php else: ?><span></span><?php endif; ?>
<?php if (count($qs) >= 15): ?><a class="btn ghost" href="<?=e($base.$sep.'page='.($page + 1))?>">Sau →</a><?php endif; ?></div>
