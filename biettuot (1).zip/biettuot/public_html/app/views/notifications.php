<h1>Thông báo</h1>
<?php foreach ($items as $n): ?><a class="card notif<?=$n['is_read'] ? '' : ' unread'?>" href="<?=e($n['url'])?>"><?=e($n['text'])?><div class="meta"><?=e(ago($n['created_at']))?></div></a>
<?php endforeach; if (!$items): ?><p class="muted">Chưa có thông báo nào.</p><?php endif; ?>
