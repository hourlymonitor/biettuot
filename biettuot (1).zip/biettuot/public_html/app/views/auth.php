<?php $titles = ['login' => 'Đăng nhập', 'register' => 'Đăng ký', 'forgot' => 'Quên mật khẩu', 'reset' => 'Đặt mật khẩu mới']; ?>
<h1><?=$titles[$mode]?></h1>
<?php if (!empty($err)): ?><div class="flash err"><?=e($err)?></div><?php endif; ?>
<form method="post" class="form narrow"><?=csrf_field()?><input type="text" name="hp_note" class="hp" tabindex="-1" autocomplete="off">
<?php if ($mode === 'register'): ?>
  <label>Tên đăng nhập<input name="username" required pattern="[A-Za-z0-9_]{3,30}" autocomplete="username"></label>
  <label>Email<input type="email" name="email" required autocomplete="email"></label>
  <label>Mật khẩu (tối thiểu 8 ký tự)<input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
  <label class="chk"><input type="checkbox" name="agree" value="1" required> Tôi đồng ý <a href="/trang/dieu-khoan" target="_blank">Điều khoản</a> và <a href="/trang/bao-mat" target="_blank">Chính sách bảo mật</a></label>
<?php elseif ($mode === 'login'): ?>
  <label>Tên đăng nhập hoặc email<input name="login" required autocomplete="username"></label>
  <label>Mật khẩu<input type="password" name="password" required autocomplete="current-password"></label>
<?php elseif ($mode === 'forgot'): ?>
  <label>Email đã đăng ký<input type="email" name="email" required autocomplete="email"></label>
<?php else: ?><input type="hidden" name="t" value="<?=e($token)?>">
  <label>Mật khẩu mới (tối thiểu 8 ký tự)<input type="password" name="password" required minlength="8" autocomplete="new-password"></label><?php endif; ?>
<?php if ($mode !== 'reset') echo turnstile_widget(); ?>
<button class="btn big"><?=['login' => 'Đăng nhập', 'register' => 'Tạo tài khoản', 'forgot' => 'Gửi hướng dẫn', 'reset' => 'Lưu mật khẩu'][$mode]?></button>
<p class="muted"><?php if ($mode === 'register'): ?>Đã có tài khoản? <a href="/dang-nhap">Đăng nhập</a>
<?php elseif ($mode === 'login'): ?>Chưa có tài khoản? <a href="/dang-ky">Đăng ký</a> · <a href="/quen-mat-khau">Quên mật khẩu?</a><?php endif; ?></p></form>
