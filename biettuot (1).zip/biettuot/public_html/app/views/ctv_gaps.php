<h1>📌 Nhu cầu nội dung</h1>
<p class="muted">Những câu hỏi người dùng đã gửi cho Trợ lý hoặc tìm kiếm mà <b>website chưa có nội dung phù hợp</b>. Hãy nhận một chủ đề và viết bài - bài đúng nhu cầu sẽ có nhiều lượt xem hơn (và tăng phần chia sẻ doanh thu).</p>
<p><a class="btn ghost" href="/ctv">← Khu vực CTV</a></p>
<?php if ($canAi): ?><form method="post" action="/ctv/soan-nhap" class="form card"><?=csrf_field()?><b>🤖 Soạn bản nháp bằng AI từ chủ đề bất kỳ</b>
<div class="g2"><label>Chủ đề / câu hỏi cần giải đáp<input name="topic" minlength="10" maxlength="200" required placeholder="Ví dụ: Cách bảo quản rau củ trong tủ lạnh"></label>
<label>Lĩnh vực<select name="category_id" required><option value="">- Chọn -</option><?php foreach ($cats as $c): ?><option value="<?=(int)$c['id']?>"><?=e($c['icon'].' '.$c['name'])?></option><?php endforeach; ?></select></label></div>
<button class="btn">Soạn nháp</button><span class="muted">AI chỉ tạo bản nháp; bạn phải kiểm chứng và chỉnh sửa trước khi đăng.</span></form><?php endif; ?>
<?php foreach ($gaps as $g): ?><div class="card gapcard"><b><?=e($g['query'])?></b> <span class="badge"><?=(int)$g['hits']?> lượt hỏi</span> <span class="badge <?=$g['status'] === 'open' ? 'ok' : ''?>"><?=$g['status'] === 'open' ? 'Chưa ai nhận' : 'Đã giao: '.e($g['assignee'] ?? '')?></span>
<div class="meta"><?=e($g['cname'] ?? 'Chưa gán lĩnh vực')?> · lần cuối <?=e(ago($g['last_at']))?></div>
<div class="acts">
<form method="post" action="/ctv/nhu-cau/act" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$g['id']?>">
<?php if ($g['status'] === 'open'): ?><button class="btn sm" name="act" value="claim">Nhận viết</button><?php endif; ?><button class="btn sm ghost" name="act" value="done">Đã xong</button><button class="btn sm ghost" name="act" value="ignore">Bỏ qua</button></form>
<?php if (!$g['category_id']): ?><form method="post" action="/ctv/nhu-cau/act" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$g['id']?>"><input type="hidden" name="act" value="setcat"><select name="category_id" style="width:auto"><?php foreach ($cats as $c): ?><option value="<?=(int)$c['id']?>"><?=e($c['name'])?></option><?php endforeach; ?></select><button class="btn sm ghost">Gán lĩnh vực</button></form><?php endif; ?>
<?php if ($canAi && $g['category_id']): ?><form method="post" action="/ctv/soan-nhap" class="inline"><?=csrf_field()?><input type="hidden" name="gap_id" value="<?=(int)$g['id']?>"><input type="hidden" name="topic" value="<?=e($g['query'])?>"><input type="hidden" name="category_id" value="<?=(int)$g['category_id']?>"><button class="btn sm">🤖 Soạn nháp</button></form><?php endif; ?>
<?php if ($g['article_id']): ?><a class="btn sm ghost" href="/ctv/bai-viet/<?=(int)$g['article_id']?>/sua">Mở bản nháp</a><?php endif; ?></div></div>
<?php endforeach; if (!$gaps): ?><p class="muted">Chưa có nhu cầu nội dung nào được ghi nhận.</p><?php endif; ?>
