<h1>📜 Điều khoản</h1><?=admin_nav()?>
<div class="stats"><div class="stat"><small>Phiên bản điều khoản CTV</small><b><?=(int)$ver?></b></div><div class="stat"><small>CTV đã đồng ý phiên bản này</small><b><?=(int)$accepted?> / <?=(int)$ctvs?></b></div><div class="stat"><small>Phiên bản điều khoản/bảo mật chung</small><b><?=(int)$siteVer?></b></div></div>
<form method="post" class="form"><?=csrf_field()?>
<label>Nội dung điều khoản cộng tác viên (hiển thị tại /dieu-khoan-ctv; định dạng ## tiêu đề, - gạch đầu dòng)<textarea name="text" rows="16"><?=e($text)?></textarea></label>
<label class="chk"><input type="checkbox" name="bump" value="1"> Đây là thay đổi quan trọng - <b>yêu cầu mọi CTV đồng ý lại</b> (tăng phiên bản)</label>
<label class="chk"><input type="checkbox" name="bump_site" value="1"> Tăng phiên bản Điều khoản/Chính sách bảo mật chung (ghi nhận cho người đăng ký mới)</label>
<button class="btn">Lưu</button></form>
<p class="muted">Văn bản mặc định chỉ là bản mẫu. Hãy nhờ luật sư soạn/rà soát. Hệ thống lưu thời điểm, phiên bản và IP khi người dùng đồng ý (bảng terms_acceptance).</p>
