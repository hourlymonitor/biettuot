<h1>Kiểm duyệt</h1><?=admin_nav()?>
<?php if (is_admin()): ?><h2>Trạng thái các AI</h2>
<table><tr><th>AI</th><th>Model</th><th>Key</th><th>Hôm nay</th><th>Trạng thái</th><th></th></tr>
<?php foreach ($prov as $x): $p = $x['p']; ?><tr><td><b><?=e($p['name'])?></b></td><td><?=e($p['model'])?></td><td><?=!empty($p['key']) ? '✔' : '- (tắt)'?></td>
<td><?=(int)$x['n']?><?=!empty($p['daily_limit']) ? ' / '.(int)$p['daily_limit'] : ''?></td>
<td><?=$x['cd'] ? '⏸ nghỉ đến '.e($x['cd']['until_at']).' · '.e($x['cd']['reason']) : (!empty($p['key']) ? '🟢 sẵn sàng' : '')?></td>
<td><?php if ($x['cd']): ?><form method="post" action="/admin/act" class="inline"><?=csrf_field()?><input type="hidden" name="act" value="reset_ai"><input type="hidden" name="provider" value="<?=e($p['name'])?>"><button class="btn sm">Bật lại</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></table>
<p class="muted">Tác vụ nền: <?php foreach ($jobs as $k => $n) echo e($k).' '.(int)$n.' · '; ?><?php if (!empty($jobs['failed'])): ?><form method="post" action="/admin/act" class="inline"><?=csrf_field()?><button class="btn sm" name="act" value="retry_jobs">Thử lại tác vụ lỗi</button></form><?php endif; ?></p><?php endif; ?>
<h2>Báo cáo chưa xử lý (<?=count($reports)?>) <small class="muted">- xếp theo số lượt báo</small></h2>
<?php foreach ($reports as $x): ?><div class="card"><span class="badge ok"><?=(int)$x['n']?> báo cáo</span> <b><?=$x['target_type'] === 'question' ? 'Câu hỏi' : 'Câu trả lời'?>:</b> <a href="/hoi/x-<?=(int)$x['qid']?>" target="_blank"><?=e($x['preview'])?></a>
<div class="meta">Lý do: <?=e($x['reasons'])?> · <?=e(ago($x['first_at']))?></div>
<form method="post" action="/admin/act" class="inline"><?=csrf_field()?><?=back_field()?><input type="hidden" name="ttype" value="<?=e($x['target_type'])?>"><input type="hidden" name="tid" value="<?=(int)$x['target_id']?>">
<button class="btn sm" name="act" value="hide_t">Ẩn nội dung</button><button class="btn sm ghost" name="act" value="resolve_t">Bỏ qua</button></form></div>
<?php endforeach; ?>
<h2>Câu hỏi chờ duyệt (<?=count($pending)?>)</h2>
<?php foreach ($pending as $x): ?><div class="card"><a href="/hoi/<?=e($x['slug'])?>-<?=(int)$x['id']?>" target="_blank"><?=e($x['title'])?></a> <span class="meta">· <?=e($x['username'])?></span>
<form method="post" action="/admin/act" class="inline"><?=csrf_field()?><?=back_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><button class="btn sm" name="act" value="pub_q">Duyệt</button><button class="btn sm ghost" name="act" value="hide_q">Ẩn</button></form></div>
<?php endforeach; ?>
<h2>Câu trả lời chờ duyệt (<?=count($pans)?>)</h2>
<?php foreach ($pans as $x): ?><div class="card"><a href="/hoi/x-<?=(int)$x['qid']?>" target="_blank"><?=e(mb_substr($x['body'], 0, 160))?></a> <span class="meta">· <?=e($x['username'])?></span>
<form method="post" action="/admin/act" class="inline"><?=csrf_field()?><?=back_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><button class="btn sm" name="act" value="pub_a">Duyệt</button><button class="btn sm ghost" name="act" value="hide_a">Ẩn</button></form></div>
<?php endforeach; ?>
<?php if (is_admin()): ?><h2>Nhật ký AI gần đây</h2>
<table><tr><th>Giờ</th><th>AI</th><th>Kết quả</th><th>Ghi chú</th></tr><?php foreach ($log as $l): ?>
<tr><td><?=e($l['created_at'])?></td><td><?=e($l['provider'])?></td><td><?=$l['ok'] ? '✔' : '✘ '.(int)$l['http_code']?></td><td><?=e($l['note'])?></td></tr><?php endforeach; ?></table><?php endif; ?>
