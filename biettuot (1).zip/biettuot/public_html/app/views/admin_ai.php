<h1>🤖 Quản lý AI</h1><?=admin_nav()?>
<?php if (!$dbOk): ?><div class="flash err">Chưa có bảng <code>ai_providers</code>. Hãy chạy <a href="/install.php">/install.php</a> (hoặc Admin → Hệ thống → "Cập nhật cơ sở dữ liệu").</div><?php endif; ?>
<div class="stats"><div class="stat"><small>AI đang hoạt động</small><b><?=(int)$active?></b></div><div class="stat"><small>Chiến lược</small><b style="font-size:1rem"><?=$strategy === 'round_robin' ? 'Xoay vòng đều' : 'Ưu tiên theo thứ tự'?></b></div></div>
<p class="muted">Thêm API key ở đây là AI được tích hợp ngay (Trợ lý chat, AI trả lời câu hỏi, kiểm duyệt, tóm tắt...). Khóa được mã hóa trong CSDL. Khi một AI hết hạn mức hoặc lỗi, hệ thống tự chuyển sang AI khác; AI đánh dấu <b>dự phòng</b> (ví dụ Puter) chỉ được dùng khi tất cả AI chính không dùng được.</p>

<h2>Các AI đã thêm</h2>
<?php foreach ($provs as $p): ?><div class="card aicard">
  <div class="ai-head"><b><?=e($p['label'])?></b> <span class="badge"><?=$p['type'] === 'anthropic' ? 'Anthropic' : 'OpenAI-tương thích'?></span>
    <?php if ($p['fallback']): ?><span class="badge prem">Dự phòng<?=$p['chat_only'] ? ' (chỉ chat)' : ''?></span><?php endif; ?>
    <?=$p['source'] === 'config' ? '<span class="badge">từ config</span>' : ''?>
    <?=!$p['active'] ? '<span class="badge adm">Đang tắt</span>' : ($p['cd'] ? '<span class="badge">⏸ nghỉ: '.e($p['cd']['reason']).'</span>' : '<span class="badge ok">🟢 Sẵn sàng</span>')?></div>
  <div class="meta">Model: <b><?=e($p['model'])?></b> · Key: <?=e($p['mask'])?> · Hôm nay: <?=(int)$p['used']?><?=$p['daily_limit'] ? ' / '.(int)$p['daily_limit'] : ''?> lượt · Ưu tiên: <?=(int)$p['priority']?>
    <?php if ($p['test_at']): ?> · Kiểm tra: <?=$p['test_ok'] ? '✔' : '✘'?> <?=e($p['test_note'])?><?php endif; ?></div>
  <?php if ($p['source'] === 'db'): ?>
  <details class="rep"><summary>Chỉnh sửa / thao tác</summary>
  <form method="post" class="form"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$p['id']?>">
    <div class="g2"><label>Tên hiển thị<input name="label" value="<?=e($p['label'])?>"></label><label>Model<input name="model" value="<?=e($p['model'])?>"></label></div>
    <?php if ($p['type'] !== 'anthropic'): ?><label>Base URL<input name="base_url" value="<?=e($p['base_url'])?>"></label><?php endif; ?>
    <div class="g2"><label>Ưu tiên (nhỏ = dùng trước)<input type="number" name="priority" value="<?=(int)$p['priority']?>"></label><label>Giới hạn lượt/ngày (trống = không giới hạn)<input type="number" name="daily_limit" value="<?=$p['daily_limit'] ? (int)$p['daily_limit'] : ''?>"></label></div>
    <div class="g2"><label>Giá token vào (USD / 1 triệu)<input type="number" step="0.0001" min="0" name="price_in" value="<?=e((string)($p['price_in'] ?? 0))?>"></label><label>Giá token ra (USD / 1 triệu)<input type="number" step="0.0001" min="0" name="price_out" value="<?=e((string)($p['price_out'] ?? 0))?>"></label></div>
    <div class="g2"><label>Giới hạn lượt/tháng (trống = không)<input type="number" min="0" name="monthly_limit" value="<?=!empty($p['monthly_limit']) ? (int)$p['monthly_limit'] : ''?>"></label><label>Ngân sách tháng cho AI này (USD, trống = không)<input type="number" step="0.01" min="0" name="monthly_budget_usd" value="<?=!empty($p['monthly_budget_usd']) ? e((string)$p['monthly_budget_usd']) : ''?>"></label></div>
    <label class="chk"><input type="checkbox" name="vision" value="1" <?=!empty($p['vision']) ? 'checked' : ''?>> Hỗ trợ đọc ảnh (cho tính năng "Hỏi bằng ảnh")</label>
    <label>Thay API key (để trống = giữ nguyên)<input type="password" name="api_key" autocomplete="off" placeholder="Dán key mới nếu cần đổi"></label>
    <label class="chk"><input type="checkbox" name="is_fallback" value="1" <?=$p['fallback'] ? 'checked' : ''?>> Dự phòng (chỉ dùng khi các AI chính hết hạn mức/lỗi)</label>
    <label class="chk"><input type="checkbox" name="chat_only" value="1" <?=$p['chat_only'] ? 'checked' : ''?>> Chỉ dùng cho Trợ lý chat (khi là dự phòng)</label>
    <div class="acts"><button class="btn sm" name="act" value="save">Lưu</button><button class="btn sm ghost" name="act" value="test">Kiểm tra</button><button class="btn sm ghost" name="act" value="models">Danh sách model</button>
      <button class="btn sm ghost" name="act" value="toggle"><?=$p['active'] ? 'Tắt' : 'Bật'?></button><?php if ($p['cd']): ?><button class="btn sm ghost" name="act" value="reset_cd" onclick="this.form.pname.value='<?=e($p['name'])?>'">Bật lại ngay</button><input type="hidden" name="pname" value=""><?php endif; ?>
      <button class="btn sm ghost" name="act" value="delete" data-confirm-btn="Xóa AI này?">Xóa</button></div></form></details>
  <?php endif; ?></div>
<?php endforeach; if (!$provs): ?><p class="muted">Chưa có AI nào. Hãy thêm ở bên dưới.</p><?php endif; ?>
<?php if (array_filter($provs, fn($p) => $p['source'] === 'config')): ?><form method="post" class="inline"><?=csrf_field()?><button class="btn sm" name="act" value="import_config">⬆ Nhập các AI trong config.local.php vào bảng này</button></form><?php endif; ?>

<h2>➕ Thêm AI mới</h2>
<form method="post" class="form card" id="aiadd"><?=csrf_field()?><input type="hidden" name="act" value="add">
  <label>Chọn nhà cung cấp<select name="preset" id="preset"><?php foreach ($presets as $k => $pr): ?><option value="<?=e($k)?>" data-type="<?=e($pr[1])?>" data-base="<?=e($pr[2])?>" data-model="<?=e($pr[3])?>" data-fb="<?=(int)$pr[4]?>" data-note="<?=e($pr[5])?>" data-keylabel="<?=e($pr[7] ?? 'API key')?>" data-vision="<?=(int)($pr[8] ?? 0)?>"><?=e($pr[0])?></option><?php endforeach; ?></select></label>
  <p class="muted" id="presetnote"></p>
  <div class="g2"><label>Tên hiển thị<input name="label" id="f_label" placeholder="Ví dụ: Claude chính"></label>
  <label>Loại API<select name="ptype" id="f_type"><option value="openai">OpenAI-tương thích</option><option value="anthropic">Anthropic</option></select></label></div>
  <label id="row_base">Base URL<input name="base_url" id="f_base" placeholder="https://..."></label>
  <div class="g2"><label>Model (để trống = tự chọn)<input name="model" id="f_model" placeholder="Tự chọn nếu để trống"></label><label><span id="keylabel">API key / token</span><input type="password" name="api_key" autocomplete="off" required placeholder="Dán key / token"></label></div>
  <div class="g2"><label>Ưu tiên (nhỏ = dùng trước)<input type="number" name="priority" value="100"></label><label>Giới hạn lượt/ngày (tùy chọn)<input type="number" name="daily_limit" placeholder="Không giới hạn"></label></div>
  <div class="g2"><label>Giá token vào (USD / 1 triệu, tùy chọn)<input type="number" step="0.0001" min="0" name="price_in" value="0"></label><label>Giá token ra (USD / 1 triệu, tùy chọn)<input type="number" step="0.0001" min="0" name="price_out" value="0"></label></div>
  <label class="chk"><input type="checkbox" name="vision" id="f_vis" value="1"> Hỗ trợ đọc ảnh</label>
  <label class="chk"><input type="checkbox" name="is_fallback" id="f_fb" value="1"> Dự phòng (chỉ dùng khi các AI chính hết hạn mức/lỗi) - nên chọn cho Puter</label>
  <label class="chk"><input type="checkbox" name="chat_only" value="1"> Chỉ dùng cho Trợ lý chat</label>
  <button class="btn big">Lưu & kiểm tra</button></form>

<h2>⚙️ Chiến lược gọi AI</h2>
<form method="post" class="form card"><?=csrf_field()?><input type="hidden" name="act" value="strategy">
  <label class="chk"><input type="radio" name="strategy" value="priority" <?=$strategy !== 'round_robin' ? 'checked' : ''?>> <b>Ưu tiên theo thứ tự</b> - luôn thử AI ưu tiên cao nhất trước, lỗi/hết hạn mức mới chuyển AI kế tiếp.</label>
  <label class="chk"><input type="radio" name="strategy" value="round_robin" <?=$strategy === 'round_robin' ? 'checked' : ''?>> <b>Xoay vòng đều</b> - luân phiên các AI chính để chia đều lượt dùng (vẫn tự chuyển khi lỗi).</label>
  <button class="btn sm">Lưu chiến lược</button></form>

<h2>🔗 Tích hợp AI vào website</h2>
<div class="card"><?php foreach ($aiFeatures as $k => [$name, $on]): ?><div class="meta"><?=$on ? '✅' : '⬜'?> <?=e($name)?></div><?php endforeach; ?>
<p class="muted">Các tính năng trên tự dùng AI đã cấu hình. Bật/tắt từng mục ở <a href="/admin/tinh-nang">Tính năng</a>.</p>
<form method="post" class="inline"><?=csrf_field()?><button class="btn sm" name="act" value="integrate">Bật toàn bộ tính năng AI cơ bản</button></form></div>
<script>(function(){var s=document.getElementById('preset');if(!s)return;function fill(){var o=s.options[s.selectedIndex],d=o.dataset;
 document.getElementById('f_type').value=d.type;document.getElementById('f_base').value=d.base||'';document.getElementById('f_model').value=d.model||'';document.getElementById('f_fb').checked=d.fb==='1';document.getElementById('f_vis').checked=d.vision==='1';
 document.getElementById('f_label').placeholder=o.text;document.getElementById('presetnote').textContent=d.note||'';document.getElementById('keylabel').textContent=d.keylabel||'API key / token';document.getElementById('row_base').style.display=d.type==='anthropic'?'none':'';}
 s.addEventListener('change',fill);document.getElementById('f_type').addEventListener('change',function(){document.getElementById('row_base').style.display=this.value==='anthropic'?'none':'';});fill();})();</script>
