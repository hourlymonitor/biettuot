<h1>Bảng xếp hạng tháng này</h1><p class="muted">Xếp theo điểm đóng góp đã được xác nhận trong tháng.</p>
<table><tr><th>#</th><th>Thành viên</th><th>Cấp bậc</th><th>Điểm tháng</th></tr>
<?php foreach ($rows as $i => $r): ?><tr><td><?=$i + 1?></td><td><b><?=e($r['username'])?></b></td><td><?=tier_badge($r)?></td><td><?=number_format((int)$r['m'])?></td></tr><?php endforeach; ?></table>
<?php if (!$rows): ?><p class="muted">Chưa có dữ liệu tháng này.</p><?php endif; ?>
