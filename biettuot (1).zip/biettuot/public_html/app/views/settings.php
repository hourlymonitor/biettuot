<h1>Cài đặt</h1>
<div class="card"><b>Email:</b> <?=e($u['email'])?> · <?=$u['email_verified'] ? '<span class="badge ok">✔ Đã xác minh</span>' : '<span class="badge">Chưa xác minh</span>'?>
<?php if (!$u['email_verified']): ?><form method="post" action="/xac-minh/gui-lai" class="inline"><?=csrf_field()?><button class="btn sm">Gửi lại thư xác minh</button></form><?php endif; ?>
<?php if (is_premium($u)): ?><div class="meta">⭐ Premium đến <?=e(date('d/m/Y', strtotime($u['premium_until'])))?></div><?php else: ?><div class="meta"><a href="/goi-thanh-vien">Nâng cấp Premium</a> để có thêm lượt hỏi AI và bỏ quảng cáo.</div><?php endif; ?></div>
<form method="post" action="/cai-dat" class="form"><?=csrf_field()?>
  <label>Giới thiệu ngắn (hiển thị ở hồ sơ công khai)<textarea name="bio" rows="3" maxlength="200"><?=e($u['bio'])?></textarea></label>
  <?php if (!empty($u['birthday_set'])): ?><p class="muted">🎂 Ngày sinh: <?=e(date('d/m/Y', strtotime($u['birthday'])))?> (đã ghi nhận; liên hệ quản trị viên nếu cần sửa)</p>
  <?php else: ?><label>🎂 Ngày sinh (nhận quà điểm vào sinh nhật; chỉ đặt được 1 lần, cần tài khoản ≥ 7 ngày)<input type="date" name="birthday" max="<?=e(date('Y-m-d', strtotime('-6 years')))?>"></label><?php endif; ?>
  <label class="chk"><input type="checkbox" name="email_notify" value="1" <?=$u['email_notify'] ? 'checked' : ''?>> Gửi email khi có người trả lời hoặc có cập nhật quan trọng</label>
  <?php if (feature('newsletter')): ?><label class="chk"><input type="checkbox" name="newsletter" value="1" <?=!empty($nl) ? 'checked' : ''?>> Nhận bản tin hằng tuần qua email</label><?php endif; ?>
  <b>Đổi mật khẩu (bỏ trống nếu không đổi)</b>
  <input type="password" name="cur_password" placeholder="Mật khẩu hiện tại" autocomplete="current-password"><input type="password" name="new_password" placeholder="Mật khẩu mới (tối thiểu 8 ký tự)" autocomplete="new-password">
  <button class="btn">Lưu</button></form>
<h2>Bảo mật & dữ liệu</h2><div class="card"><?php if (feature('2fa')): ?><p>🔐 Xác thực hai lớp: <b><?=$u['totp_enabled'] ? 'đang bật' : 'chưa bật'?></b> · <a href="/cai-dat/2fa">Quản lý</a></p><?php endif; ?><?php if (feature('data_tools')): ?><p>📦 <a href="/cai-dat/du-lieu">Tải dữ liệu của tôi / xóa tài khoản</a></p><?php endif; ?></div>
<h2>Giới thiệu bạn bè</h2>
<div class="card"><p>Chia sẻ liên kết này. Bạn nhận <b><?=(int)pc('points.earn.referral')?> điểm</b> khi bạn bè đăng ký, xác minh email, hoạt động ≥ 7 ngày và đăng ≥ 3 nội dung.</p>
<input readonly value="<?=e(url('/dang-ky?ref='.$code))?>" onclick="this.select()"><p class="meta">Đã mời: <?=(int)$refs?> người · Đã nhận thưởng: <?=(int)$earned?> lượt</p></div>
<?php if ($pushPub !== ''): ?><h2>Thông báo đẩy</h2><p class="muted">Nhận thông báo ngay trên thiết bị này (cài ứng dụng vào màn hình chính để dùng tốt trên iPhone).</p>
<button class="btn" id="pushbtn" data-csrf="<?=e(csrf_token())?>" hidden>🔔 Bật thông báo đẩy</button><?php endif; ?>
