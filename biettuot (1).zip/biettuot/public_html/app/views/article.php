<p class="crumb"><a href="/">Trang chủ</a> › <a href="/bai-viet">Bài viết</a><?php if (!empty($art['cat'])): ?> › <a href="/bai-viet/chuyen-muc/<?=e($art['cslug'])?>"><?=e($art['cat'])?></a><?php endif; ?></p>
<article class="doc"><h1><?=e($art['title'])?></h1>
<div class="meta"><?php if (!empty($art['username'])): ?>Tác giả: <b><a href="/u/<?=e($art['username'])?>"><?=e($art['username'])?></a></b> · <?php endif; ?><?=e(date('d/m/Y', strtotime($art['published_at'] ?: $art['created_at'])))?> · <?=(int)$art['views']?> lượt xem
<?php if (!empty($canEdit)): ?> · <a href="/ctv/bai-viet/<?=(int)$art['id']?>/sua">✏️ Sửa bài</a><?php endif; ?></div>
<?php if ($art['status'] !== 'published'): ?><div class="flash info">Bản chưa đăng - chỉ người có quyền chỉnh sửa nhìn thấy.</div><?php endif; ?>
<?php if (!empty($art['csens'])): ?><div class="flash info">⚠️ Lĩnh vực nhạy cảm: nội dung chỉ mang tính tham khảo, không thay thế tư vấn của chuyên gia (bác sĩ, luật sư, chuyên viên tài chính...).</div><?php endif; ?>
<?=md_doc($art['body'])?></article>
<?=$art['status'] === 'published' ? share_buttons('/bai-viet/'.$art['slug'].'-'.(int)$art['id'], $art['title']) : ''?>
<?php if ($art['status'] === 'published'): ?><img class="beacon" src="/api/xem?a=<?=(int)$art['id']?>" width="1" height="1" alt=""><?php endif; ?>
<?=ad_slot('inline')?>
<?php if ($rq): ?><div class="card"><small class="muted">Câu hỏi gốc từ cộng đồng</small><br><a class="qt" href="<?=e(qurl($rq))?>"><?=e($rq['title'])?></a> - xem thảo luận và đóng góp ý kiến của bạn.</div><?php endif; ?>
<p class="muted">Nội dung được biên soạn với sự hỗ trợ của AI và cộng tác viên, mang tính tham khảo.</p>
