<div class="chat" id="chat" data-server="<?=$serverAi ? '1' : '0'?>" data-q="<?=e($q0)?>" data-login="<?=$loggedIn ? '1' : '0'?>" data-sync="<?=$sync ? '1' : '0'?>" data-csrf="<?=e($csrf)?>" data-share="<?=$share ? '1' : '0'?>" data-image="<?=$image ? '1' : '0'?>" data-ts="<?=e($tsSite)?>">
  <div class="chat-head">
    <div class="modes" role="tablist" aria-label="Chế độ trả lời"><?php foreach ($modes as $k => $m): ?><button type="button" class="mode<?=$k === 'smart' ? ' on' : ''?>" data-mode="<?=e($k)?>" title="<?=e($m[4])?>"><?=$m[1]?> <?=e($m[0])?></button><?php endforeach; ?></div>
    <select id="cfield" aria-label="Lĩnh vực"><?php foreach ($fields as [$slug, $name, $icon]): ?><option value="<?=e($slug)?>"><?=e($icon.' '.$name)?></option><?php endforeach; ?></select>
    <button type="button" class="btn sm ghost" id="chist">🕘 Lịch sử</button><button type="button" class="btn sm" id="cnew">＋ Mới</button>
  </div>
  <div class="chat-main">
    <aside id="hist" class="hist" hidden><b>Lịch sử trò chuyện</b><div id="hlist"></div><button type="button" class="link" id="hclear">Xóa tất cả</button></aside>
    <div class="chat-body">
      <div id="msgs" class="msgs" aria-live="polite">
        <div id="welcome" class="welcome"><h1>Hỏi gì cũng biết</h1><p>Chào bạn, mình là <b>Biết Tuốt</b>! Trợ lý AI thân thiện giúp bạn học tập, làm việc, nấu ăn, du lịch, viết lách và giải đáp mọi thắc mắc.</p>
          <div class="tags3"><span>⚡ Nhanh</span><span>🧠 Thông minh</span><span>🔬 Chuyên sâu</span></div>
          <p class="muted">Thử hỏi ngay:</p>
          <div class="sugs"><?php foreach (['Gợi ý thực đơn cơm gia đình 3 món dễ nấu', 'Giải thích lạm phát bằng ví dụ đơn giản', 'Lên kế hoạch học tiếng Anh trong 3 tháng', 'Đi Đà Lạt 3 ngày 2 đêm cần chuẩn bị gì?', 'Viết email xin nghỉ phép lịch sự', 'Mẹo bảo quản rau củ lâu hơn'] as $s): ?><button type="button" class="sug"><?=e($s)?></button><?php endforeach; ?></div></div>
      </div>
      <?php if ($tsSite !== ''): ?><div id="tsgate" class="card center"><p><b>Xác minh nhanh</b> để dùng Trợ lý AI (chống bot):</p><div class="cf-turnstile" data-sitekey="<?=e($tsSite)?>" data-callback="btTs"></div><script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script></div><?php endif; ?>
      <div id="cprev" class="cprev" hidden></div>
      <form id="cform" class="composer"><?php if ($image): ?><button type="button" class="btn ghost" id="cattach" title="Đính kèm ảnh" aria-label="Đính kèm ảnh">📎</button><input type="file" id="cimg" accept="image/*" hidden><?php endif; ?><textarea id="cin" rows="1" maxlength="2000" placeholder="Nhập câu hỏi của bạn… (Enter để gửi, Shift+Enter xuống dòng)" aria-label="Câu hỏi"></textarea><button class="btn" id="csend">Gửi</button></form>
      <p class="muted small center">Biết Tuốt có thể mắc lỗi. Hãy kiểm tra lại thông tin quan trọng. <?=$sync ? 'Cuộc trò chuyện được lưu trong tài khoản của bạn (xóa được bất cứ lúc nào).' : 'Cuộc trò chuyện được lưu trên thiết bị của bạn.'?> <?php if (!$loggedIn): ?><a href="/dang-nhap">Đăng nhập</a> để có thêm lượt và chế độ Chuyên sâu.<?php endif; ?><?php if (!$serverAi): ?><br><b>⚠ Trợ lý chưa được cấu hình AI.</b> Quản trị viên: thêm AI tại Admin → AI.<?php endif; ?></p>
    </div>
  </div>
</div>
<script src="/assets/chat.js" defer></script>
