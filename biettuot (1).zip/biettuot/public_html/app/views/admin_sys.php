<h1>Hệ thống</h1><?=admin_nav()?>
<?php $act = fn(string $a, array $h = [], string $label = '', string $cls = 'btn sm', string $confirm = '') => '<form method="post" action="/admin/he-thong/act" class="inline"'.($confirm ? ' data-confirm="'.e($confirm).'"' : '').'>'.csrf_field().'<input type="hidden" name="act" value="'.e($a).'">'.implode('', array_map(fn($k, $v) => '<input type="hidden" name="'.e($k).'" value="'.e($v).'">', array_keys($h), $h)).'<button class="'.$cls.'">'.e($label).'</button></form>'; ?>

<?php if ($t === 'thongke'): ?>
<?php foreach ($alerts as $al): ?><div class="flash err">⚠️ <?=e($al)?></div><?php endforeach; if (!$alerts): ?><div class="flash ok">✔ Không có cảnh báo.</div><?php endif; ?>
<div class="stats"><?php foreach (['users' => 'Thành viên', 'new7' => 'Mới 7 ngày', 'q7' => 'Câu hỏi 7 ngày', 'a7' => 'Trả lời 7 ngày', 'dau' => 'Hoạt động hôm nay', 'mau' => 'Hoạt động 30 ngày'] as $k => $l): ?><div class="stat"><small><?=$l?></small><b><?=number_format($kpi[$k])?></b></div><?php endforeach; ?></div>
<h2>14 ngày gần đây <small class="muted">(<span class="lg q"></span> câu hỏi · <span class="lg a"></span> trả lời)</small></h2>
<?php $mx = max(1, ...array_values(array_map(fn($v) => max($v['q'], $v['a']), $days))); ?>
<div class="bars"><?php foreach ($days as $dd => $v): ?><div class="bar" title="<?=e($dd)?>: <?=$v['q']?> hỏi, <?=$v['a']?> đáp"><div class="cols"><i class="q" style="height:<?=round($v['q'] / $mx * 100)?>%"></i><i class="a" style="height:<?=round($v['a'] / $mx * 100)?>%"></i></div><small><?=e(date('d', strtotime($dd)))?></small></div><?php endforeach; ?></div>
<h2>Điểm & quỹ tháng này</h2>
<div class="stats"><div class="stat"><small>Điểm đã phát</small><b><?=number_format($pts['issued'])?></b></div><div class="stat"><small>Điểm đã đổi</small><b><?=number_format($pts['spent'])?></b></div>
<div class="stat"><small>Điểm đang lưu hành</small><b><?=number_format($pts['outstanding'])?></b></div><div class="stat"><small>Nghĩa vụ tối đa (ước tính)</small><b><?=number_format($pts['outstanding'] * $pts['vnd'])?>đ</b></div>
<div class="stat"><small>Quà đã chi tháng này</small><b><?=number_format($redeemVnd)?>đ</b></div></div>
<h2>AI 7 ngày qua</h2><table><tr><th>AI</th><th>Thành công</th><th>Tổng gọi</th><th>Tỷ lệ</th></tr><?php foreach ($ai as $x): ?><tr><td><?=e($x['provider'])?></td><td><?=(int)$x['ok']?></td><td><?=(int)$x['n']?></td><td><?=$x['n'] ? round($x['ok'] / $x['n'] * 100) : 0?>%</td></tr><?php endforeach; ?></table>

<?php elseif ($t === 'gianlan'): ?>
<p class="muted">Các dấu hiệu dưới đây chỉ là gợi ý để bạn kiểm tra thủ công, không phải kết luận. Mạng dùng chung (trường học, quán net, công ty) có thể gây báo nhầm.</p>
<h2>Nhiều tài khoản cùng mạng (14 ngày)</h2><table><tr><th>IP</th><th>Số TK</th><th>Tài khoản</th></tr><?php foreach ($ips as $x): ?><tr><td><?=e($x['ip'])?></td><td><?=(int)$x['n']?></td><td><?=e($x['names'])?></td></tr><?php endforeach; ?></table>
<h2>Bình chọn qua lại (nghi vòng bình chọn)</h2><table><tr><th>A</th><th>B</th><th>A→B</th><th>B→A</th><th></th></tr><?php foreach ($rings as $x): ?><tr><td><?=e($x['na'])?></td><td><?=e($x['nb'])?></td><td><?=(int)$x['ab']?></td><td><?=(int)$x['ba']?></td>
<td><a href="/admin/diem?t=user&s=<?=e(urlencode($x['na']))?>">Xem A</a> · <a href="/admin/diem?t=user&s=<?=e(urlencode($x['nb']))?>">Xem B</a></td></tr><?php endforeach; ?></table>
<h2>Một người bình chọn dồn cho một người (≥ 8 lượt)</h2><table><tr><th>Người bình chọn</th><th>Tác giả</th><th>Lượt</th></tr><?php foreach ($heavy as $x): ?><tr><td><?=e($x['na'])?></td><td><?=e($x['nb'])?></td><td><?=(int)$x['c']?></td></tr><?php endforeach; ?></table>
<h2>Tài khoản mới kiếm điểm nhanh (&lt; 7 ngày, ≥ 150 điểm đóng góp)</h2><table><tr><th>Tài khoản</th><th>Điểm</th><th>Đóng góp</th><th></th></tr><?php foreach ($fast as $x): ?><tr><td><?=e($x['username'])?></td><td><?=(int)$x['points']?></td><td><?=(int)$x['xp']?></td>
<td><form method="post" action="/admin/diem/act" class="inline" data-confirm="Khóa tài khoản này?"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><button class="btn sm ghost" name="act" value="user_ban">Khóa</button></form></td></tr><?php endforeach; ?></table>

<?php elseif ($t === 'noidung'): ?>
<h2>📌 Câu hỏi của ngày</h2><p><?=$qotd ? '<a href="'.e(qurl($qotd)).'">'.e($qotd['title']).'</a>' : '<span class="muted">Chưa có</span>'?></p>
<form method="post" action="/admin/he-thong/act" class="inline wide"><?=csrf_field()?><input type="hidden" name="act" value="qotd_set"><input type="number" name="id" placeholder="ID câu hỏi muốn đặt làm câu hỏi của ngày"><button class="btn sm">Đặt</button></form>
<h2>📰 Câu hỏi nổi bật - biến thành bài viết</h2>
<?php foreach ($hot as $x): ?><div class="card"><a href="/hoi/x-<?=(int)$x['id']?>" target="_blank"><?=e($x['title'])?></a> <span class="meta">· <?=(int)$x['views']?> lượt xem · <?=(int)$x['answers_count']?> trả lời</span><?=$act('article_gen', ['id' => $x['id']], 'Tạo bài nháp bằng AI')?></div><?php endforeach; if (!$hot): ?><p class="muted">Chưa có câu hỏi phù hợp.</p><?php endif; ?>
<?php if ($edit): ?><h2>Sửa bài #<?=(int)$edit['id']?></h2><form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="article_save"><input type="hidden" name="id" value="<?=(int)$edit['id']?>">
<input name="title" maxlength="200" value="<?=e($edit['title'])?>"><textarea name="body" rows="16"><?=e($edit['body'])?></textarea><button class="btn">Lưu</button></form><?php endif; ?>
<h2>Bài viết <a class="btn sm" href="/ctv/bai-viet/moi">＋ Viết bài mới</a></h2><table><tr><th>Tiêu đề</th><th>Lĩnh vực</th><th>Tác giả</th><th>Trạng thái</th><th></th></tr><?php foreach ($arts as $x): ?><tr><td><a href="/bai-viet/<?=(int)$x['id']?>" target="_blank"><?=e($x['title'])?></a></td><td><?=e($x['cat'] ?? '')?></td><td><?=e($x['username'] ?? 'AI')?></td><td><?=['draft' => 'Nháp', 'pending' => '⏳ Chờ duyệt', 'published' => 'Đã đăng'][$x['status']] ?? e($x['status'])?></td>
<td><a class="btn sm ghost" href="/ctv/bai-viet/<?=(int)$x['id']?>/sua">Sửa</a> <?=$x['status'] !== 'published' ? $act('article_pub', ['id' => $x['id']], 'Duyệt & đăng') : $act('article_unpub', ['id' => $x['id']], 'Gỡ', 'btn sm ghost')?> <?=$act('article_del', ['id' => $x['id']], 'Xóa', 'btn sm ghost', 'Xóa bài viết này?')?></td></tr><?php endforeach; ?></table>
<h2>🎯 Đố vui</h2>
<form method="post" action="/admin/he-thong/act" class="inline wide"><?=csrf_field()?><input type="hidden" name="act" value="quiz_gen"><input name="topic" placeholder="Chủ đề để AI tạo 5 câu (ví dụ: khoa học, địa lý)"><button class="btn sm">Tạo bằng AI</button></form>
<form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="quiz_add"><b>Thêm câu đố thủ công</b><input name="question" placeholder="Câu hỏi" required>
<?php for ($i = 1; $i <= 4; $i++): ?><input name="opt<?=$i?>" placeholder="Đáp án <?=$i?>" required><?php endfor; ?><select name="answer"><?php for ($i = 0; $i < 4; $i++): ?><option value="<?=$i?>">Đáp án đúng: <?=$i + 1?></option><?php endfor; ?></select><input name="explain" placeholder="Giải thích"><button class="btn">Thêm</button></form>
<table><?php foreach ($quizzes as $x): ?><tr><td><?=e($x['question'])?></td><td><?=$act('quiz_del', ['id' => $x['id']], 'Xóa', 'btn sm ghost', 'Xóa câu đố?')?></td></tr><?php endforeach; ?></table>

<?php elseif ($t === 'doisoat'): ?>
<form method="get" class="inline wide"><input type="hidden" name="t" value="doisoat"><input type="month" name="m" value="<?=e($m)?>"><button class="btn sm">Xem</button><a class="btn sm ghost" href="/admin/xuat-csv?m=<?=e($m)?>">⬇ Xuất CSV</a></form>
<div class="stats"><div class="stat"><small>Đơn đã gửi quà (<?=e($m)?>)</small><b><?=count($rows)?></b></div><div class="stat"><small>Tổng giá trị</small><b><?=number_format((int)array_sum(array_column($rows, 'vnd_value')))?>đ</b></div>
<div class="stat"><small>Đơn đang chờ (giá trị)</small><b><?=number_format($pendingVnd)?>đ</b></div><div class="stat"><small>Nghĩa vụ điểm tối đa</small><b><?=number_format($outstanding)?>đ</b></div></div>
<p class="muted">Cột "Ghi chú" là mã giao dịch/mã thẻ/mã vận đơn bạn nhập khi bấm "Đã gửi quà" - hãy nhập đầy đủ để đối soát với sao kê và chứng từ kế toán.</p>
<table><tr><th>Đơn</th><th>Thành viên</th><th>Quà</th><th>Loại</th><th>Giá trị</th><th>Ghi chú/mã GD</th><th>Ngày</th></tr><?php foreach ($rows as $x): ?><tr><td>#<?=(int)$x['id']?></td><td><?=e($x['username'])?></td><td><?=e($x['wname'])?></td><td><?=e($x['type'])?></td><td><?=number_format((int)$x['vnd_value'])?>đ</td><td><?=e($x['admin_note'])?></td><td><?=e($x['updated_at'])?></td></tr><?php endforeach; ?></table>

<?php elseif ($t === 'quangcao'): ?>
<form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="ads_save"><h2>Vị trí quảng cáo</h2>
<label>Đầu trang chủ (dán mã quảng cáo HTML, để trống = tắt)<textarea name="ad_top" rows="3"><?=e($ad['top'])?></textarea></label>
<label>Giữa nội dung (danh sách và trang câu hỏi)<textarea name="ad_inline" rows="3"><?=e($ad['inline'])?></textarea></label>
<label>Hướng dẫn thanh toán Premium (hiển thị cho người dùng)<textarea name="premium_pay_info" rows="3"><?=e($ad['pay'])?></textarea></label><button class="btn">Lưu</button></form>
<p class="muted">Chỉ dán mã từ nguồn bạn tin cậy (ví dụ Google AdSense): mã này chạy trực tiếp trên trang. Thành viên Premium không thấy quảng cáo.</p>
<h2>Liên kết tiếp thị</h2>
<form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="aff_add"><input name="name" placeholder="Tên" required><input name="url" placeholder="https://… (liên kết tiếp thị)" required><input name="text" placeholder="Mô tả ngắn">
<select name="category_id"><option value="0">Mọi chuyên mục</option><?php foreach ($cats as $c): ?><option value="<?=(int)$c['id']?>"><?=e($c['name'])?></option><?php endforeach; ?></select><button class="btn">Thêm</button></form>
<table><tr><th>Tên</th><th>Lượt bấm</th><th></th></tr><?php foreach ($affs as $x): ?><tr><td><?=e($x['name'])?></td><td><?=(int)$x['clicks']?></td><td><?=$act('aff_toggle', ['id' => $x['id']], $x['active'] ? 'Đang bật · Tắt' : 'Đang tắt · Bật', 'btn sm ghost')?></td></tr><?php endforeach; ?></table>
<h2>Yêu cầu Premium chờ xác nhận (<?=count($reqs)?>) · đang Premium: <?=(int)$premCount?></h2>
<?php foreach ($reqs as $x): ?><div class="card"><b><?=e($x['username'])?></b> (<?=e($x['email'])?>) <div class="meta">Gói: <?=e($plans[$x['plan']]['name'] ?? $x['plan'])?> · Ghi chú: <?=e($x['note'])?> · <?=e(ago($x['created_at']))?></div><?=$act('prem_ok', ['id' => $x['id']], 'Kích hoạt gói')?> <?=$act('prem_no', ['id' => $x['id']], 'Từ chối', 'btn sm ghost')?></div><?php endforeach; ?>

<?php elseif ($t === 'ctv'): ?>
<p class="muted">Chương trình cộng tác viên: duyệt đơn, phân công lĩnh vực phụ trách. CTV được viết/sửa bài trong lĩnh vực của mình và nhận chia sẻ doanh thu (tab "Chia doanh thu CTV").</p>
<h2>Đơn ứng tuyển chờ duyệt (<?=count($apps)?>)</h2>
<?php foreach ($apps as $x): ?><div class="card"><b><?=e($x['username'])?></b> (<?=e($x['email'])?>) · <?=(int)$x['xp']?> điểm đóng góp<div class="meta">Muốn phụ trách: <?=e($x['areas'])?> · <?=e(ago($x['created_at']))?></div><p><?=nl2br(e($x['experience']))?></p>
<form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><span class="muted">Phân công lĩnh vực (bỏ trống = tất cả):</span>
<div class="chips"><?php foreach ($cats as $c): ?><label class="chk"><input type="checkbox" name="cats[]" value="<?=(int)$c['id']?>"> <?=e($c['icon'].' '.$c['name'])?></label><?php endforeach; ?></div>
<div class="acts"><button class="btn sm" name="act" value="ctv_ok">Duyệt làm CTV</button><button class="btn sm ghost" name="act" value="ctv_no">Từ chối</button></div></form></div><?php endforeach; ?>
<h2>Cộng tác viên hiện tại (<?=count($ctvs)?>)</h2>
<table><tr><th>CTV</th><th>Lĩnh vực</th><th>Bài đã đăng</th><th>Lượt xem tháng</th><th></th></tr><?php foreach ($ctvs as $x): ?><tr><td><?=e($x['username'])?><br><small class="muted"><?=e($x['email'])?></small></td><td><?=e($x['cats'] ?: 'Tất cả')?></td><td><?=(int)$x['arts']?></td><td><?=number_format((int)$x['vm'])?></td>
<td><a class="btn sm ghost" href="/admin/diem?t=user&s=<?=e(urlencode($x['username']))?>">Đổi lĩnh vực</a> <?=$act('ctv_remove', ['id' => $x['id']], 'Gỡ CTV', 'btn sm ghost', 'Gỡ vai trò cộng tác viên của '.$x['username'].'?')?></td></tr><?php endforeach; ?></table>

<?php elseif ($t === 'chuyenmuc'): ?>
<p class="muted">Thêm/sắp xếp các lĩnh vực hiển thị ở menu, bộ lọc và form đặt câu hỏi. Lĩnh vực "nhạy cảm" sẽ hiện cảnh báo thông tin chỉ mang tính tham khảo.</p>
<form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="cat_add"><b>Thêm lĩnh vực</b><input name="name" placeholder="Tên lĩnh vực" required><input name="icon" maxlength="8" placeholder="Biểu tượng (1 emoji)"><input name="description" placeholder="Mô tả ngắn"><input type="number" name="sort_order" value="50" placeholder="Thứ tự"><label class="chk"><input type="checkbox" name="sensitive" value="1"> Lĩnh vực nhạy cảm</label><button class="btn">Thêm</button></form>
<?php foreach ($allcats as $c): ?><div class="card"><form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$c['id']?>">
<div class="inline wide"><input name="icon" maxlength="8" value="<?=e($c['icon'])?>" style="max-width:70px"><input name="name" value="<?=e($c['name'])?>"><input type="number" name="sort_order" value="<?=(int)$c['sort_order']?>" style="max-width:90px"><label class="chk"><input type="checkbox" name="sensitive" value="1" <?=$c['is_sensitive'] ? 'checked' : ''?>> Nhạy cảm</label></div>
<label>Quy tắc/tính cách riêng cho AI ở lĩnh vực này (áp dụng cho trợ lý chat, AI trả lời và soạn bài)<textarea name="ai_prompt" rows="2" maxlength="1500" placeholder="Ví dụ: Luôn gợi ý nguyên liệu thay thế; không khuyên dùng thuốc..."><?=e($c['ai_prompt'] ?? '')?></textarea></label>
<label>Giới thiệu dài cho trang chuyên mục (SEO; ## tiêu đề, - gạch đầu dòng)<textarea name="long_desc" rows="3" maxlength="4000"><?=e($c['long_desc'] ?? '')?></textarea></label>
<div class="acts"><button class="btn sm" name="act" value="cat_save">Lưu</button><button class="btn sm ghost" name="act" value="cat_toggle"><?=$c['active'] ? 'Đang hiện · Ẩn' : 'Đang ẩn · Hiện'?></button><span class="meta"><?=(int)$c['qn']?> câu hỏi · <?=(int)$c['an']?> bài viết</span></div></form></div><?php endforeach; ?>

<?php elseif ($t === 'uudai'): ?>
<h2>🎁 Chương trình tặng điểm lễ, Tết</h2>
<p class="muted">Mọi thành viên (tài khoản ≥ 3 ngày) nhận quà một lần cho mỗi dịp mỗi năm khi truy cập trong thời gian diễn ra; thành viên Premium nhận thêm "điểm thưởng Premium". "Lặp hằng năm" so sánh theo ngày-tháng dương lịch (không dùng cho khoảng vắt qua năm mới). <b>Tết Nguyên Đán đổi ngày dương lịch mỗi năm: hãy tạo sự kiện riêng cho từng năm (bỏ chọn "lặp hằng năm") và kiểm tra lại ngày.</b></p>
<table><tr><th>Dịp</th><th>Từ</th><th>Đến</th><th>Lặp</th><th>Điểm</th><th>+Premium</th><th></th></tr><?php foreach ($events as $x): ?><tr><td><?=e($x['name'])?></td><td><?=e($x['start_date'])?></td><td><?=e($x['end_date'])?></td><td><?=$x['recurring'] ? '✔' : ''?></td><td><?=(int)$x['bonus_points']?></td><td><?=(int)$x['premium_bonus']?></td>
<td><?=$act('holiday_toggle', ['id' => $x['id']], $x['active'] ? 'Đang bật · Tắt' : 'Đang tắt · Bật', 'btn sm ghost')?></td></tr><?php endforeach; ?></table>
<form method="post" action="/admin/he-thong/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="holiday_add"><b>Thêm dịp</b><input name="name" placeholder="Tên dịp (ví dụ: Tết Nguyên Đán 2028)" required>
<label>Từ ngày<input type="date" name="start_date" required></label><label>Đến ngày<input type="date" name="end_date" required></label><label class="chk"><input type="checkbox" name="recurring" value="1"> Lặp hằng năm (theo ngày-tháng)</label>
<input type="number" name="bonus_points" placeholder="Điểm tặng mọi thành viên" required><input type="number" name="premium_bonus" placeholder="Điểm tặng thêm cho Premium" value="0"><button class="btn">Thêm</button></form>
<h2>💎 Gói Premium (đang cấu hình trong config)</h2><div class="stats"><?php foreach ($plans as $k => $p): ?><div class="stat"><small><?=e($p['name'])?></small><b><?=number_format((int)$p['price'])?>đ</b><small><?=(int)$p['days']?> ngày</small></div><?php endforeach; ?><div class="stat"><small>Đang Premium</small><b><?=(int)$premCount?></b></div></div>
<p class="muted">Đổi giá/thời hạn/hệ số điểm trong <code>config.local.php</code> mục <code>'premium' =&gt; ['multiplier' =&gt; 1.5, 'plans' =&gt; [...]]</code>. Ngày sinh: thành viên tự nhập một lần ở Cài đặt; quà sinh nhật cấu hình ở <code>points.birthday</code>.</p>

<?php else: ?>
<div class="stats"><div class="stat"><small>Gửi email qua</small><b style="font-size:1rem"><?=e($mailOk)?></b></div>
<?php foreach (['pending' => 'Tác vụ chờ', 'running' => 'Đang chạy', 'done' => 'Hoàn tất', 'failed' => 'Thất bại'] as $k => $l): ?><div class="stat"><small><?=$l?></small><b><?=(int)($jobs[$k] ?? 0)?></b></div><?php endforeach; ?></div>
<?php if ($failed): ?><?=$act('retry_jobs', [], 'Thử lại tác vụ thất bại')?><?php endif; ?>
<h2>Cron (khuyên dùng)</h2><p class="muted">Trong hPanel → Advanced → Cron Jobs, đặt chạy mỗi 5 phút lệnh: <code>curl -s "<?=e($cron ?: 'https://tenmien/cron?key=CRON_KEY (hãy đặt cron_key trong config)')?>" &gt;/dev/null</code></p>
<h2>Thông báo đẩy (Web Push)</h2><p class="muted">Khóa VAPID: <?=$vapid ? 'đã tạo' : 'chưa tạo'?>. Sau khi tạo, đặt <code>'push' =&gt; ['enabled' =&gt; true]</code> trong config.local.php.</p><?=$act('vapid_gen', [], $vapid ? 'Tạo lại khóa (làm mất đăng ký cũ)' : 'Tạo khóa VAPID', 'btn sm', $vapid ? 'Tạo lại khóa sẽ vô hiệu hóa mọi đăng ký push hiện có. Tiếp tục?' : '')?>
<h2>Cơ sở dữ liệu</h2><p class="muted">Đồng bộ lại cấu trúc CSDL (an toàn chạy nhiều lần; tạo bảng/cột còn thiếu). Phiên bản hiện tại: <?=(int)setting('schema_version', '0')?> / <?=SCHEMA_VERSION?>.</p><?=$act('db_sync', [], 'Cập nhật cơ sở dữ liệu')?>
<h2>Kiểm tra AI</h2><p class="muted">Gửi câu hỏi thử tới từng AI đã cấu hình (quản lý AI tại <a href="/admin/ai">Admin → AI</a>).</p><?=$act('ai_test', [], 'Kiểm tra các AI')?>
<h2>Nhật ký lỗi PHP (30 dòng gần nhất) <?=$act('clear_log', [], 'Xóa nhật ký', 'btn sm ghost')?></h2><pre class="log"><?=e($errlog !== '' ? $errlog : 'Không có lỗi.')?></pre>
<h2>Sao lưu</h2><form method="post" action="/admin/sao-luu"><?=csrf_field()?><button class="btn">⬇ Tải bản sao lưu database (.sql)</button></form><p class="muted">Dùng cho database nhỏ-vừa. Hãy bật thêm backup tự động của Hostinger và lưu bản tải về ở nơi an toàn (file chứa dữ liệu cá nhân và khóa).</p>
<h2>Nhật ký thao tác quản trị</h2><table><tr><th>Giờ</th><th>Ai</th><th>Hành động</th><th>Đối tượng</th><th>Chi tiết</th></tr><?php foreach ($audit as $x): ?><tr><td><?=e($x['created_at'])?></td><td><?=e($x['username'] ?? '')?></td><td><?=e($x['action'])?></td><td><?=e($x['target'])?></td><td><?=e($x['detail'])?></td></tr><?php endforeach; ?></table>
<?php endif; ?>
