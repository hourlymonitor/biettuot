<h1>🤝 Chương trình cộng tác viên</h1>
<p>Cộng tác viên (CTV) là thành viên được Biết Tuốt tin tưởng giao phụ trách một hoặc nhiều <b>lĩnh vực</b>: viết bài, biên tập, kiểm duyệt và nhận <b>chia sẻ doanh thu</b> hằng tháng theo mức đóng góp.</p>
<div class="cards2">
<div class="card"><b>✍️ Quyền hạn</b><ul><li>Viết và đăng bài viết trong lĩnh vực mình phụ trách<?=pc('ctv.publish_directly') ? '' : ' (bài gửi duyệt trước khi đăng)'?></li><li>Chỉnh sửa bài viết trong lĩnh vực đó (có lưu lịch sử chỉnh sửa)</li><li>Duyệt câu hỏi/câu trả lời chờ duyệt, xử lý báo cáo, gộp câu hỏi trùng</li><li>Nhận điểm x<?=e((string)pc('points.collab_multiplier'))?> cho mọi hoạt động</li></ul></div>
<div class="card"><b>💰 Chia sẻ doanh thu</b><ul><li>Mỗi tháng, <?=(int)round((float)pc('ctv.pool_pct') * 100)?>% doanh thu thực nhận được trích làm quỹ chia cho CTV, trả bằng điểm (đổi quà được)</li><li>Tỷ lệ chia theo điểm đóng góp: điểm hoạt động trong tháng + số bài đăng + lượt xem bài viết của bạn</li><li>Bạn xem được tiến độ và lịch sử nhận ở Khu vực CTV</li></ul></div></div>
<p class="muted">Lưu ý: mức chia phụ thuộc doanh thu thực tế và quyết định của quản trị, không bảo đảm có doanh thu. Đây là chương trình cộng tác theo thỏa thuận, không phải quyền sở hữu hay cổ phần của công ty. Nghĩa vụ thuế (nếu có) thuộc về người nhận.</p>
<?php if (!$u): ?><p><a class="btn big" href="/dang-ky">Đăng ký thành viên để ứng tuyển</a> <a href="/dang-nhap">Đăng nhập</a></p>
<?php elseif ($u['role'] === 'collab' || $u['role'] === 'admin'): ?><div class="flash ok">Bạn là <?=$u['role'] === 'admin' ? 'quản trị viên' : 'cộng tác viên'?>.<?=$myCats ? ' Lĩnh vực phụ trách: '.e(implode(', ', $myCats)).'.' : ''?></div><p><a class="btn big" href="/ctv">Vào Khu vực CTV</a></p>
<?php elseif ($app && $app['status'] === 'pending'): ?><div class="flash info">Đơn ứng tuyển của bạn đang chờ xét duyệt.</div>
<?php else: ?><?php if ($app && $app['status'] === 'rejected'): ?><div class="flash err">Đơn trước đây chưa được duyệt. Bạn có thể bổ sung kinh nghiệm và gửi lại.</div><?php endif; ?>
<h2>Ứng tuyển</h2><form method="post" class="form"><?=csrf_field()?>
<label>Lĩnh vực muốn phụ trách<input name="fields" maxlength="255" required placeholder="Ví dụ: Ẩm thực, Du lịch"></label>
<label>Giới thiệu kinh nghiệm / chuyên môn / sản phẩm đã viết<textarea name="experience" rows="6" maxlength="2000" required minlength="20" placeholder="Bạn có thể dán liên kết bài viết đã thực hiện, chứng chỉ, nghề nghiệp…"></textarea></label>
<label class="chk"><input type="checkbox" name="agree" value="1" required> Tôi đã đọc và đồng ý <a href="/dieu-khoan-ctv" target="_blank">Điều khoản cộng tác viên</a></label>
<button class="btn big">Gửi đơn ứng tuyển</button><p class="muted">Cần xác minh email. Quản trị viên sẽ phản hồi qua thông báo và email.</p></form><?php endif; ?>
