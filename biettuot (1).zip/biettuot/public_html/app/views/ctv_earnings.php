<h1>💰 Thu nhập cộng tác viên</h1>
<p class="muted">Bảng kê phần chia sẻ doanh thu bạn đã nhận theo tháng (trả bằng điểm). "Quy đổi ước tính" = điểm × <?=(int)$vp?>đ/điểm, chỉ để tham khảo; giá trị thực tế khi đổi quà có thể khác. Bạn tự chịu trách nhiệm kê khai thuế theo quy định.</p>
<div class="acts"><a class="btn ghost" href="/ctv">← Khu vực CTV</a><a class="btn ghost" href="/ctv/thu-nhap.csv">⬇ Tải CSV</a><button type="button" class="btn ghost" onclick="window.print()">🖨 In bảng kê</button></div>
<table><tr><th>Tháng</th><th>Điểm được chia</th><th>Quy đổi ước tính</th><th>Bài đăng</th><th>Lượt xem bài</th></tr><?php foreach ($rows as $r): ?><tr><td><?=e($r['ym'])?></td><td><b><?=number_format($r['pts'])?></b></td><td><?=number_format($r['vnd'])?>đ</td><td><?=(int)$r['art']?></td><td><?=number_format($r['views'])?></td></tr><?php endforeach; ?>
<?php if ($rows): ?><tr><td><b>Tổng</b></td><td><b><?=number_format(array_sum(array_column($rows, 'pts')))?></b></td><td><b><?=number_format(array_sum(array_column($rows, 'vnd')))?>đ</b></td><td></td><td></td></tr><?php endif; ?></table>
<?php if (!$rows): ?><p class="muted">Chưa có kỳ chia sẻ doanh thu nào.</p><?php endif; ?>
<p class="muted">Tài khoản: <?=e($u['username'])?> · Xuất lúc <?=e(date('d/m/Y H:i'))?></p>
