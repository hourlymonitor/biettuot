<h1>🎛 Bật / tắt tính năng</h1><?=admin_nav()?>
<p class="muted">Bật hoặc tắt từng tính năng của website. Thay đổi có hiệu lực ngay. Quản trị viên vẫn truy cập được trang của tính năng đang tắt để kiểm tra.</p>
<form method="post" class="form"><?=csrf_field()?>
<div class="acts"><button class="btn" name="mode" value="save">💾 Lưu thay đổi</button><button class="btn ghost" name="mode" value="on" data-confirm-btn="Bật TẤT CẢ tính năng (trừ chế độ bảo trì)?">Bật tất cả</button><button class="btn ghost" name="mode" value="off" data-confirm-btn="Tắt các tính năng mở rộng (giữ nhóm Cốt lõi)?">Tắt các tính năng mở rộng</button></div>
<?php foreach ($groups as $gk => $gl): ?><h2><?=e($gl)?></h2><div class="featgrid">
<?php foreach ($defs as $k => $d): if ($d[0] !== $gk) continue; ?><label class="feat-row"><span class="fr-text"><b><?=e($d[1])?></b><?php if ($d[2] !== ''): ?><small><?=e($d[2])?></small><?php endif; ?></span>
<span class="switch"><input type="checkbox" name="f[<?=e($k)?>]" value="1" <?=feature($k) ? 'checked' : ''?>><i></i></span></label><?php endforeach; ?></div><?php endforeach; ?>
<div class="acts"><button class="btn" name="mode" value="save">💾 Lưu thay đổi</button></div></form>
