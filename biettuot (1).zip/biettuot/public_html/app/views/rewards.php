<h1>Đổi quà tặng</h1>
<?php if ($me): $t = tier_of((int)$me['xp']); ?><p>Điểm khả dụng của bạn: <b><?=number_format((int)$me['points'])?></b> · Cấp bậc: <?=tier_badge($me)?> · <a href="/vi">Xem ví</a></p>
<?php else: ?><p><a href="/dang-nhap">Đăng nhập</a> để đổi quà.</p><?php endif; ?>
<p class="muted">Điều kiện chung: tài khoản hoạt động từ <?=(int)pc('redeem.min_age_days')?> ngày, đã đăng ít nhất <?=(int)pc('redeem.min_contrib')?> câu hỏi/câu trả lời, tối đa <?=(int)pc('redeem.max_per_day')?> lượt đổi mỗi ngày. Quà có số lượng và quỹ giới hạn mỗi tháng; đơn được quản trị viên xét duyệt, có thể cần xác minh danh tính với quà là tiền.</p>
<?php $tn = array_column(tiers(), 'name'); foreach ($rw as $w): ?>
<div class="card"><b><?=['item' => '🎁', 'cash' => '💵', 'phonecard' => '📱'][$w['type']]?> <?=e($w['name'])?></b> <span class="badge ok"><?=number_format((int)$w['cost_points'])?> điểm</span>
  <?php if ((int)$w['min_tier'] > 0): ?><span class="badge">Từ cấp <?=e($tn[$w['min_tier']] ?? '')?></span><?php endif; ?>
  <?=(int)$w['stock'] >= 0 ? '<span class="badge">Còn '.(int)$w['stock'].'</span>' : ''?>
  <div class="meta"><?=e($w['description'])?></div>
  <?php if ($me): ?><form method="post" action="/doi-qua" class="inline wide"><?=csrf_field()?><input type="hidden" name="reward_id" value="<?=(int)$w['id']?>">
    <input name="contact" placeholder="SĐT/Zalo, địa chỉ hoặc tài khoản nhận" maxlength="255" required value="<?=e($me['payout_info'])?>"><button class="btn sm" <?=(int)$w['stock'] === 0 ? 'disabled' : ''?>>Đổi</button></form><?php endif; ?></div>
<?php endforeach; if (!$rw): ?><p class="muted">Chưa có quà nào.</p><?php endif; ?>
