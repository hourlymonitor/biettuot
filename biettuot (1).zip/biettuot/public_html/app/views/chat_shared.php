<h1>💬 <?=e($t['title'])?></h1>
<p class="muted">Cuộc trò chuyện do một thành viên chia sẻ. Nội dung do AI tạo, chỉ mang tính tham khảo. <a href="/tro-ly">Hỏi Trợ lý AI →</a></p>
<div class="shared"><?php foreach ($m as $x): ?><div class="msg <?=$x['role'] === 'user' ? 'user' : 'assistant'?>"><?php if ($x['role'] !== 'user'): ?><div class="av">🤖</div><?php endif; ?><div class="bub"><?=$x['role'] === 'user' ? '<p>'.nl2br(e($x['content'])).'</p>' : md_lite($x['content'])?></div></div><?php endforeach; ?></div>
