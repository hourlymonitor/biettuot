<h1>🎯 Đố vui hằng ngày</h1>
<?php if (!$quiz): ?><p class="muted">Chưa có câu đố nào.</p><?php else: ?>
<div class="card"><b><?=e($quiz['question'])?></b>
<?php if ($mine): ?>
  <?php foreach ($quiz['opts'] as $i => $o): ?><div class="opt <?=$i === (int)$quiz['answer_idx'] ? 'right' : ($i === (int)$mine['choice'] ? 'wrong' : '')?>"><?=e($o)?><?=$i === (int)$quiz['answer_idx'] ? ' ✔' : ''?></div><?php endforeach; ?>
  <p><?=$mine['correct'] ? '🎉 Bạn trả lời đúng!' : 'Rất tiếc, lần sau nhé.'?> <?=e($quiz['explanation'])?></p><p class="muted">Quay lại vào ngày mai để có câu đố mới.</p>
<?php elseif (!me()): ?><p><a href="/dang-nhap">Đăng nhập</a> để trả lời và nhận điểm.</p>
<?php else: ?><form method="post" action="/do-vui" class="opts"><?=csrf_field()?><?php foreach ($quiz['opts'] as $i => $o): ?><button class="btn ghost opt" name="choice" value="<?=$i?>"><?=e($o)?></button><?php endforeach; ?></form><?php endif; ?></div><?php endif; ?>
