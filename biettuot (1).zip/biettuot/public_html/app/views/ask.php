<h1>Đặt câu hỏi</h1>
<?php if (!empty($err)): ?><div class="flash err"><?=e($err)?></div><?php endif; $old = $old ?? []; ?>
<form method="post" action="/hoi-moi" class="form" id="askf"><?=csrf_field()?>
  <input type="text" name="hp_note" class="hp" tabindex="-1" autocomplete="off">
  <label>Chuyên mục<select name="category" required><option value="">- Chọn -</option>
    <?php foreach (cats() as $c): ?><option value="<?=(int)$c['id']?>" <?=((int)($old['cid'] ?? 0) === (int)$c['id']) ? 'selected' : ''?>><?=e($c['name'])?></option><?php endforeach; ?></select></label>
  <label>Câu hỏi của bạn<input id="title" name="title" maxlength="200" required autocomplete="off" placeholder="Ví dụ: Tại sao bầu trời có màu xanh?" value="<?=e($old['title'] ?? '')?>"></label>
  <div id="sim" class="sim"></div>
  <label>Chi tiết (không bắt buộc)<textarea name="body" rows="5" maxlength="5000"><?=e($old['body'] ?? '')?></textarea></label>
  <label>Thẻ (tối đa 5, cách nhau bằng dấu phẩy)<input name="tags" maxlength="150" placeholder="ví dụ: nấu ăn, mẹo vặt" value="<?=e($old['tags'] ?? '')?>"></label>
  <?=turnstile_widget()?>
  <button class="btn big">Gửi câu hỏi</button><p class="muted">AI sẽ soạn câu trả lời đầu tiên ngay sau khi bạn gửi (mất vài giây).</p>
</form>
