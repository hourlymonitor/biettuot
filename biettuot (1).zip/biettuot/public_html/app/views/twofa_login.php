<h1>🔐 Xác thực hai lớp</h1>
<?php if (!empty($err)): ?><div class="flash err"><?=e($err)?></div><?php endif; ?>
<form method="post" class="form narrow"><?=csrf_field()?><label>Mã 6 số từ ứng dụng xác thực (hoặc một mã khôi phục)<input name="code" inputmode="numeric" autocomplete="one-time-code" autofocus required placeholder="123 456"></label><button class="btn big">Xác nhận</button>
<p class="muted">Mất điện thoại? Dùng một mã khôi phục đã lưu khi bật 2FA (mỗi mã chỉ dùng được một lần).</p></form>
