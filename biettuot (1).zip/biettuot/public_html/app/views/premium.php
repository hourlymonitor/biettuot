<h1>💎 Gói Premium</h1>
<p class="muted">Thành viên trả phí nhận nhiều điểm hơn, nhiều lượt AI hơn và nhiều ưu đãi hơn. Thanh toán bằng chuyển khoản (mã QR); Premium được kích hoạt ngay khi hệ thống nhận được tiền (hoặc sau khi quản trị viên xác nhận).</p>
<?php if (is_premium($me)): ?><div class="flash ok">Bạn đang dùng Premium đến <?=e(date('d/m/Y', strtotime($me['premium_until'])))?>. Gia hạn bằng cách gửi yêu cầu mới.</div><?php endif; ?>
<div class="card"><b>Quyền lợi Premium</b><ul>
<li>Nhận điểm <b>x<?=e((string)pc('premium.multiplier'))?></b> cho mọi hoạt động; hạn mức điểm mỗi ngày x<?=(int)pc('premium.caps_multiplier')?></li>
<li>Quà sinh nhật <b><?=(int)pc('points.birthday.premium_bonus')?> điểm</b> (thay vì <?=(int)pc('points.birthday.bonus')?>) và thêm điểm trong các dịp lễ, Tết</li>
<li>Trợ lý AI: <?=(int)pc('premium.chat_per_day')?> lượt/ngày (thay vì <?=(int)pc('chat.user_per_day')?>); hỏi AI trên câu hỏi: <?=(int)pc('premium.ai_per_user_day')?> lượt/ngày</li>
<li>Đổi quà tối đa <?=(int)pc('premium.redeem_max_per_day')?> lần/ngày; không hiển thị quảng cáo; huy hiệu 💎 Premium</li></ul></div>
<?php $mo = (int)($plans['month']['price'] ?? 0); ?>
<div class="plans"><?php foreach ($plans as $k => $p): ?><div class="plan<?=$k === 'year' ? ' best' : ''?>">
  <?php if ($k === 'year' && $mo > 0 && (int)$p['price'] < $mo * 12): ?><span class="ribbon">Tiết kiệm <?=round((1 - $p['price'] / ($mo * 12)) * 100)?>%</span><?php endif; ?>
  <h3><?=e($p['name'])?></h3><div class="price"><?=number_format((int)$p['price'])?>đ<small> / <?=(int)$p['days'] >= 365 ? 'năm' : (int)$p['days'].' ngày'?></small></div>
  <?php if (!$me): ?><a class="btn" href="/dang-nhap">Đăng nhập để đăng ký</a>
  <?php elseif ($pend): ?><p class="muted">Đang chờ xác nhận thanh toán</p>
  <?php elseif (!empty($payAuto)): ?><form method="post" class="form"><?=csrf_field()?><input type="hidden" name="plan" value="<?=e($k)?>"><input name="coupon" maxlength="30" placeholder="Mã giảm giá (nếu có)" autocomplete="off"><button class="btn">💳 Thanh toán bằng QR</button></form>
  <?php else: ?><form method="post" class="form"><?=csrf_field()?><input type="hidden" name="plan" value="<?=e($k)?>"><input name="note" maxlength="255" placeholder="Mã/ghi chú thanh toán"><button class="btn">Đăng ký <?=e($p['name'])?></button></form><?php endif; ?></div><?php endforeach; ?></div>
<?php if ($info !== ''): ?><h2>Cách thanh toán</h2><div class="body"><?=md_lite($info)?></div><?php endif; ?>
