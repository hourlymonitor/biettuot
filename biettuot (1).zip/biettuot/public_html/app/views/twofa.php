<h1>🔐 Xác thực hai lớp (2FA)</h1>
<?php if (!empty($codes)): ?><div class="card"><b>Mã khôi phục của bạn</b> - lưu ở nơi an toàn, <u>chỉ hiển thị một lần</u>:<pre class="log"><?=e(implode("\n", $codes))?></pre></div><?php endif; ?>
<?php if ($u['totp_enabled']): ?>
<div class="flash ok">✔ Xác thực hai lớp đang <b>bật</b> cho tài khoản này.</div>
<form method="post" class="form card narrow"><?=csrf_field()?><b>Tạo mã khôi phục mới / Tắt 2FA</b><input type="password" name="password" placeholder="Mật khẩu hiện tại" autocomplete="current-password" required><input name="code" inputmode="numeric" placeholder="Mã 6 số hiện tại" required>
<div class="acts"><button class="btn sm ghost" name="act" value="regen">Tạo mã khôi phục mới</button><button class="btn sm" name="act" value="disable" data-confirm-btn="Tắt xác thực hai lớp?">Tắt 2FA</button></div></form>
<?php else: ?>
<p>Thêm một lớp bảo vệ: sau mật khẩu, bạn nhập mã 6 số từ ứng dụng như Google Authenticator, Microsoft Authenticator hoặc Authy.</p>
<div class="card"><b>Bước 1.</b> Trong ứng dụng xác thực, chọn "Thêm tài khoản" → quét mã QR bên dưới (hoặc nhập khóa thủ công):
<div id="qrbox" class="center" style="margin:12px"></div><p class="center">Khóa thủ công: <code><?=e(trim(chunk_split($secret, 4, ' ')))?></code></p></div>
<form method="post" class="form card narrow"><?=csrf_field()?><input type="hidden" name="act" value="enable"><b>Bước 2.</b> Nhập mã 6 số hiển thị trong ứng dụng:<input name="code" inputmode="numeric" required placeholder="123456" autocomplete="one-time-code"><button class="btn">Bật 2FA</button></form>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>(function(){try{new QRCode(document.getElementById('qrbox'),{text:<?=json_encode($uri)?>,width:200,height:200});}catch(e){document.getElementById('qrbox').textContent='(Không tải được mã QR - hãy nhập khóa thủ công)';}})();</script>
<?php endif; ?>
<p><a href="/cai-dat">← Cài đặt</a></p>
