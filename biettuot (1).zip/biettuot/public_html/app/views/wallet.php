<?php $t = tier_of((int)$u['xp']); $nt = next_tier((int)$u['xp']);
$pct = $nt ? max(0, min(100, (int)round((($u['xp'] - $t['min']) / max(1, $nt['min'] - $t['min'])) * 100))) : 100; ?>
<h1>Ví điểm của tôi</h1>
<div class="stats">
  <div class="stat"><small>Điểm khả dụng</small><b><?=number_format((int)$u['points'])?></b></div>
  <div class="stat"><small>Đang giữ chờ xác nhận</small><b><?=number_format($pending)?></b></div>
  <div class="stat"><small>Điểm đóng góp</small><b><?=number_format((int)$u['xp'])?></b></div>
  <div class="stat"><small>Chuỗi điểm danh</small><b><?=(int)$u['streak']?> ngày</b></div>
  <div class="stat"><small>Phần chia sẻ doanh thu</small><b><?=(int)$u['shares']?></b></div>
</div>
<p>Cấp bậc: <?=tier_badge($u)?> <?php if ($nt): ?><span class="muted">- còn <?=number_format($nt['min'] - (int)$u['xp'])?> điểm đóng góp để lên <b><?=e($nt['name'])?></b></span><?php endif; ?></p>
<div class="prog"><i style="width:<?=$pct?>%"></i></div>
<p class="muted">Điểm kiếm được sẽ "đang giữ" vài ngày để chống gian lận, sau đó thành điểm khả dụng. <a href="/qua-tang">Đổi quà →</a></p>

<?php if (feature('challenges')): ?><h2>Thử thách</h2>
<?php foreach ($chs as $c): ?><div class="card"><b><?=e($c['title'])?></b> <span class="badge"><?=['daily' => 'Hằng ngày', 'weekly' => 'Hằng tuần', 'once' => 'Một lần'][$c['period']]?></span>
  <div class="meta">Tiến độ <?=(int)$c['prog']?>/<?=(int)$c['target']?> · thưởng <?=(int)$c['reward']?> điểm</div>
  <div class="prog"><i style="width:<?=(int)round($c['prog'] / max(1, $c['target']) * 100)?>%"></i></div>
  <?php if ($c['claimed']): ?><span class="muted">✔ Đã nhận</span>
  <?php elseif ($c['done']): ?><form method="post" action="/thu-thach/nhan" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$c['id']?>"><button class="btn sm">Nhận thưởng</button></form><?php endif; ?></div>
<?php endforeach; if (!$chs): ?><p class="muted">Chưa có thử thách nào.</p><?php endif; ?>

<?php endif; ?>
<h2>Thông tin nhận quà</h2>
<form method="post" action="/vi/thong-tin" class="form"><?=csrf_field()?><label>Số điện thoại / Zalo / địa chỉ / tài khoản nhận tiền<input name="payout_info" maxlength="255" value="<?=e($u['payout_info'])?>"></label><button class="btn">Lưu</button></form>

<h2>Đơn đổi quà</h2>
<?php foreach ($reds as $r): ?><div class="card"><b>#<?=(int)$r['id']?> · <?=e($r['name'])?></b> · <?=number_format((int)$r['cost_points'])?> điểm · <?=['pending' => '⏳ Chờ xử lý', 'fulfilled' => '✔ Đã gửi quà', 'rejected' => '✘ Từ chối (đã hoàn điểm)'][$r['status']]?>
  <div class="meta"><?=e(ago($r['created_at']))?><?=$r['admin_note'] !== '' ? ' · Ghi chú: '.e($r['admin_note']) : ''?></div></div>
<?php endforeach; if (!$reds): ?><p class="muted">Bạn chưa đổi quà nào.</p><?php endif; ?>

<h2>Lịch sử điểm</h2>
<table><tr><th>Thời gian</th><th>Nội dung</th><th>Điểm</th><th></th></tr>
<?php foreach ($ledger as $l): ?><tr><td><?=e(ago($l['created_at']))?></td><td><?=e(kind_label($l['kind']))?><?=$l['note'] !== '' ? ' - '.e($l['note']) : ''?></td>
<td><b><?=($l['delta'] > 0 ? '+' : '').(int)$l['delta']?></b></td><td class="muted"><?=['pending' => 'đang giữ', 'confirmed' => '', 'reversed' => 'đã thu hồi'][$l['status']]?></td></tr><?php endforeach; ?></table>
