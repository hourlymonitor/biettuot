<h1>Quản trị điểm & quà</h1><?=admin_nav()?>
<?php if ($t === 'qua'): ?>
<p class="muted">Quỹ quà đã dùng tháng này: <b><?=number_format($spent ?? 0)?>đ</b> / <?=number_format((int)pc('redeem.budget_vnd_month'))?>đ</p>
<h2>Đơn chờ xử lý (<?=count($queue)?>)</h2>
<?php foreach ($queue as $r): ?><div class="card"><b>#<?=(int)$r['id']?> · <?=e($r['username'])?> → <?=e($r['wname'])?></b> (<?=number_format((int)$r['vnd_value'])?>đ · <?=number_format((int)$r['cost_points'])?> điểm)
<div class="meta">Nhận quà: <b><?=e($r['contact'])?></b> · <?=e(ago($r['created_at']))?></div>
<form method="post" action="/admin/diem/act" class="inline wide"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><input name="note" placeholder="Ghi chú / mã thẻ / mã giao dịch">
<button class="btn sm" name="act" value="redeem_ok">Đã gửi quà</button><button class="btn sm ghost" name="act" value="redeem_no">Từ chối & hoàn điểm</button></form></div>
<?php endforeach; ?>
<h2>Đã xử lý gần đây</h2><table><?php foreach ($done as $r): ?><tr><td>#<?=(int)$r['id']?></td><td><?=e($r['username'])?></td><td><?=e($r['wname'])?></td><td><?=e($r['status'])?></td><td><?=e($r['admin_note'])?></td></tr><?php endforeach; ?></table>
<h2>Kho quà</h2>
<table><tr><th>Tên</th><th>Loại</th><th>Điểm</th><th>Giá trị</th><th>Kho</th><th>Cấp</th><th></th></tr><?php foreach ($rewards as $w): ?><tr><td><?=e($w['name'])?></td><td><?=e($w['type'])?></td><td><?=(int)$w['cost_points']?></td><td><?=number_format((int)$w['vnd_value'])?>đ</td><td><?=(int)$w['stock']?></td><td><?=(int)$w['min_tier']?></td>
<td><form method="post" action="/admin/diem/act" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$w['id']?>"><button class="btn sm ghost" name="act" value="reward_toggle"><?=$w['active'] ? 'Đang bán · Tắt' : 'Đang tắt · Bật'?></button></form></td></tr><?php endforeach; ?></table>
<form method="post" action="/admin/diem/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="reward_add"><b>Thêm quà</b>
<input name="name" placeholder="Tên quà" required><select name="type"><option value="phonecard">Thẻ điện thoại</option><option value="cash">Tiền</option><option value="item">Vật phẩm</option></select>
<input type="number" name="cost" placeholder="Giá (điểm)" required><input type="number" name="vnd" placeholder="Giá trị thật (đồng) - tính vào quỹ tháng" required><input type="number" name="stock" placeholder="Số lượng (-1 = không giới hạn)" value="-1"><input type="number" name="min_tier" placeholder="Cấp tối thiểu (0-4)" value="0"><input name="desc" placeholder="Mô tả"><button class="btn">Thêm</button></form>
<?php elseif ($t === 'thuthach'): ?>
<table><tr><th>Thử thách</th><th>Chỉ số</th><th>Mục tiêu</th><th>Chu kỳ</th><th>Thưởng</th><th></th></tr><?php foreach ($chs as $c): ?><tr><td><?=e($c['title'])?></td><td><?=e($c['metric'])?></td><td><?=(int)$c['target']?></td><td><?=e($c['period'])?></td><td><?=(int)$c['reward']?></td>
<td><form method="post" action="/admin/diem/act" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$c['id']?>"><button class="btn sm ghost" name="act" value="ch_toggle"><?=$c['active'] ? 'Đang bật · Tắt' : 'Đang tắt · Bật'?></button></form></td></tr><?php endforeach; ?></table>
<form method="post" action="/admin/diem/act" class="form"><?=csrf_field()?><input type="hidden" name="act" value="ch_add"><b>Thêm thử thách</b><input name="title" placeholder="Tên thử thách" required>
<select name="metric"><option value="answers">Số câu trả lời</option><option value="questions">Số câu hỏi</option><option value="upvotes">Lượt bình chọn nhận được</option><option value="best">Câu trả lời tốt nhất</option><option value="checkins">Ngày điểm danh</option></select>
<input type="number" name="target" placeholder="Mục tiêu" required><select name="period"><option value="daily">Hằng ngày</option><option value="weekly">Hằng tuần</option><option value="once">Một lần</option></select><input type="number" name="reward" placeholder="Điểm thưởng" required><button class="btn">Thêm</button></form>
<?php elseif ($t === 'user'): ?>
<form class="search" method="get"><input type="hidden" name="t" value="user"><input name="s" placeholder="Tìm tên hoặc email" value="<?=e($s ?? '')?>"></form>
<?php foreach ($users as $x): ?><div class="card"><b><?=e($x['username'])?></b> · <?=e($x['email'])?> <?=tier_badge($x)?> <?=$x['banned'] ? '<span class="badge">ĐÃ KHÓA</span>' : ''?>
<div class="meta">Điểm <?=number_format((int)$x['points'])?> · Đóng góp <?=number_format((int)$x['xp'])?> · Phần <?=(int)$x['shares']?> · Vai trò <?=e($x['role'])?> · <?=e(ago($x['created_at']))?></div>
<form method="post" action="/admin/diem/act" class="inline wide"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><input name="title" placeholder="Danh hiệu chuyên gia đã xác minh (để trống = bỏ)" value="<?=e($x['expert_title'] ?? '')?>" maxlength="80"><button class="btn sm ghost" name="act" value="user_expert">✔ Lưu danh hiệu</button></form>
<?php if ($x['role'] !== 'admin'): ?><form method="post" action="/admin/diem/act" class="inline wide"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>">
<button class="btn sm ghost" name="act" value="user_role" onclick="this.form.role.value='<?=$x['role'] === 'collab' ? 'user' : 'collab'?>'"><?=$x['role'] === 'collab' ? 'Bỏ CTV' : 'Cấp CTV'?></button><input type="hidden" name="role" value="">
<button class="btn sm ghost" name="act" value="<?=$x['banned'] ? 'user_unban' : 'user_ban'?>"><?=$x['banned'] ? 'Mở khóa' : 'Khóa'?></button><?php if (!$x['email_verified']): ?><button class="btn sm ghost" name="act" value="user_verify">Xác minh email</button><?php endif; ?>
<input type="number" name="amount" placeholder="± điểm" style="width:100px"><input name="note" placeholder="Lý do"><button class="btn sm" name="act" value="user_adjust">Điều chỉnh</button></form><?php endif; ?>
<?php if ($x['role'] === 'collab'): $mine = array_column(array_filter($mc, fn($m) => (int)$m['user_id'] === (int)$x['id']), 'category_id'); ?>
<form method="post" action="/admin/diem/act" class="inline wide"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><input type="hidden" name="act" value="user_cats"><span class="muted">Chuyên mục CTV được duyệt (bỏ trống = tất cả):</span>
<?php foreach ($cats as $c): ?><label class="chk"><input type="checkbox" name="cats[]" value="<?=(int)$c['id']?>" <?=in_array((string)$c['id'], array_map('strval', $mine), true) ? 'checked' : ''?>> <?=e($c['name'])?></label><?php endforeach; ?><button class="btn sm">Lưu</button></form><?php endif; ?></div>
<?php endforeach; ?>
<?php else: ?>
<div class="flash info">Chia sẻ doanh thu cho <b>cộng tác viên</b>: quỹ = doanh thu × <?=(int)round((float)pc('ctv.pool_pct') * 100)?>% ÷ <?=(int)pc('points.vnd_per_point')?>đ/điểm; chia theo điểm đóng góp = <?=e((string)pc('ctv.w_xp'))?> × điểm hoạt động trong tháng + <?=e((string)pc('ctv.w_article'))?> × số bài đăng + <?=e((string)pc('ctv.w_view'))?> × lượt xem bài. Chỉ chia cho tháng đã kết thúc, mỗi tháng một lần. Hãy hỏi kế toán/luật sư về hợp đồng cộng tác và thuế trước khi áp dụng.</div>
<form method="post" action="/admin/diem/doanh-thu" class="form narrow"><?=csrf_field()?>
<label>Tháng (YYYY-MM)<input name="ym" placeholder="<?=date('Y-m', strtotime('first day of last month'))?>" value="<?=e($ym ?? '')?>" required></label>
<label>Doanh thu KHÁC trong tháng (quảng cáo, tiếp thị... nhập tay, đồng)<input type="number" name="revenue" value="<?=(int)($other ?? 0)?>" min="0"></label>
<label class="chk"><input type="checkbox" name="auto" value="1" checked> Tự cộng doanh thu Premium đã thanh toán trong tháng đó</label>
<?php if (isset($preview)): ?><label class="chk"><input type="checkbox" name="confirm" value="1"> Xác nhận chia thật cho <?=count($preview['rows'])?> cộng tác viên</label><?php endif; ?>
<button class="btn"><?=isset($preview) ? 'Chia' : 'Xem trước'?></button></form>
<?php if (isset($preview)): ?><p class="muted">Doanh thu tính chia: Premium <b><?=number_format((int)($prem ?? 0))?>đ</b> + khác <b><?=number_format((int)($other ?? 0))?>đ</b> = <b><?=number_format((int)($rev ?? 0))?>đ</b></p><p>Quỹ: <b><?=number_format($preview['pool'])?></b> điểm · Tổng điểm đóng góp của các CTV: <?=number_format($preview['total'], 1)?></p>
<table><tr><th>CTV</th><th>Điểm hoạt động</th><th>Bài đăng</th><th>Lượt xem</th><th>Điểm đóng góp</th><th>Nhận (điểm)</th></tr><?php foreach ($preview['rows'] as $r): ?><tr><td><?=e($r['name'])?></td><td><?=(int)$r['x']?></td><td><?=(int)$r['art']?></td><td><?=(int)$r['views']?></td><td><?=number_format($r['score'], 1)?></td><td><b><?=(int)$r['pts']?></b></td></tr><?php endforeach; ?></table><?php endif; ?>
<h2>Các kỳ đã chia</h2><table><?php foreach ($runs as $r): ?><tr><td><?=e($r['month'])?></td><td><?=number_format((int)$r['revenue_vnd'])?>đ</td><td><?=number_format((int)$r['pool_points'])?> điểm</td><td><?=(int)$r['total_shares']?> CTV</td></tr><?php endforeach; ?></table>
<?php endif; ?>
