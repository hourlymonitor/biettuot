<?php $base = $cat ? '/bai-viet/chuyen-muc/'.$cat['slug'] : '/bai-viet'; ?>
<h1><?=$cat ? e($cat['icon'].' '.$cat['name']) : '📰 Bài viết'?></h1><p class="muted">Giải đáp chi tiết do cộng tác viên và AI biên soạn từ các câu hỏi hay của cộng đồng.</p>
<nav class="chips"><a href="/bai-viet">Tất cả</a><?php foreach (cats() as $c): ?><a href="/bai-viet/chuyen-muc/<?=e($c['slug'])?>"><?=e($c['icon'])?> <?=e($c['name'])?></a><?php endforeach; ?></nav>
<?php foreach ($items as $x): ?><article class="card"><a class="qt" href="/bai-viet/<?=e($x['slug'])?>-<?=(int)$x['id']?>"><?=e($x['title'])?></a>
<div class="meta"><?=e(($x['icon'] ?? '').' '.($x['cat'] ?? 'Chung'))?><?=$x['username'] ? ' · '.e($x['username']) : ''?> · <?=e(date('d/m/Y', strtotime($x['published_at'])))?></div>
<p class="muted"><?=e(mb_substr(trim(preg_replace('/[#*\-\s]+/u', ' ', $x['ex'])), 0, 150))?>…</p></article><?php endforeach; if (!$items): ?><p class="muted">Chưa có bài viết nào trong mục này.</p><?php endif; ?>
<div class="pager"><?php if ($page > 1): ?><a class="btn ghost" href="<?=e($base)?>?page=<?=$page - 1?>">← Trước</a><?php else: ?><span></span><?php endif; ?><?php if (count($items) >= 20): ?><a class="btn ghost" href="<?=e($base)?>?page=<?=$page + 1?>">Sau →</a><?php endif; ?></div>
