<h1>💳 Thanh toán Premium</h1><?=admin_nav()?>
<?php if (!$dbOk): ?><div class="flash err">Chưa có bảng thanh toán. Hãy chạy <a href="/install.php">/install.php</a>.</div><?php endif; ?>
<div class="stats"><div class="stat"><small>Doanh thu Premium tháng này</small><b><?=number_format($stats['sum'])?>đ</b></div><div class="stat"><small>Đơn đã thanh toán</small><b><?=(int)$stats['n']?></b></div><div class="stat"><small>Đơn đang chờ</small><b><?=(int)$stats['pending']?></b></div>
<div class="stat"><small>Trạng thái</small><b style="font-size:1rem"><?=feature('pay_auto') ? '🟢 Đang bật' : '⚪ Đang tắt'?></b></div></div>
<p class="muted">Quy trình: thành viên chọn gói → hệ thống tạo đơn và mã QR (VietQR) → khi tiền về, SePay/Casso gửi webhook → hệ thống tự khớp mã đơn và kích hoạt Premium. Bật/tắt ở <a href="/admin/tinh-nang">Tính năng</a> ("Thanh toán Premium tự động"). Chưa dùng dịch vụ đối soát: chọn "Thủ công" rồi bấm "Xác nhận đã thanh toán" khi thấy tiền về.</p>
<h2>⚙️ Cấu hình nhận tiền</h2>
<form method="post" class="form card"><?=csrf_field()?><input type="hidden" name="act" value="save_cfg">
  <div class="g2"><label>Mã ngân hàng theo VietQR (ví dụ MB, VCB, ACB, TCB, VPB)<input name="bank" value="<?=e($cfg['bank'])?>" required></label><label>Số tài khoản<input name="acc" value="<?=e($cfg['acc'])?>" required></label></div>
  <div class="g2"><label>Tên chủ tài khoản (hiển thị trên QR)<input name="name" value="<?=e($cfg['name'])?>"></label><label>Template QR (compact2, compact, qr_only...)<input name="tpl" value="<?=e($cfg['tpl'])?>"></label></div>
  <div class="g2"><label>Dịch vụ đối soát<select name="provider"><option value="manual" <?=$cfg['provider'] === 'manual' ? 'selected' : ''?>>Thủ công (admin xác nhận)</option><option value="sepay" <?=$cfg['provider'] === 'sepay' ? 'selected' : ''?>>SePay (webhook)</option><option value="casso" <?=$cfg['provider'] === 'casso' ? 'selected' : ''?>>Casso (webhook thủ công)</option></select></label>
  <label>Khóa webhook / secure-token <?=$hasSecret ? '(đã lưu - để trống để giữ nguyên)' : ''?><input type="password" name="secret" autocomplete="off" placeholder="Chuỗi bí mật bạn tự đặt, trùng với bên SePay/Casso"></label></div>
  <label>Hạn thanh toán của đơn (phút)<input type="number" name="expiry" value="<?=(int)$cfg['expiry']?>" min="10" max="1440"></label>
  <button class="btn">Lưu cấu hình</button></form>
<div class="card"><b>Địa chỉ webhook:</b> <code><?=e($webhook)?></code>
<ul class="muted"><li><b>SePay</b> (my.sepay.vn → WebHooks → Thêm): URL như trên; chứng thực <b>API Key</b> (SePay gửi header <code>Authorization: Apikey KHÓA</code>), điền cùng KHÓA vào ô trên; Content-Type <b>application/json</b>; <u>tắt</u> tùy chọn "bỏ qua nếu không có mã thanh toán" (hệ thống tự tìm mã đơn trong nội dung chuyển khoản).</li>
<li><b>Casso</b> (webhook thủ công): URL như trên; điền "Key bảo mật" trùng ô trên (Casso gửi header <code>secure-token</code>); chỉ nhận giao dịch tiền vào. Hiện hỗ trợ dạng webhook thủ công, chưa hỗ trợ chữ ký Webhook V2.</li>
<li>Ảnh QR lấy từ dịch vụ VietQR Quick Link (img.vietqr.io). VietQR khuyến nghị dự án chính thức tạo template riêng tại my.vietqr.io rồi nhập mã template vào ô trên.</li></ul></div>

<h2>🧾 Đơn hàng gần đây</h2>
<table><tr><th>Mã</th><th>Thành viên</th><th>Gói</th><th>Số tiền</th><th>Trạng thái</th><th>Tạo</th><th></th></tr><?php foreach ($orders as $o): ?><tr><td><code><?=e($o['code'])?></code></td><td><?=e($o['username'])?></td><td><?=e($o['plan'])?></td><td><?=number_format((int)$o['amount'])?>đ</td>
<td><?=['pending' => '⏳ Chờ', 'paid' => '✅ Đã trả', 'expired' => '⌛ Hết hạn', 'cancelled' => '✘ Hủy'][$o['status']]?><?=$o['provider'] && $o['status'] === 'paid' ? ' ('.e($o['provider']).')' : ''?></td><td><?=e(ago($o['created_at']))?></td>
<td><?php if (in_array($o['status'], ['pending', 'expired'], true)): ?><form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="btn sm" name="act" value="mark_paid" data-confirm-btn="Xác nhận đã nhận tiền và kích hoạt Premium?">Xác nhận đã trả</button><button class="btn sm ghost" name="act" value="cancel">Hủy</button></form><?php endif; ?></td></tr><?php endforeach; ?></table>
<h2>📥 Giao dịch từ webhook</h2>
<table><tr><th>Giờ</th><th>Nguồn</th><th>Số tiền</th><th>Nội dung</th><th>Kết quả</th></tr><?php foreach ($txs as $x): ?><tr><td><?=e($x['created_at'])?></td><td><?=e($x['provider'])?></td><td><?=number_format((int)$x['amount'])?>đ</td><td><?=e($x['content'])?></td><td><?=e($x['result'])?></td></tr><?php endforeach; ?></table>
<p class="muted">Giao dịch "không khớp đơn" nghĩa là nội dung chuyển khoản không chứa mã đơn hợp lệ: hãy đối chiếu thủ công và dùng "Xác nhận đã trả" ở đơn tương ứng.</p>
<h2>🏷 Mã giảm giá</h2>
<form method="post" class="form card"><?=csrf_field()?><input type="hidden" name="act" value="coupon_add"><div class="g2"><label>Mã (A-Z, 0-9)<input name="code" required placeholder="TET2027"></label>
<label>Loại<select name="kind"><option value="percent">Giảm theo %</option><option value="fixed">Giảm số tiền (đ)</option></select></label></div>
<div class="g2"><label>Giá trị (% hoặc đồng)<input type="number" name="value" required></label><label>Số lượt tối đa (0 = không giới hạn)<input type="number" name="max_uses" value="0"></label></div>
<div class="g2"><label>Hết hạn (tùy chọn)<input type="date" name="expires"></label><label>Áp dụng cho gói<select name="plan"><option value="">Mọi gói</option><?php foreach ($plans as $k => $p): ?><option value="<?=e($k)?>"><?=e($p['name'])?></option><?php endforeach; ?></select></label></div><button class="btn">Thêm mã</button></form>
<table><tr><th>Mã</th><th>Giảm</th><th>Đã dùng</th><th>Hết hạn</th><th></th></tr><?php foreach ($coupons as $x): ?><tr><td><b><?=e($x['code'])?></b></td><td><?=$x['kind'] === 'percent' ? (int)$x['value'].'%' : number_format((int)$x['value']).'đ'?></td><td><?=(int)$x['uses']?><?=(int)$x['max_uses'] ? ' / '.(int)$x['max_uses'] : ''?></td><td><?=e($x['expires_at'] ?? '')?></td>
<td><form method="post" class="inline"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$x['id']?>"><button class="btn sm ghost" name="act" value="coupon_toggle"><?=$x['active'] ? 'Đang bật · Tắt' : 'Đang tắt · Bật'?></button></form></td></tr><?php endforeach; ?></table>
