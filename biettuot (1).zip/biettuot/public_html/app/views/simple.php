<div class="empty"><div class="big-emoji"><?=e($emoji)?></div><h1><?=e($head)?></h1><p class="muted"><?=e($msg)?></p><p><a class="btn" href="/">Về trang chủ</a></p></div>
