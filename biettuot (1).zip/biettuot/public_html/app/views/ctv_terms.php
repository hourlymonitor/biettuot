<h1>📜 Điều khoản cộng tác viên <small class="muted">(phiên bản <?=(int)$ver?>)</small></h1>
<div class="doc"><?=md_doc($text)?></div>
<?php if (empty($public) && !$ok): ?><form method="post" class="form card"><?=csrf_field()?><label class="chk"><input type="checkbox" name="agree" value="1" required> Tôi đã đọc và đồng ý với điều khoản trên.</label><button class="btn big">Đồng ý và tiếp tục</button></form>
<?php elseif (empty($public)): ?><div class="flash ok">✔ Bạn đã đồng ý phiên bản điều khoản hiện tại. <a href="/ctv">Về khu vực CTV</a></div><?php endif; ?>
