<h1>💸 Chi phí & ngân sách AI</h1><?=admin_nav()?>
<?php if (!$ok): ?><div class="flash err">Chưa có cột theo dõi chi phí. Hãy chạy <a href="/install.php">/install.php</a>.</div><?php endif; ?>
<?php $usd = fn($v) => '$'.number_format((float)$v, 4); $vnd = fn($v) => number_format((float)$v * $rate).'đ'; $bd = (float)$cfg['day']; $bm = (float)$cfg['month']; ?>
<div class="stats"><div class="stat"><small>Hôm nay</small><b><?=$usd($spendDay)?></b><small>≈ <?=$vnd($spendDay)?><?=$bd > 0 ? ' / '.$usd($bd) : ''?></small></div>
<div class="stat"><small>Tháng này</small><b><?=$usd($spendMonth)?></b><small>≈ <?=$vnd($spendMonth)?><?=$bm > 0 ? ' / '.$usd($bm) : ''?></small></div><div class="stat"><small>Ngân sách</small><b style="font-size:1rem"><?=feature('ai_budget') ? '🟢 Đang áp dụng' : '⚪ Đang tắt'?></b></div></div>
<?php if ($bm > 0): ?><div class="prog"><i style="width:<?=min(100, round($spendMonth / $bm * 100))?>%"></i></div><?php endif; ?>
<p class="muted">Chi phí là <b>ước tính</b> từ số token và đơn giá bạn nhập cho từng AI (Admin → AI → "Chỉnh sửa", đơn vị USD cho 1 triệu token). AI không trả về token thì hệ thống ước lượng theo độ dài chữ.</p>
<h2>⚙️ Ngân sách & trần lượt</h2>
<form method="post" class="form card"><?=csrf_field()?>
  <div class="g2"><label>Ngân sách mỗi ngày (USD, 0 = không giới hạn)<input type="number" step="0.01" min="0" name="day" value="<?=e($cfg['day'])?>"></label><label>Ngân sách mỗi tháng (USD, 0 = không giới hạn)<input type="number" step="0.01" min="0" name="month" value="<?=e($cfg['month'])?>"></label></div>
  <label>Khi chạm ngân sách<select name="action"><option value="fallback" <?=$cfg['action'] !== 'stop' ? 'selected' : ''?>>Chỉ dùng AI dự phòng (ví dụ Puter), nếu không có thì dừng</option><option value="stop" <?=$cfg['action'] === 'stop' ? 'selected' : ''?>>Dừng mọi lượt gọi AI</option></select></label>
  <label>Tỷ giá USD → VND (để hiển thị)<input type="number" name="rate" value="<?=(float)$rate?>"></label>
  <b>Trần số lượt/ngày theo tính năng (0 = không giới hạn)</b>
  <div class="g2"><?php foreach (['chat' => 'Trợ lý chat', 'answer' => 'AI trả lời câu hỏi', 'moderation' => 'Kiểm duyệt', 'summary' => 'Tóm tắt', 'article' => 'Soạn bài', 'quiz' => 'Tạo đố vui'] as $k => $l): ?><label><?=e($l)?><input type="number" min="0" name="cap_<?=e($k)?>" value="<?=(int)$caps[$k]?>"></label><?php endforeach; ?></div>
  <button class="btn">Lưu ngân sách</button></form>
<h2>Theo AI (tháng này)</h2><table><tr><th>AI</th><th>Lượt</th><th>Thành công</th><th>Token vào</th><th>Token ra</th><th>Chi phí</th></tr><?php foreach ($byProv as $r): ?><tr><td><?=e($r['provider'])?></td><td><?=(int)$r['calls']?></td><td><?=(int)$r['okc']?></td><td><?=number_format((int)$r['tin'])?></td><td><?=number_format((int)$r['tout'])?></td><td><?=$usd($r['cost'])?></td></tr><?php endforeach; ?></table>
<h2>Theo tính năng (tháng này)</h2><table><tr><th>Tính năng</th><th>Lượt thành công</th><th>Chi phí</th></tr><?php foreach ($byPurpose as $r): ?><tr><td><?=e($r['purpose'] !== '' ? $r['purpose'] : 'khác')?></td><td><?=(int)$r['calls']?></td><td><?=$usd($r['cost'])?></td></tr><?php endforeach; ?></table>
<h2>Thành viên dùng nhiều nhất (tháng này)</h2><table><tr><th>Thành viên</th><th>Lượt</th><th>Chi phí</th></tr><?php foreach ($topUsers as $r): ?><tr><td><?=e($r['username'] ?? '#'.$r['user_id'])?></td><td><?=(int)$r['calls']?></td><td><?=$usd($r['cost'])?></td></tr><?php endforeach; ?></table>
<h2>14 ngày gần đây</h2><?php $mx = max(0.0001, ...array_values(array_map(fn($v) => $v['c'], $days ?: ['x' => ['c' => 0.0001]]))); ?>
<div class="bars"><?php foreach ($days as $dd => $v): ?><div class="bar" title="<?=e($dd)?>: <?=(int)$v['n']?> lượt, <?=$usd($v['c'])?>"><div class="cols"><i class="q" style="height:<?=round($v['c'] / $mx * 100)?>%"></i></div><small><?=e(date('d', strtotime($dd)))?></small></div><?php endforeach; ?></div>
