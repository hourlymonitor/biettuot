<h1>💳 Thanh toán <?=e($plan['name'])?></h1>
<?php if ($o['status'] === 'paid'): ?><div class="flash ok">✅ Đã thanh toán thành công! Gói Premium của bạn đã được kích hoạt. <a href="/cai-dat">Xem trong Cài đặt</a></div>
<?php elseif ($o['status'] === 'cancelled'): ?><div class="flash err">Đơn này đã bị hủy. <a href="/goi-thanh-vien">Tạo đơn mới</a></div>
<?php else: ?>
<?php if ($o['status'] === 'expired'): ?><div class="flash err">Đơn đã hết hạn. Nếu bạn đã chuyển khoản, hệ thống vẫn sẽ kích hoạt khi nhận được tiền. Nếu chưa, hãy <a href="/goi-thanh-vien">tạo đơn mới</a>.</div><?php endif; ?>
<div class="pay-grid">
  <div class="card center"><?php if ($qr): ?><img class="qr" src="<?=e($qr)?>" alt="Mã VietQR" width="280" height="280" loading="eager"><?php endif; ?><p class="muted">Quét bằng ứng dụng ngân hàng - số tiền và nội dung đã điền sẵn.</p></div>
  <div class="card">
    <table><tr><td>Ngân hàng</td><td><b><?=e($c['bank'])?></b></td></tr><tr><td>Số tài khoản</td><td><b id="v_acc"><?=e($c['acc'])?></b></td></tr><tr><td>Chủ tài khoản</td><td><b><?=e($c['name'])?></b></td></tr>
    <tr><td>Số tiền</td><td><b id="v_amt"><?=number_format((int)$o['amount'])?>đ</b><?php if ((int)$o['discount'] > 0): ?> <small class="muted">(đã giảm <?=number_format((int)$o['discount'])?>đ<?=$o['coupon'] ? ' - mã '.e($o['coupon']) : ''?>)</small><?php endif; ?></td></tr>
    <tr><td>Nội dung CK</td><td><b id="v_code"><?=e($o['code'])?></b> <button type="button" class="btn sm ghost" data-copy="<?=e($o['code'])?>">Chép</button></td></tr></table>
    <div class="flash info"><b>Giữ nguyên nội dung chuyển khoản</b> <code><?=e($o['code'])?></code> và chuyển <b>đủ số tiền</b> để hệ thống tự nhận.<?=$c['provider'] === 'manual' ? ' Quản trị viên sẽ xác nhận thủ công sau khi nhận tiền.' : ''?></div>
    <?php if ($o['status'] === 'pending'): ?><p>Đơn hết hạn sau: <b id="cd" data-exp="<?=(int)strtotime($o['expires_at'])?>">…</b></p><?php endif; ?>
    <p id="st" class="muted"><span class="spin"></span> Đang chờ tiền về…</p>
    <form method="post" action="/thanh-toan/huy" class="inline" data-confirm="Hủy đơn này?"><?=csrf_field()?><input type="hidden" name="code" value="<?=e($o['code'])?>"><button class="btn sm ghost">Hủy đơn</button></form>
  </div>
</div>
<script>(function(){var code=<?=json_encode($o['code'])?>,cd=document.getElementById('cd');
 function tick(){if(!cd)return;var s=Math.max(0,parseInt(cd.dataset.exp,10)-Math.floor(Date.now()/1000));cd.textContent=Math.floor(s/60)+' phút '+('0'+(s%60)).slice(-2)+' giây';}
 tick();setInterval(tick,1000);
 document.querySelectorAll('[data-copy]').forEach(function(b){b.onclick=function(){try{navigator.clipboard.writeText(b.dataset.copy);b.textContent='✔ Đã chép';}catch(e){}};});
 var n=0;(function poll(){fetch('/api/thanh-toan?code='+encodeURIComponent(code)).then(function(r){return r.json();}).then(function(d){if(d.status==='paid'){location.reload();return;}if(d.status==='cancelled')return;if(++n<400)setTimeout(poll,5000);}).catch(function(){setTimeout(poll,8000);});})();})();</script>
<?php endif; ?>
