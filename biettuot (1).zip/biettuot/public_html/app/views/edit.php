<h1><?=$kind === 'question' ? 'Sửa câu hỏi' : 'Sửa câu trả lời'?></h1>
<form method="post" class="form"><?=csrf_field()?>
<?php if ($kind === 'question'): ?><label>Tiêu đề<input name="title" maxlength="200" required value="<?=e($row['title'])?>"></label>
<label>Chi tiết<textarea name="body" rows="6" maxlength="5000"><?=e($row['body'])?></textarea></label>
<label>Thẻ<input name="tags" maxlength="150" value="<?=e($tags)?>"></label>
<?php else: ?><label>Nội dung<textarea name="body" rows="8" maxlength="5000" required><?=e($row['body'])?></textarea></label><?php endif; ?>
<button class="btn">Lưu thay đổi</button><p class="muted">Phiên bản cũ được lưu lại trong lịch sử chỉnh sửa (người kiểm duyệt có thể xem).</p></form>
