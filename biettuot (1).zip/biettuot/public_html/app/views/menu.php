<h1>Menu</h1>
<?php $cu = me(); ?>
<form class="form" action="/tim" role="search"><input name="q" placeholder="Tìm câu hỏi…" aria-label="Tìm kiếm"><button class="btn">Tìm</button></form>
<?php if ($cu): ?><h2>Của tôi</h2><div class="menu"><?php if (feature('profiles')): ?><a href="/u/<?=e($cu['username'])?>">👤 Hồ sơ</a><?php endif; ?><?php if (feature('points')): ?><a href="/vi">⭐ Ví điểm & thử thách</a><?php endif; ?><a href="/cai-dat">⚙️ Cài đặt</a>
<?php if (feature('ctv') && is_ctv($cu)): ?><a href="/ctv">✍️ Khu vực cộng tác viên</a><?php endif; ?><?php if (is_admin() || $cu['role'] === 'collab'): ?><a href="/admin">🛠 Quản trị</a><?php endif; ?></div><?php endif; ?>
<h2>Lĩnh vực</h2><div class="menu grid2"><?php foreach (cats() as $c): ?><a href="/c/<?=e($c['slug'])?>"><?=e($c['icon'])?> <?=e($c['name'])?></a><?php endforeach; ?></div>
<h2>Khám phá</h2><div class="menu"><?php if (feature('chat')): ?><a href="/tro-ly">🤖 Trợ lý AI</a><?php endif; ?><?php if (feature('articles')): ?><a href="/bai-viet">📰 Bài viết</a><?php endif; ?><?php if (feature('quiz')): ?><a href="/do-vui">🎯 Đố vui hằng ngày</a><?php endif; ?>
<?php if (feature('leaderboard')): ?><a href="/xep-hang">🏅 Bảng xếp hạng</a><?php endif; ?><?php if (feature('rewards')): ?><a href="/qua-tang">🎁 Đổi quà</a><?php endif; ?><?php if (feature('ctv')): ?><a href="/cong-tac-vien">🤝 Chương trình cộng tác viên</a><?php endif; ?>
<?php if (feature('premium')): ?><a href="/goi-thanh-vien">💎 Gói Premium</a><?php endif; ?><a href="/trang/quy-dinh">📜 Quy định cộng đồng</a><a href="/trang/gioi-thieu">ℹ️ Giới thiệu</a></div>
<div class="menu" style="margin-top:12px"><?php if ($cu): ?><form method="post" action="/dang-xuat"><?=csrf_field()?><button>🚪 Đăng xuất</button></form><?php else: ?><a href="/dang-nhap">🔑 Đăng nhập</a><?php if (feature('registration')): ?><a href="/dang-ky">✨ Đăng ký</a><?php endif; ?><?php endif; ?></div>
