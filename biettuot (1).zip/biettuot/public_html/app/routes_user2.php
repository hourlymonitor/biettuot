<?php
// ---------- Người dùng & cộng tác viên: 2FA, dữ liệu cá nhân, bản tin, ảnh chia sẻ, danh bạ chuyên gia, nhu cầu nội dung, điều khoản, thu nhập CTV ----------
function ctv_earnings(int $uid): array {
  $out = []; $vp = (int)pc('points.vnd_per_point');
  foreach (q("SELECT ref_id,SUM(delta) pts FROM point_ledger WHERE user_id=? AND kind='revshare' AND status<>'reversed' GROUP BY ref_id ORDER BY ref_id DESC LIMIT 36", [$uid])->fetchAll() as $r) {
    $ym = substr((string)$r['ref_id'], 0, 4).'-'.substr((string)$r['ref_id'], 4, 2);
    $art = (int)q("SELECT COUNT(*) FROM articles WHERE author_id=? AND status='published' AND published_at>=? AND published_at<DATE_ADD(?,INTERVAL 1 MONTH)", [$uid, "$ym-01 00:00:00", "$ym-01 00:00:00"])->fetchColumn();
    $views = (int)q('SELECT COALESCE(SUM(s.views),0) FROM article_stats s JOIN articles a ON a.id=s.article_id WHERE a.author_id=? AND s.ym=?', [$uid, $ym])->fetchColumn();
    $out[] = ['ym' => $ym, 'pts' => (int)$r['pts'], 'vnd' => (int)$r['pts'] * $vp, 'art' => $art, 'views' => $views];
  }
  return $out;
}

// ----- Xác thực hai lớp -----
route('GET', '#^/dang-nhap/2fa$#', function () {
  if (empty($_SESSION['p2fa']) || $_SESSION['p2fa']['ts'] < time() - 600) { unset($_SESSION['p2fa']); flash('Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.', 'err'); redirect('/dang-nhap'); }
  render('twofa_login', [], 'Xác thực hai lớp - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/dang-nhap/2fa$#', function () {
  $p = $_SESSION['p2fa'] ?? null; if (!$p || $p['ts'] < time() - 600) { unset($_SESSION['p2fa']); redirect('/dang-nhap'); }
  $u = q('SELECT * FROM users WHERE id=? AND banned=0', [$p['uid']])->fetch(); if (!$u || empty($u['totp_enabled'])) { unset($_SESSION['p2fa']); redirect('/dang-nhap'); }
  $code = trim((string)($_POST['code'] ?? ''));
  $ok = preg_match('/^\s*\d{3}\s?\d{3}\s*$/', $code) ? totp_verify(secret_dec((string)$u['totp_secret']), $code) : totp_use_recovery((int)$u['id'], $code);
  if (!$ok) {
    $_SESSION['p2fa']['fails']++; log_login((int)$u['id'], false);
    if ($_SESSION['p2fa']['fails'] >= 5) { unset($_SESSION['p2fa']); flash('Nhập sai quá nhiều lần, hãy đăng nhập lại.', 'err'); redirect('/dang-nhap'); }
    render('twofa_login', ['err' => 'Mã không đúng, hãy thử lại.'], 'Xác thực hai lớp - '.cfg('site_name'), '', ['noindex' => true]); return;
  }
  $next = $p['next']; unset($_SESSION['p2fa'], $_SESSION['next']); session_regenerate_id(true); $_SESSION['uid'] = (int)$u['id'];
  log_login((int)$u['id'], true); q('UPDATE users SET last_ip=? WHERE id=?', [client_ip(), $u['id']]); redirect($next);
});
route('GET', '#^/cai-dat/2fa$#', function () {
  $u = fresh_user((int)require_login()['id']); $secret = $uri = '';
  if (!$u['totp_enabled']) { $_SESSION['totp_new'] ??= b32_encode(random_bytes(20)); $secret = $_SESSION['totp_new']; $uri = totp_uri($secret, $u['email']); }
  $codes = $_SESSION['totp_codes'] ?? null; unset($_SESSION['totp_codes']);
  render('twofa', ['u' => $u, 'secret' => $secret, 'uri' => $uri, 'codes' => $codes], 'Xác thực hai lớp - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/cai-dat/2fa$#', function () {
  $u = fresh_user((int)require_login()['id']); $act = (string)($_POST['act'] ?? '');
  if ($act === 'enable' && !$u['totp_enabled']) {
    $s = (string)($_SESSION['totp_new'] ?? '');
    if ($s !== '' && totp_verify($s, (string)($_POST['code'] ?? ''))) {
      [$codes, $hashes] = totp_make_recovery(); q('UPDATE users SET totp_secret=?,totp_enabled=1,totp_recovery=? WHERE id=?', [secret_enc($s), json_encode($hashes), $u['id']]);
      unset($_SESSION['totp_new']); $_SESSION['totp_codes'] = $codes; audit('2fa:on'); flash('Đã bật xác thực hai lớp. Hãy lưu các mã khôi phục bên dưới ở nơi an toàn.', 'ok');
    } else flash('Mã xác thực không đúng.', 'err');
  } elseif (in_array($act, ['disable', 'regen'], true) && $u['totp_enabled']) {
    if (!password_verify((string)($_POST['password'] ?? ''), $u['pass_hash']) || !totp_verify(secret_dec((string)$u['totp_secret']), (string)($_POST['code'] ?? ''))) flash('Mật khẩu hoặc mã xác thực không đúng.', 'err');
    elseif ($act === 'disable') { q('UPDATE users SET totp_secret=NULL,totp_enabled=0,totp_recovery=NULL WHERE id=?', [$u['id']]); audit('2fa:off'); flash('Đã tắt xác thực hai lớp.', 'ok'); }
    else { [$codes, $hashes] = totp_make_recovery(); q('UPDATE users SET totp_recovery=? WHERE id=?', [json_encode($hashes), $u['id']]); $_SESSION['totp_codes'] = $codes; flash('Đã tạo mã khôi phục mới (mã cũ không còn dùng được).', 'ok'); }
  }
  redirect('/cai-dat/2fa');
});

// ----- Dữ liệu cá nhân: tải xuống / xóa tài khoản -----
route('GET', '#^/cai-dat/du-lieu$#', function () { require_login(); render('my_data', [], 'Dữ liệu của tôi - '.cfg('site_name'), '', ['noindex' => true]); });
route('POST', '#^/cai-dat/du-lieu$#', function () {
  $u = fresh_user((int)require_login()['id']); $act = (string)($_POST['act'] ?? ''); $id = (int)$u['id'];
  if (!password_verify((string)($_POST['password'] ?? ''), $u['pass_hash'])) { flash('Mật khẩu không đúng.', 'err'); redirect('/cai-dat/du-lieu'); }
  if ($act === 'export') {
    unset($u['pass_hash'], $u['totp_secret'], $u['totp_recovery']); audit('data:export');
    $all = fn(string $sql) => q($sql, [$id])->fetchAll();
    $threads = $all('SELECT id,title,mode,field,created_at FROM chat_threads WHERE user_id=?'); foreach ($threads as &$t) $t['messages'] = q('SELECT role,content,created_at FROM chat_messages WHERE thread_id=? ORDER BY id', [$t['id']])->fetchAll(); unset($t);
    $data = ['xuat_luc' => date('c'), 'tai_khoan' => $u, 'cau_hoi' => $all('SELECT id,title,body,status,created_at FROM questions WHERE user_id=?'), 'cau_tra_loi' => $all('SELECT id,question_id,body,status,score,created_at FROM answers WHERE user_id=?'),
      'binh_luan' => $all('SELECT id,answer_id,body,created_at FROM comments WHERE user_id=?'), 'lich_su_diem' => $all('SELECT delta,kind,status,note,created_at FROM point_ledger WHERE user_id=?'),
      'doi_qua' => $all('SELECT reward_id,cost_points,status,contact,created_at FROM redemptions WHERE user_id=?'), 'don_thanh_toan' => $all('SELECT plan,amount,status,created_at,paid_at FROM payment_orders WHERE user_id=?'),
      'theo_doi' => $all('SELECT type,target_id,created_at FROM follows WHERE user_id=?'), 'huy_hieu' => $all('SELECT code,created_at FROM user_badges WHERE user_id=?'), 'tro_ly_chat' => $threads, 'dong_y_dieu_khoan' => $all('SELECT doc,version,accepted_at FROM terms_acceptance WHERE user_id=?')];
    header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="du-lieu-cua-toi.json"'); echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); exit;
  }
  if ($act === 'delete') {
    if (strtoupper(trim((string)($_POST['confirm'] ?? ''))) !== 'XOA') { flash('Hãy gõ XOA để xác nhận.', 'err'); redirect('/cai-dat/du-lieu'); }
    if ($u['role'] === 'admin') { flash('Tài khoản quản trị không thể tự xóa. Hãy chuyển quyền quản trị trước.', 'err'); redirect('/cai-dat/du-lieu'); }
    if ((int)q("SELECT COUNT(*) FROM redemptions WHERE user_id=? AND status='pending'", [$id])->fetchColumn() || (int)q("SELECT COUNT(*) FROM payment_orders WHERE user_id=? AND status='pending' AND expires_at>NOW()", [$id])->fetchColumn()) { flash('Bạn còn đơn đổi quà/thanh toán đang chờ xử lý. Hãy đợi xử lý xong rồi xóa tài khoản.', 'err'); redirect('/cai-dat/du-lieu'); }
    audit('data:delete', '#'.$id);
    q("UPDATE users SET username=?,email=?,pass_hash=?,bio='',payout_info='',birthday=NULL,birthday_set=0,signup_ip='',last_ip='',totp_secret=NULL,totp_enabled=0,totp_recovery=NULL,banned=1,deleted_at=NOW(),email_notify=0,ref_code=NULL,expert_title='' WHERE id=?",
      ['deleted_'.$id, 'deleted_'.$id.'@invalid.local', password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT), $id]);
    foreach (['tokens', 'push_subs', 'notifications', 'follows', 'login_log', 'mod_categories', 'user_badges', 'newsletter_subs'] as $t) { try { q("DELETE FROM `$t` WHERE user_id=?", [$id]); } catch (Throwable $e) {} }
    q('DELETE m FROM chat_messages m JOIN chat_threads t ON t.id=m.thread_id WHERE t.user_id=?', [$id]); q('DELETE FROM chat_threads WHERE user_id=?', [$id]);
    $_SESSION = []; session_destroy(); session_start(); flash('Tài khoản đã được xóa. Nội dung bạn từng đăng được giữ lại dưới tên ẩn danh.', 'ok'); redirect('/');
  }
  redirect('/cai-dat/du-lieu');
});

// ----- Bản tin email -----
route('POST', '#^/ban-tin/dang-ky$#', function () {
  $back = safe_path($_POST['back'] ?? '/'); if (!empty($_POST['hp_note'])) redirect($back);
  $_SESSION['nl_n'] = ($_SESSION['nl_n'] ?? 0) + 1;
  if ($_SESSION['nl_n'] > 3 || (int)q('SELECT COUNT(*) FROM newsletter_subs WHERE created_at>=DATE_SUB(NOW(),INTERVAL 1 DAY) AND user_id IS NULL')->fetchColumn() >= 300) { flash('Bạn thao tác quá nhiều, hãy thử lại sau.', 'err'); redirect($back); }
  $s = news_subscribe((string)($_POST['email'] ?? '')); if (!$s) { flash('Email không hợp lệ.', 'err'); redirect($back); }
  if (!$s['confirmed']) news_confirm_mail($s); flash('Hãy kiểm tra email để xác nhận đăng ký bản tin (xem cả thư rác).', 'ok'); redirect($back);
});
route('GET', '#^/ban-tin/xac-nhan$#', function () {
  $s = q('SELECT * FROM newsletter_subs WHERE token=?', [(string)($_GET['t'] ?? '')])->fetch();
  if ($s) { q('UPDATE newsletter_subs SET confirmed=1,confirmed_at=NOW(),unsub_at=NULL WHERE id=?', [$s['id']]); render('simple', ['emoji' => '✅', 'head' => 'Đã xác nhận', 'msg' => 'Bạn sẽ nhận bản tin Biết Tuốt mỗi tuần. Có thể hủy bất cứ lúc nào bằng liên kết cuối mỗi thư.'], 'Xác nhận bản tin', '', ['noindex' => true]); }
  else render('simple', ['emoji' => '⚠️', 'head' => 'Liên kết không hợp lệ', 'msg' => 'Liên kết xác nhận không đúng hoặc đã hết hạn.'], 'Xác nhận bản tin', '', ['noindex' => true]);
});
route('GET', '#^/ban-tin/huy$#', function () {
  $s = q('SELECT * FROM newsletter_subs WHERE token=?', [(string)($_GET['t'] ?? '')])->fetch();
  if ($s) q('UPDATE newsletter_subs SET unsub_at=NOW() WHERE id=?', [$s['id']]);
  render('simple', ['emoji' => $s ? '👋' : '⚠️', 'head' => $s ? 'Đã hủy nhận bản tin' : 'Liên kết không hợp lệ', 'msg' => $s ? 'Bạn sẽ không nhận bản tin nữa. Cảm ơn bạn đã đọc Biết Tuốt!' : 'Liên kết không đúng.'], 'Hủy bản tin', '', ['noindex' => true]);
});

// ----- Ảnh xem trước khi chia sẻ -----
route('GET', '#^/og/(q|a)/(\d+)\.png$#', function ($t, $id) {
  $def = function () { header('Location: /assets/og-default.png', true, 302); exit; };
  if (!feature('og_images') || !og_available()) $def();
  if ($t === 'q') { $r = q("SELECT q.title,q.answers_count,c.name cat FROM questions q JOIN categories c ON c.id=q.category_id WHERE q.id=? AND q.status='published'", [$id])->fetch(); if (!$r) $def(); $title = $r['title']; $sub = (int)$r['answers_count'].' câu trả lời · Hỏi đáp Biết Tuốt'; $tag = (string)$r['cat']; }
  else { $r = q("SELECT a.title,c.name cat FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.id=? AND a.status='published'", [$id])->fetch(); if (!$r) $def(); $title = $r['title']; $sub = 'Bài viết · Biết Tuốt'; $tag = (string)($r['cat'] ?? ''); }
  $dir = ROOT.'/app/cache/og'; if (!is_dir($dir)) @mkdir($dir, 0755, true); $f = $dir.'/'.$t.$id.'-'.substr(md5($title.$sub.$tag), 0, 8).'.png';
  if (is_file($f)) $out = (string)file_get_contents($f); else { $out = og_png($title, $sub, $tag); if ($out === null) $def(); @file_put_contents($f, $out, LOCK_EX); }
  header_remove('Pragma'); header_remove('Expires'); header('Content-Type: image/png'); header('Cache-Control: public, max-age=604800'); echo $out;
});

// ----- Danh bạ chuyên gia / cộng tác viên -----
route('GET', '#^/chuyen-gia$#', function () {
  $slug = (string)($_GET['c'] ?? ''); $w = "u.banned=0 AND (u.role='collab' OR u.expert_title<>'')"; $p = [];
  if ($slug !== '') { $w .= ' AND u.id IN (SELECT m.user_id FROM mod_categories m JOIN categories c ON c.id=m.category_id WHERE c.slug=?)'; $p[] = $slug; }
  $rows = q("SELECT u.id,u.username,u.bio,u.xp,u.role,u.expert_title,u.premium_until,(SELECT GROUP_CONCAT(c.name SEPARATOR ', ') FROM mod_categories m JOIN categories c ON c.id=m.category_id WHERE m.user_id=u.id) cats,
    (SELECT COUNT(*) FROM articles WHERE author_id=u.id AND status='published') arts FROM users u WHERE $w ORDER BY (u.expert_title<>'') DESC,arts DESC,u.xp DESC LIMIT 60", $p)->fetchAll();
  render('experts', ['rows' => $rows, 'slug' => $slug], 'Chuyên gia & cộng tác viên - '.cfg('site_name'), 'Danh sách chuyên gia và cộng tác viên phụ trách từng lĩnh vực trên Biết Tuốt.', ['cache' => true]);
});

// ----- Khu vực CTV: nhu cầu nội dung, soạn nháp bằng AI, điều khoản, thu nhập -----
route('GET', '#^/ctv/nhu-cau$#', function () {
  $u = ctv_only(); $mc = $u['role'] === 'admin' ? [] : ctv_cats((int)$u['id']); $w = "g.status IN ('open','assigned')"; if ($mc) $w .= ' AND (g.category_id IS NULL OR g.category_id IN ('.implode(',', $mc).'))';
  $gaps = q("SELECT g.*,c.name cname,u.username assignee FROM content_gaps g LEFT JOIN categories c ON c.id=g.category_id LEFT JOIN users u ON u.id=g.assigned_to WHERE $w ORDER BY (g.status='open') DESC,g.hits DESC,g.last_at DESC LIMIT 60")->fetchAll();
  render('ctv_gaps', ['gaps' => $gaps, 'cats' => ctv_article_cats($u), 'canAi' => feature('ai_drafts') && (bool)ai_providers()], 'Nhu cầu nội dung - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/ctv/nhu-cau/act$#', function () {
  $u = ctv_only(); $id = (int)($_POST['id'] ?? 0); $act = (string)($_POST['act'] ?? ''); $g = q('SELECT * FROM content_gaps WHERE id=?', [$id])->fetch(); if (!$g) not_found();
  if ($g['category_id'] && !ctv_can_cat($u, (int)$g['category_id'])) not_found();
  switch ($act) {
    case 'claim': if ($g['status'] === 'open') q("UPDATE content_gaps SET status='assigned',assigned_to=? WHERE id=?", [$u['id'], $id]); break;
    case 'ignore': q("UPDATE content_gaps SET status='ignored' WHERE id=?", [$id]); break;
    case 'done': q("UPDATE content_gaps SET status='done' WHERE id=?", [$id]); break;
    case 'setcat': $cid = (int)($_POST['category_id'] ?? 0); if ($cid && ctv_can_cat($u, $cid)) q('UPDATE content_gaps SET category_id=? WHERE id=?', [$cid, $id]); break;
  }
  redirect('/ctv/nhu-cau');
});
route('POST', '#^/ctv/soan-nhap$#', function () {
  $u = ctv_only(); @set_time_limit(180); $topic = trim(mb_substr((string)($_POST['topic'] ?? ''), 0, 200)); $cid = (int)($_POST['category_id'] ?? 0); $gid = (int)($_POST['gap_id'] ?? 0) ?: null;
  if (mb_strlen($topic) < 10 || !ctv_can_cat($u, $cid) || !q('SELECT 1 FROM categories WHERE id=?', [$cid])->fetchColumn()) { flash('Cần chủ đề từ 10 ký tự và chọn lĩnh vực bạn phụ trách.', 'err'); redirect('/ctv/nhu-cau'); }
  if (over_limit('articles', 'author_id', (int)$u['id'], 20)) { flash('Hôm nay bạn đã tạo đủ số bản nháp cho phép.', 'err'); redirect('/ctv/nhu-cau'); }
  $id = draft_from_topic($u, $topic, $cid, $gid); flash('Đã tạo bản nháp. Hãy kiểm chứng, chỉnh sửa rồi đăng bài.', 'ok'); redirect('/ctv/bai-viet/'.$id.'/sua');
});
route('GET', '#^/ctv/dieu-khoan$#', function () {
  $u = require_login(); if (!in_array($u['role'], ['collab', 'admin'], true)) not_found();
  render('ctv_terms', ['text' => ctv_terms_text(), 'ver' => ctv_terms_ver(), 'ok' => ctv_terms_ok($u), 'public' => false], 'Điều khoản cộng tác viên - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/ctv/dieu-khoan$#', function () {
  $u = require_login(); if (!in_array($u['role'], ['collab', 'admin'], true)) not_found();
  if (empty($_POST['agree'])) { flash('Bạn cần đồng ý điều khoản để tiếp tục.', 'err'); redirect('/ctv/dieu-khoan'); }
  q('INSERT IGNORE INTO terms_acceptance(user_id,doc,version,ip) VALUES(?,?,?,?)', [$u['id'], 'ctv', ctv_terms_ver(), client_ip()]); flash('Cảm ơn bạn đã đồng ý điều khoản.', 'ok'); redirect('/ctv');
});
route('GET', '#^/dieu-khoan-ctv$#', function () { render('ctv_terms', ['text' => ctv_terms_text(), 'ver' => ctv_terms_ver(), 'ok' => true, 'public' => true], 'Điều khoản cộng tác viên - '.cfg('site_name'), 'Điều khoản chương trình cộng tác viên Biết Tuốt.'); });
route('GET', '#^/ctv/thu-nhap(\.csv)?$#', function ($csv = '') {
  $u = ctv_only(); $rows = ctv_earnings((int)$u['id']);
  if ($csv) {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="thu-nhap-ctv.csv"'); echo "\xEF\xBB\xBF"; $o = fopen('php://output', 'w');
    fputcsv($o, ['Thang', 'Ten dang nhap', 'Diem duoc chia', 'Quy doi uoc tinh (VND)', 'So bai dang', 'Luot xem bai']); foreach ($rows as $r) fputcsv($o, [$r['ym'], $u['username'], $r['pts'], $r['vnd'], $r['art'], $r['views']]); fclose($o); return;
  }
  render('ctv_earnings', ['u' => $u, 'rows' => $rows, 'vp' => (int)pc('points.vnd_per_point')], 'Thu nhập cộng tác viên - '.cfg('site_name'), '', ['noindex' => true]);
});
