<?php
// ---------- Admin: bật/tắt tính năng và quản lý AI (thêm API, xoay vòng, dự phòng Puter) ----------
route('GET', '#^/admin/tinh-nang$#', function () {
  admin_only(); render('admin_features', ['defs' => feature_defs(), 'groups' => feature_groups()], 'Bật/tắt tính năng - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/tinh-nang$#', function () {
  admin_only(); $mode = (string)($_POST['mode'] ?? 'save');
  foreach (feature_defs() as $k => $d) {
    if ($k === 'maintenance' && $mode !== 'save') continue;
    $on = $mode === 'on' ? true : ($mode === 'off' ? ($d[0] === 'core' ? feature($k) : false) : !empty($_POST['f'][$k]));
    if ($on !== feature($k)) feature_set($k, $on);
  }
  audit('features', $mode); cache_clear(); flash($mode === 'on' ? 'Đã bật tất cả tính năng.' : ($mode === 'off' ? 'Đã tắt các tính năng mở rộng (giữ nhóm cốt lõi).' : 'Đã lưu cài đặt tính năng.'), 'ok'); redirect('/admin/tinh-nang');
});

function ai_provider_row(int $id): ?array {
  $r = q('SELECT * FROM ai_providers WHERE id=?', [$id])->fetch(); if (!$r) return null;
  return ['id' => (int)$r['id'], 'name' => $r['name'], 'type' => $r['ptype'], 'key' => secret_dec((string)$r['api_key']), 'model' => $r['model'], 'base_url' => $r['base_url'], 'active' => (int)$r['active']];
}
function ai_run_test(int $id, array $cands = []): array {
  $p = ai_provider_row($id); if (!$p) return [false, 'Không tìm thấy AI này'];
  if (!$cands && strpos((string)$p['base_url'], 'puter.com') !== false) $cands = (array)ai_presets()['puter'][6];
  [$ok, $note] = ai_test_one($p);
  if (!$ok && !preg_match('/^HTTP (401|402|403|429)/', $note)) {   // lỗi model/tham số: tự tìm model dùng được
    [$c, $ids] = ai_models($p); $try = [];
    if ($ids && !in_array($p['model'], $ids, true)) { $pick = ai_pick_model($ids); if ($pick !== '') $try[] = $pick; }
    foreach ($cands as $m) if ($m !== $p['model']) $try[] = $m;
    foreach (array_slice(array_values(array_unique($try)), 0, 4) as $m) {
      $p2 = $p; $p2['model'] = $m; [$ok2, $n2] = ai_test_one($p2);
      if ($ok2) { q('UPDATE ai_providers SET model=? WHERE id=?', [$m, $id]); $ok = true; $note = "(tự đổi model sang $m) $n2"; break; }
    }
  }
  q('UPDATE ai_providers SET last_test_at=NOW(),last_test_ok=?,last_test_note=? WHERE id=?', [(int)$ok, mb_substr($note, 0, 250), $id]);
  if ($ok) q('DELETE FROM ai_cooldown WHERE provider=?', [$p['name']]);
  return [$ok, $note];
}
function ai_autointegrate(bool $force = false): bool {
  if (!$force && setting('ai_integrated') === '1') return false;
  foreach (['chat', 'chat_guest', 'ai_answers', 'ai_moderation', 'ai_summary'] as $k) feature_set($k, true);
  set_setting('ai_integrated', '1'); cache_clear(); return true;
}
route('GET', '#^/admin/ai$#', function () {
  admin_only(); $dbOk = true; try { q('SELECT 1 FROM ai_providers LIMIT 1'); } catch (Throwable $e) { $dbOk = false; }
  $provs = ai_all_providers(true);
  foreach ($provs as &$p) {
    $p['cd'] = q('SELECT until_at,reason FROM ai_cooldown WHERE provider=? AND until_at>NOW()', [$p['name']])->fetch() ?: null;
    $p['used'] = (int)q('SELECT COUNT(*) FROM ai_log WHERE provider=? AND ok=1 AND created_at>=CURDATE()', [$p['name']])->fetchColumn(); $p['mask'] = secret_mask((string)$p['key']);
  } unset($p);
  $aiFeatures = []; foreach (['chat', 'chat_guest', 'ai_answers', 'ai_moderation', 'ai_summary', 'ai_articles', 'ai_quizgen'] as $k) $aiFeatures[$k] = [feature_defs()[$k][1], feature($k)];
  render('admin_ai', ['provs' => $provs, 'presets' => ai_presets(), 'strategy' => setting('ai_strategy', 'priority'), 'dbOk' => $dbOk, 'aiFeatures' => $aiFeatures, 'active' => count(ai_providers())], 'Quản lý AI - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/ai$#', function () {
  admin_only(); @set_time_limit(240); $act = (string)($_POST['act'] ?? ''); $id = (int)($_POST['id'] ?? 0); audit('ai:'.$act, '#'.$id);
  $txt = fn(string $k, int $n = 255) => mb_substr(trim((string)($_POST[$k] ?? '')), 0, $n);
  switch ($act) {
    case 'add':
      $type = in_array($_POST['ptype'] ?? '', ['anthropic', 'openai'], true) ? $_POST['ptype'] : 'openai'; $base = $txt('base_url'); $model = $txt('model', 120); $key = $txt('api_key', 600); $label = $txt('label', 80) ?: ai_presets()[$_POST['preset'] ?? '']['0'] ?? 'AI';
      $cands = (array)(ai_presets()[$_POST['preset'] ?? '']['6'] ?? []);
      if ($key === '' || ($type === 'openai' && !preg_match('#^https://#i', $base))) { flash('Cần API key/token và (với loại OpenAI-tương thích) địa chỉ base URL bắt đầu bằng https://', 'err'); break; }
      if ($model === '') { [$mc, $mids] = ai_models(['type' => $type, 'key' => $key, 'base_url' => $base]); $model = ai_pick_model($mids) ?: ($cands[0] ?? ''); }
      if ($model === '') { flash('Không tự chọn được model. Hãy nhập tên model (dùng nút "Danh sách model" sau khi lưu để xem model khả dụng).', 'err'); break; }
      $name = mb_substr(slugify($label), 0, 36); $base0 = $name; $i = 2; while (q('SELECT 1 FROM ai_providers WHERE name=?', [$name])->fetchColumn()) $name = $base0.'-'.$i++;
      q('INSERT INTO ai_providers(name,label,ptype,base_url,model,api_key,priority,daily_limit,is_fallback,chat_only,price_in,price_out,vision,active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,0)',
        [$name, $label, $type, $type === 'anthropic' ? '' : $base, $model, secret_enc($key), (int)($_POST['priority'] ?? 100), ((int)($_POST['daily_limit'] ?? 0)) ?: null, !empty($_POST['is_fallback']) ? 1 : 0, !empty($_POST['chat_only']) ? 1 : 0, max(0, (float)($_POST['price_in'] ?? 0)), max(0, (float)($_POST['price_out'] ?? 0)), !empty($_POST['vision']) ? 1 : 0]);
      $nid = (int)db()->lastInsertId(); [$ok, $note] = ai_run_test($nid, $cands);
      if ($ok) { q('UPDATE ai_providers SET active=1 WHERE id=?', [$nid]); flash("✔ Đã thêm \"$label\" và kiểm tra thành công: $note", 'ok'); if (ai_autointegrate()) flash('Đã tự động bật các tính năng AI: Trợ lý chat, AI trả lời câu hỏi, kiểm duyệt, tóm tắt.', 'ok'); }
      else flash("⚠ Đã lưu \"$label\" nhưng kiểm tra thất bại (đang tắt): $note. Hãy kiểm tra key/model rồi bấm \"Kiểm tra\".", 'err');
      break;
    case 'save':
      q('UPDATE ai_providers SET label=?,model=?,base_url=?,priority=?,daily_limit=?,is_fallback=?,chat_only=?,price_in=?,price_out=?,monthly_limit=?,monthly_budget_usd=?,vision=? WHERE id=?', [$txt('label', 80), $txt('model', 120), $txt('base_url'), (int)($_POST['priority'] ?? 100), ((int)($_POST['daily_limit'] ?? 0)) ?: null, !empty($_POST['is_fallback']) ? 1 : 0, !empty($_POST['chat_only']) ? 1 : 0,
        max(0, (float)($_POST['price_in'] ?? 0)), max(0, (float)($_POST['price_out'] ?? 0)), ((int)($_POST['monthly_limit'] ?? 0)) ?: null, ((float)($_POST['monthly_budget_usd'] ?? 0)) ?: null, !empty($_POST['vision']) ? 1 : 0, $id]);
      if ($txt('api_key', 600) !== '') q('UPDATE ai_providers SET api_key=? WHERE id=?', [secret_enc($txt('api_key', 600)), $id]);
      flash('Đã lưu. Bấm "Kiểm tra" để thử lại.', 'ok'); break;
    case 'test':
      [$ok, $note] = ai_run_test($id); flash(($ok ? '✔ ' : '✘ ').$note, $ok ? 'ok' : 'err');
      if ($ok && !q('SELECT active FROM ai_providers WHERE id=?', [$id])->fetchColumn()) { q('UPDATE ai_providers SET active=1 WHERE id=?', [$id]); if (ai_autointegrate()) flash('Đã tự động bật các tính năng AI.', 'ok'); }
      break;
    case 'toggle': q('UPDATE ai_providers SET active=1-active WHERE id=?', [$id]); break;
    case 'delete': q('DELETE FROM ai_providers WHERE id=?', [$id]); break;
    case 'models':
      $p = ai_provider_row($id); if ($p) { [$c, $ids, $raw] = ai_models($p); flash($ids ? 'Model khả dụng ('.count($ids).'): '.implode(', ', array_slice($ids, 0, 40)) : "Không lấy được danh sách model (HTTP $c): ".mb_substr($raw, 0, 160), $ids ? 'info' : 'err'); } break;
    case 'strategy': set_setting('ai_strategy', ($_POST['strategy'] ?? '') === 'round_robin' ? 'round_robin' : 'priority'); flash('Đã lưu chiến lược gọi AI.', 'ok'); break;
    case 'integrate': ai_autointegrate(true); flash('Đã bật toàn bộ tính năng AI cơ bản (chat, AI trả lời, kiểm duyệt, tóm tắt).', 'ok'); break;
    case 'reset_cd': q('DELETE FROM ai_cooldown WHERE provider=?', [(string)($_POST['pname'] ?? '')]); flash('Đã bật lại AI này ngay.', 'ok'); break;
    case 'import_config':
      $n = 0; foreach ((array)cfg('ai.providers', []) as $p) {
        if (empty($p['key']) || empty($p['name']) || q('SELECT 1 FROM ai_providers WHERE name=?', [$p['name']])->fetchColumn()) continue;
        q('INSERT INTO ai_providers(name,label,ptype,base_url,model,api_key,priority,daily_limit,active) VALUES(?,?,?,?,?,?,?,?,1)', [mb_substr((string)$p['name'], 0, 40), (string)$p['name'], ($p['type'] ?? '') === 'anthropic' ? 'anthropic' : 'openai', (string)($p['base_url'] ?? ''), (string)($p['model'] ?? ''), secret_enc((string)$p['key']), 100 + $n, $p['daily_limit'] ?? null]); $n++;
      }
      flash("Đã nhập $n AI từ config.local.php. Bạn có thể xóa mục 'providers' trong config sau khi kiểm tra.", 'ok'); break;
  }
  ai_all_providers(true); cache_clear(); redirect('/admin/ai');
});
