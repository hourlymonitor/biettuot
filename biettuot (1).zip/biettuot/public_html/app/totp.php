<?php
// Xác thực hai lớp (TOTP - RFC 6238, tương thích Google Authenticator/Authy/Microsoft Authenticator)
function b32_encode(string $s): string {
  $al = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; $out = '';
  foreach (str_split($s) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
  foreach (str_split($bits, 5) as $chunk) $out .= $al[bindec(str_pad($chunk, 5, '0'))];
  return $out;
}
function b32_decode(string $s): string {
  $al = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $s = strtoupper(preg_replace('/[^A-Z2-7]/i', '', $s)); $bits = '';
  foreach (str_split($s) as $c) $bits .= str_pad(decbin(strpos($al, $c)), 5, '0', STR_PAD_LEFT);
  $out = ''; foreach (str_split($bits, 8) as $b) if (strlen($b) === 8) $out .= chr(bindec($b));
  return $out;
}
function totp_code(string $raw, int $counter): string {
  $h = hash_hmac('sha1', pack('N*', 0).pack('N*', $counter), $raw, true); $o = ord($h[19]) & 0xf;
  $v = ((ord($h[$o]) & 0x7f) << 24) | ((ord($h[$o + 1]) & 0xff) << 16) | ((ord($h[$o + 2]) & 0xff) << 8) | (ord($h[$o + 3]) & 0xff);
  return str_pad((string)($v % 1000000), 6, '0', STR_PAD_LEFT);
}
function totp_verify(string $secretB32, string $code): bool {
  $code = preg_replace('/\D/', '', $code); if (strlen($code) !== 6) return false; $raw = b32_decode($secretB32); $c = (int)floor(time() / 30);
  foreach ([-1, 0, 1] as $d) if (hash_equals(totp_code($raw, $c + $d), $code)) return true;
  return false;
}
function totp_uri(string $secretB32, string $account): string { return 'otpauth://totp/'.rawurlencode('Biết Tuốt:'.$account).'?secret='.$secretB32.'&issuer='.rawurlencode('Biết Tuốt').'&digits=6&period=30'; }
function totp_make_recovery(): array { $codes = $hashes = []; for ($i = 0; $i < 8; $i++) { $c = bin2hex(random_bytes(5)); $codes[] = $c; $hashes[] = hash('sha256', $c); } return [$codes, $hashes]; }
// Dùng mã khôi phục (mỗi mã dùng 1 lần). Trả về true nếu hợp lệ.
function totp_use_recovery(int $uid, string $code): bool {
  $code = strtolower(trim($code)); if (!preg_match('/^[a-f0-9]{10}$/', $code)) return false;
  $list = json_decode((string)q('SELECT totp_recovery FROM users WHERE id=?', [$uid])->fetchColumn(), true) ?: []; $h = hash('sha256', $code); $i = array_search($h, $list, true);
  if ($i === false) return false; unset($list[$i]); q('UPDATE users SET totp_recovery=? WHERE id=?', [json_encode(array_values($list)), $uid]); return true;
}
