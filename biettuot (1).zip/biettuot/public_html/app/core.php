<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Ho_Chi_Minh');
if (!is_file(__DIR__.'/config.local.php')) { http_response_code(500); exit('Thiếu app/config.local.php - hãy sao chép từ config.sample.php'); }
$CFG = require __DIR__.'/config.local.php';

@ini_set('display_errors', '0');
function app_log(string $m): void {
  $d = ROOT.'/app/logs'; if (!is_dir($d)) @mkdir($d, 0755, true); $f = $d.'/error.log';
  if (is_file($f) && filesize($f) > 1048576) @file_put_contents($f, '');
  @file_put_contents($f, '['.date('Y-m-d H:i:s').'] '.$m."\n", FILE_APPEND | LOCK_EX);
}
set_exception_handler(function (Throwable $e) {
  app_log(get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().' ['.($_SERVER['REQUEST_URI'] ?? '').']');
  while (ob_get_level()) ob_end_clean();
  http_response_code(500);
  echo '<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Có lỗi xảy ra</title><body style="font-family:system-ui;max-width:520px;margin:15vh auto;padding:0 16px"><h1>Có lỗi xảy ra</h1><p>Xin lỗi, hệ thống gặp sự cố. Hãy thử lại sau ít phút.</p><p><a href="/">Về trang chủ</a></p></body></html>';
});
set_error_handler(function (int $no, string $str, string $file, int $line) {
  if (!(error_reporting() & $no)) return false;   // lệnh có dấu @ thì bỏ qua
  if ($no & (E_WARNING | E_USER_WARNING | E_USER_ERROR | E_RECOVERABLE_ERROR)) app_log("PHP[$no]: $str @ ".basename($file).':'.$line);
  return true;
});
register_shutdown_function(function () {
  $e = error_get_last(); if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) app_log('FATAL: '.$e['message'].' @ '.basename($e['file']).':'.$e['line']);
});

function cfg(string $path, $def = null) {
  global $CFG; $v = $CFG;
  foreach (explode('.', $path) as $k) { if (!is_array($v) || !array_key_exists($k, $v)) return $def; $v = $v[$k]; }
  return $v;
}
function db(bool $reset = false): PDO {
  static $pdo;
  if ($reset) $pdo = null;
  if (!$pdo) {
    $c = cfg('db');
    $pdo = new PDO("mysql:host={$c['host']};dbname={$c['name']};charset=utf8mb4", $c['user'], $c['pass'],
      [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]);
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("SET time_zone='+07:00'");
  }
  return $pdo;
}
// Tự kết nối lại 1 lần nếu máy chủ MySQL ngắt kết nối (ví dụ sau khi chờ AI lâu).
function q(string $sql, array $p = []): PDOStatement {
  for ($try = 0;; $try++) {
    try { $s = db()->prepare($sql); $s->execute($p); return $s; }
    catch (PDOException $e) {
      $m = $e->getMessage();
      if ($try === 0 && !db()->inTransaction() && (str_contains($m, 'gone away') || str_contains($m, 'Lost connection') || str_contains($m, '2006') || str_contains($m, '2013'))) { db(true); continue; }
      throw $e;
    }
  }
}
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $p = ''): string { return rtrim((string)cfg('base_url'), '/').$p; }
function redirect(string $to, int $code = 302) { header('Location: '.$to, true, $code); exit; }
function safe_path(?string $p): string { $p = (string)$p; return (($p[0] ?? '') === '/' && ($p[1] ?? '') !== '/') ? $p : '/'; }

session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']), 'httponly' => true, 'samesite' => 'Lax']);
session_start();
header('X-Frame-Options: SAMEORIGIN'); header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: strict-origin-when-cross-origin');

function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); }
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="'.csrf_token().'">'; }
function csrf_check(): void {
  if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_POST['_csrf'] ?? ''))) { http_response_code(419); exit('Phiên làm việc đã hết hạn, hãy quay lại và tải lại trang.'); }
}
function back_field(): string { return '<input type="hidden" name="back" value="'.e($_SERVER['REQUEST_URI'] ?? '/').'">'; }

function flash(?string $msg = null, string $type = 'info') {
  if ($msg !== null) { $_SESSION['flash'][] = [$type, $msg]; return null; }
  $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f;
}
function me(): ?array {
  static $u = false;
  if ($u === false) $u = isset($_SESSION['uid']) ? (q('SELECT * FROM users WHERE id=? AND banned=0', [$_SESSION['uid']])->fetch() ?: null) : null;
  return $u;
}
function is_admin(): bool { return (me()['role'] ?? '') === 'admin'; }
function require_login(): array {
  if (!me()) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') $_SESSION['next'] = $_SERVER['REQUEST_URI'];
    flash('Hãy đăng nhập để tiếp tục.'); redirect('/dang-nhap');
  }
  return me();
}
function over_limit(string $table, string $col, int $uid, int $max, string $extra = ''): bool {
  return (int)q("SELECT COUNT(*) FROM $table WHERE $col=? AND created_at>=CURDATE() $extra", [$uid])->fetchColumn() >= $max;
}
function render(string $view, array $v = [], string $title = '', string $desc = '', array $opt = []): void {
  extract($v); ob_start(); include ROOT.'/app/views/'.$view.'.php'; $content = ob_get_clean();
  $title = $title ?: (string)cfg('site_name'); $cache = !empty($opt['cache']) && page_cacheable();
  if ($cache) ob_start();
  include ROOT.'/app/views/layout.php';
  if ($cache) { $html = ob_get_clean(); echo $html; $cd = ROOT.'/app/cache'; if (!is_dir($cd)) @mkdir($cd, 0755, true); @file_put_contents(cache_file(), $html, LOCK_EX); }
}
function not_found() { http_response_code(404); render('404', [], 'Không tìm thấy trang', '', ['noindex' => true]); exit; }

function slugify(string $s): string {
  $from = 'àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ';
  $to = str_repeat('a', 17).str_repeat('e', 11).str_repeat('i', 5).str_repeat('o', 17).str_repeat('u', 11).str_repeat('y', 5).'d';
  $s = strtr(mb_strtolower($s), array_combine(mb_str_split($from), str_split($to)));
  $s = trim(preg_replace('/[^a-z0-9]+/', '-', $s), '-');
  return mb_substr($s, 0, 80) ?: 'cau-hoi';
}
function ago(string $dt): string {
  $d = time() - strtotime($dt);
  if ($d < 60) return 'vừa xong'; if ($d < 3600) return intdiv($d, 60).' phút trước';
  if ($d < 86400) return intdiv($d, 3600).' giờ trước'; if ($d < 2592000) return intdiv($d, 86400).' ngày trước';
  return date('d/m/Y', strtotime($dt));
}
// Hiển thị văn bản an toàn: escape trước, rồi mới hỗ trợ **đậm** và danh sách "- ".
function md_lite(string $t): string {
  $t = preg_replace('/^#+\s*/m', '', e(trim($t)));
  $t = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', $t);
  $out = ''; $list = false;
  foreach (preg_split('/\R/', $t) as $l) {
    if (preg_match('/^\s*[-*•]\s+(.*)$/', $l, $m)) { if (!$list) { $out .= '<ul>'; $list = true; } $out .= '<li>'.$m[1].'</li>'; continue; }
    if ($list) { $out .= '</ul>'; $list = false; }
    if (trim($l) !== '') $out .= '<p>'.$l.'</p>';
  }
  return $out.($list ? '</ul>' : '');
}
function report_form(string $type, int $id): string {
  return '<form method="post" action="/bao-cao" class="inline">'.csrf_field().back_field()
    .'<input type="hidden" name="type" value="'.e($type).'"><input type="hidden" name="id" value="'.$id.'">'
    .'<input name="reason" placeholder="Lý do báo cáo" maxlength="255" required><button class="btn sm">Gửi</button></form>';
}
