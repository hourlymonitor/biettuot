<?php
// ---------- Tài khoản: xác minh email, quên mật khẩu, cài đặt, hồ sơ, thông báo, theo dõi, premium, menu, PWA ----------
route('GET', '#^/xac-minh$#', function () {
  $uid = token_use((string)($_GET['t'] ?? ''), 'verify');
  if ($uid) { q('UPDATE users SET email_verified=1 WHERE id=?', [$uid]); flash('Đã xác minh email. Cảm ơn bạn!', 'ok'); } else flash('Liên kết xác minh không hợp lệ hoặc đã hết hạn.', 'err');
  redirect(me() ? '/cai-dat' : '/dang-nhap');
});
route('POST', '#^/xac-minh/gui-lai$#', function () {
  $u = require_login(); if ($u['email_verified']) redirect('/cai-dat');
  if ((int)q("SELECT COUNT(*) FROM tokens WHERE user_id=? AND type='verify' AND created_at>DATE_SUB(NOW(),INTERVAL 2 MINUTE)", [$u['id']])->fetchColumn()) flash('Hãy đợi 2 phút trước khi gửi lại.', 'err');
  else { send_verification((int)$u['id'], $u['email'], $u['username']); flash('Đã gửi lại email xác minh.', 'ok'); }
  redirect('/cai-dat');
});
route('GET', '#^/quen-mat-khau$#', fn() => render('auth', ['mode' => 'forgot'], 'Quên mật khẩu - '.cfg('site_name'), '', ['noindex' => true]));
route('POST', '#^/quen-mat-khau$#', function () {
  if (!turnstile_ok()) { render('auth', ['mode' => 'forgot', 'err' => 'Xác minh chống robot không thành công, hãy thử lại.'], 'Quên mật khẩu', '', ['noindex' => true]); return; }
  $u = q('SELECT id,username,email FROM users WHERE email=? AND banned=0', [strtolower(trim((string)($_POST['email'] ?? '')))])->fetch();
  if ($u && (int)q("SELECT COUNT(*) FROM tokens WHERE user_id=? AND type='reset' AND created_at>DATE_SUB(NOW(),INTERVAL 10 MINUTE)", [$u['id']])->fetchColumn() < 3) {
    $link = url('/dat-lai-mat-khau?t='.token_make((int)$u['id'], 'reset', 2));
    $body = "Chào {$u['username']},\n\nBấm vào liên kết sau để đặt lại mật khẩu (hiệu lực 2 giờ):\n$link\n\nNếu bạn không yêu cầu, hãy bỏ qua thư này.";
    if (!send_mail($u['email'], 'Đặt lại mật khẩu Biết Tuốt', $body)) job_add('mail', 0, ['to' => $u['email'], 'subject' => 'Đặt lại mật khẩu Biết Tuốt', 'body' => $body]);
  }
  flash('Nếu email tồn tại trong hệ thống, chúng tôi đã gửi hướng dẫn đặt lại mật khẩu.', 'ok'); redirect('/dang-nhap');
});
route('GET', '#^/dat-lai-mat-khau$#', function () {
  $t = (string)($_GET['t'] ?? '');
  if (!token_peek($t, 'reset')) { flash('Liên kết không hợp lệ hoặc đã hết hạn.', 'err'); redirect('/quen-mat-khau'); }
  render('auth', ['mode' => 'reset', 'token' => $t], 'Đặt lại mật khẩu', '', ['noindex' => true]);
});
route('POST', '#^/dat-lai-mat-khau$#', function () {
  $t = (string)($_POST['t'] ?? ''); $pw = (string)($_POST['password'] ?? '');
  if (strlen($pw) < 8) { render('auth', ['mode' => 'reset', 'token' => $t, 'err' => 'Mật khẩu tối thiểu 8 ký tự.'], 'Đặt lại mật khẩu', '', ['noindex' => true]); return; }
  $uid = token_use($t, 'reset'); if (!$uid) { flash('Liên kết không hợp lệ hoặc đã hết hạn.', 'err'); redirect('/quen-mat-khau'); }
  q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash($pw, PASSWORD_DEFAULT), $uid]); q("UPDATE tokens SET used=1 WHERE user_id=? AND type='reset'", [$uid]);
  flash('Đã đổi mật khẩu. Hãy đăng nhập lại.', 'ok'); redirect('/dang-nhap');
});

route('GET', '#^/cai-dat$#', function () {
  $u = fresh_user((int)require_login()['id']); $code = ensure_ref_code((int)$u['id']);
  $refs = (int)q('SELECT COUNT(*) FROM users WHERE referred_by=?', [$u['id']])->fetchColumn();
  $earned = (int)q("SELECT COUNT(*) FROM point_ledger WHERE user_id=? AND kind='referral' AND status<>'reversed'", [$u['id']])->fetchColumn();
  $pushPub = feature('push') ? (string)setting('vapid_pub', '') : '';
  $nl = feature('newsletter') ? (bool)q('SELECT 1 FROM newsletter_subs WHERE user_id=? AND unsub_at IS NULL AND confirmed=1', [$u['id']])->fetchColumn() : false;
  render('settings', compact('u', 'code', 'refs', 'earned', 'pushPub', 'nl'), 'Cài đặt - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/cai-dat$#', function () {
  $u = require_login();
  q('UPDATE users SET bio=?,email_notify=? WHERE id=?', [mb_substr(trim((string)($_POST['bio'] ?? '')), 0, 200), !empty($_POST['email_notify']) ? 1 : 0, $u['id']]);
  $bd = (string)($_POST['birthday'] ?? '');   // ngày sinh chỉ đặt được 1 lần (chống lạm dụng quà sinh nhật); admin có thể sửa
  if ($bd !== '' && !fresh_user((int)$u['id'])['birthday_set'] && preg_match('/^\d{4}-\d{2}-\d{2}$/', $bd) && strtotime($bd) && $bd <= date('Y-m-d', strtotime('-6 years')) && $bd >= '1920-01-01')
    q('UPDATE users SET birthday=?,birthday_set=1 WHERE id=?', [$bd, $u['id']]);
  if (feature('newsletter')) {
    if (!empty($_POST['newsletter'])) { $f0 = fresh_user((int)$u['id']); $ns = news_subscribe($f0['email'], (int)$u['id'], (bool)$f0['email_verified']); if ($ns && !$ns['confirmed']) { news_confirm_mail($ns); flash('Hãy kiểm tra email để xác nhận đăng ký bản tin.', 'ok'); } }
    else q('UPDATE newsletter_subs SET unsub_at=NOW() WHERE user_id=? AND unsub_at IS NULL', [$u['id']]);
  }
  $new = (string)($_POST['new_password'] ?? '');
  if ($new === '') flash('Đã lưu cài đặt.', 'ok');
  elseif (!password_verify((string)($_POST['cur_password'] ?? ''), fresh_user((int)$u['id'])['pass_hash'])) flash('Mật khẩu hiện tại không đúng.', 'err');
  elseif (strlen($new) < 8) flash('Mật khẩu mới tối thiểu 8 ký tự.', 'err');
  else { q('UPDATE users SET pass_hash=? WHERE id=?', [password_hash($new, PASSWORD_DEFAULT), $u['id']]); flash('Đã lưu cài đặt và đổi mật khẩu.', 'ok'); }
  redirect('/cai-dat');
});
route('GET', '#^/thong-bao$#', function () {
  $u = require_login(); $items = q('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50', [$u['id']])->fetchAll();
  q('UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0', [$u['id']]);
  render('notifications', compact('items'), 'Thông báo - '.cfg('site_name'), '', ['noindex' => true]);
});
route('GET', '#^/api/thong-bao-moi$#', function () {
  header('Content-Type: application/json; charset=utf-8'); $u = me();
  $n = $u ? q('SELECT * FROM notifications WHERE user_id=? AND is_read=0 ORDER BY id DESC LIMIT 1', [$u['id']])->fetch() : null;
  echo json_encode($n ? ['title' => 'Biết Tuốt', 'body' => $n['text'], 'url' => $n['url']] : ['title' => 'Biết Tuốt', 'body' => 'Bạn có thông báo mới', 'url' => '/thong-bao'], JSON_UNESCAPED_UNICODE);
});
route('POST', '#^/theo-doi$#', function () {
  $u = require_login(); $type = in_array($_POST['type'] ?? '', ['question', 'user', 'category'], true) ? $_POST['type'] : null; $id = (int)($_POST['id'] ?? 0);
  if ($type && $id && !($type === 'user' && $id === (int)$u['id'])) follow_set((int)$u['id'], $type, $id, !is_following((int)$u['id'], $type, $id));
  redirect(safe_path($_POST['back'] ?? '/'));
});
route('GET', '#^/u/([A-Za-z0-9_]{3,30})$#', function ($name) {
  $p = q('SELECT id,username,role,xp,bio,created_at,streak,premium_until,expert_title FROM users WHERE username=? AND banned=0', [$name])->fetch(); if (!$p) not_found(); $uid = (int)$p['id'];
  $st = user_stats($uid); $badges = q('SELECT code FROM user_badges WHERE user_id=? ORDER BY created_at', [$uid])->fetchAll(PDO::FETCH_COLUMN);
  $best = q("SELECT a.id,q.id qid,q.slug,q.title FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.user_id=? AND a.is_best=1 AND a.status='published' AND q.status='published' ORDER BY a.id DESC LIMIT 5", [$uid])->fetchAll();
  $recA = q("SELECT a.id,q.id qid,q.slug,q.title,a.score FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.user_id=? AND a.is_ai=0 AND a.status='published' AND q.status='published' ORDER BY a.id DESC LIMIT 8", [$uid])->fetchAll();
  $recQ = q("SELECT id,slug,title,answers_count FROM questions WHERE user_id=? AND status='published' ORDER BY id DESC LIMIT 8", [$uid])->fetchAll();
  $followers = (int)q("SELECT COUNT(*) FROM follows WHERE type='user' AND target_id=?", [$uid])->fetchColumn();
  $pcats = q('SELECT c.name,c.icon,c.slug FROM mod_categories m JOIN categories c ON c.id=m.category_id WHERE m.user_id=?', [$uid])->fetchAll();
  $parts = feature('articles') ? q("SELECT id,slug,title FROM articles WHERE author_id=? AND status='published' ORDER BY published_at DESC LIMIT 6", [$uid])->fetchAll() : [];
  render('profile', compact('p', 'st', 'badges', 'best', 'recA', 'recQ', 'followers', 'pcats', 'parts'), $p['username'].' - '.cfg('site_name'), mb_substr($p['bio'], 0, 150), ['cache' => true]);
});
route('GET', '#^/menu$#', fn() => render('menu', [], 'Menu - '.cfg('site_name'), '', ['noindex' => true]));
route('GET', '#^/goi-thanh-vien$#', function () {
  $me = me() ? fresh_user((int)me()['id']) : null;
  $pend = $me ? q("SELECT plan FROM premium_requests WHERE user_id=? AND status='pending' LIMIT 1", [$me['id']])->fetchColumn() : false;
  render('premium', ['me' => $me, 'pend' => $pend, 'info' => (string)setting('premium_pay_info', ''), 'plans' => premium_plans(), 'payAuto' => pay_enabled()], 'Gói thành viên Premium - '.cfg('site_name'), 'Premium: nhiều điểm hơn, nhiều lượt AI hơn, không quảng cáo, quà sinh nhật và lễ tết.');
});
route('POST', '#^/goi-thanh-vien$#', function () {
  $u = require_verified(true); $plan = array_key_exists($_POST['plan'] ?? '', premium_plans()) ? $_POST['plan'] : 'month';
  if (pay_enabled()) {
    $order = pay_create_order((int)$u['id'], $plan, (string)($_POST['coupon'] ?? ''));
    if (is_string($order)) { flash($order, 'err'); redirect('/goi-thanh-vien'); }
    redirect('/thanh-toan/'.$order['code']);
  }
  if (!q("SELECT 1 FROM premium_requests WHERE user_id=? AND status='pending'", [$u['id']])->fetchColumn()) q('INSERT INTO premium_requests(user_id,plan,note) VALUES(?,?,?)', [$u['id'], $plan, mb_substr(trim((string)($_POST['note'] ?? '')), 0, 255)]);
  flash('Đã gửi yêu cầu. Quản trị viên sẽ kích hoạt sau khi xác nhận thanh toán.', 'ok'); redirect('/goi-thanh-vien');
});
route('GET', '#^/offline$#', fn() => render('offline', [], 'Ngoại tuyến - '.cfg('site_name'), '', ['noindex' => true]));
route('GET', '#^/push/khoa$#', function () { header('Content-Type: application/json'); echo json_encode(['key' => feature('push') ? (string)setting('vapid_pub', '') : '']); });
route('POST', '#^/push/dang-ky$#', function () {
  $u = require_login(); $ep = (string)($_POST['endpoint'] ?? ''); header('Content-Type: application/json');
  if (strncmp($ep, 'https://', 8) === 0 && filter_var($ep, FILTER_VALIDATE_URL)) q('INSERT INTO push_subs(user_id,endpoint,endpoint_hash) VALUES(?,?,?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id)', [$u['id'], $ep, md5($ep)]);
  echo '{"ok":true}';
});
route('POST', '#^/push/huy$#', function () { $u = require_login(); q('DELETE FROM push_subs WHERE user_id=?', [$u['id']]); header('Content-Type: application/json'); echo '{"ok":true}'; });
