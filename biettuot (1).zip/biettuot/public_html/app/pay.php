<?php
// Thanh toán Premium bằng chuyển khoản QR (VietQR) + tự đối soát qua webhook SePay / Casso.
function pay_cfg(): array {
  return ['bank' => (string)setting('pay_bank', ''), 'acc' => (string)setting('pay_account_no', ''), 'name' => (string)setting('pay_account_name', ''),
    'tpl' => (string)setting('pay_template', 'compact2'), 'provider' => (string)setting('pay_provider', 'manual'), 'expiry' => max(10, (int)setting('pay_expiry_min', '60'))];
}
function pay_enabled(): bool { $c = pay_cfg(); return feature('pay_auto') && $c['bank'] !== '' && $c['acc'] !== ''; }
function pay_new_code(): string {
  $al = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  do { $c = 'BT'; for ($i = 0; $i < 8; $i++) $c .= $al[random_int(0, strlen($al) - 1)]; } while (q('SELECT 1 FROM payment_orders WHERE code=?', [$c])->fetchColumn());
  return $c;
}
// Trả về [số tiền giảm, dòng coupon|null] hoặc chuỗi lỗi
function pay_coupon(string $code, string $plan, int $base) {
  $code = strtoupper(trim($code)); if ($code === '') return [0, null];
  $c = q('SELECT * FROM coupons WHERE code=? AND active=1', [$code])->fetch();
  if (!$c) return 'Mã giảm giá không hợp lệ.';
  if ($c['expires_at'] && strtotime($c['expires_at']) < time()) return 'Mã giảm giá đã hết hạn.';
  if ((int)$c['max_uses'] > 0 && (int)$c['uses'] >= (int)$c['max_uses']) return 'Mã giảm giá đã hết lượt sử dụng.';
  if ($c['plan'] !== '' && $c['plan'] !== $plan) return 'Mã này không áp dụng cho gói đã chọn.';
  $d = $c['kind'] === 'percent' ? (int)floor($base * min(100, (int)$c['value']) / 100) : (int)$c['value'];
  return [min($d, max(0, $base - 1000)), $c];
}
// Trả về dòng đơn hàng (mảng) hoặc chuỗi lỗi
function pay_create_order(int $uid, string $plan, string $coupon = '') {
  $plans = premium_plans(); if (!isset($plans[$plan])) return 'Gói không hợp lệ.';
  $base = (int)$plans[$plan]['price']; if ($base < 1000) return 'Giá gói chưa được cấu hình.';
  $r = pay_coupon($coupon, $plan, $base); if (is_string($r)) return $r; [$disc, $crow] = $r; $amount = max(1000, $base - $disc);
  q("UPDATE payment_orders SET status='expired' WHERE status='pending' AND expires_at<NOW()");
  $ex = q("SELECT * FROM payment_orders WHERE user_id=? AND plan=? AND amount=? AND status='pending' AND expires_at>NOW() ORDER BY id DESC LIMIT 1", [$uid, $plan, $amount])->fetch(); if ($ex) return $ex;
  if ((int)q('SELECT COUNT(*) FROM payment_orders WHERE user_id=? AND created_at>=CURDATE()', [$uid])->fetchColumn() >= 8) return 'Bạn đã tạo quá nhiều đơn hôm nay. Hãy thử lại ngày mai hoặc liên hệ quản trị viên.';
  $cfg = pay_cfg(); $code = pay_new_code();
  q("INSERT INTO payment_orders(user_id,plan,base_amount,discount,amount,coupon,code,status,provider,expires_at) VALUES(?,?,?,?,?,?,?,'pending',?,DATE_ADD(NOW(),INTERVAL ? MINUTE))",
    [$uid, $plan, $base, $disc, $amount, $crow['code'] ?? null, $code, $cfg['provider'], $cfg['expiry']]);
  return q('SELECT * FROM payment_orders WHERE code=?', [$code])->fetch();
}
function pay_qr_url(array $o): string {
  $c = pay_cfg();
  return 'https://img.vietqr.io/image/'.rawurlencode($c['bank']).'-'.rawurlencode($c['acc']).'-'.rawurlencode($c['tpl'] ?: 'compact2').'.png?amount='.(int)$o['amount'].'&addInfo='.rawurlencode($o['code']).'&accountName='.rawurlencode($c['name']);
}
function pay_mark_paid(int $orderId, string $provider, string $txId): bool {
  $o = q('SELECT * FROM payment_orders WHERE id=?', [$orderId])->fetch(); if (!$o) return false;
  if (!q("UPDATE payment_orders SET status='paid',paid_at=NOW(),provider=?,tx_id=? WHERE id=? AND status IN ('pending','expired')", [$provider, $txId, $orderId])->rowCount()) return false;
  $pl = premium_plans()[$o['plan']] ?? []; $days = (int)($pl['days'] ?? 30); $pn = $pl['name'] ?? 'Premium';
  q('UPDATE users SET premium_until=DATE_ADD(GREATEST(NOW(),COALESCE(premium_until,NOW())),INTERVAL ? DAY) WHERE id=?', [$days, $o['user_id']]);
  if ($o['coupon']) q('UPDATE coupons SET uses=uses+1 WHERE code=?', [$o['coupon']]);
  notify((int)$o['user_id'], 'premium', "✅ Thanh toán thành công: $pn đã được kích hoạt (+$days ngày). Cảm ơn bạn!", '/cai-dat', true);
  cache_clear(); return true;
}
function pay_norm(string $s): string { return preg_replace('/[^A-Z0-9]/', '', strtoupper($s)); }
// Xử lý một giao dịch tiền vào (idempotent theo provider + tx_id). Trả về mô tả kết quả.
function pay_handle_tx(string $provider, string $txId, int $amount, string $content, string $raw): string {
  if (!q('INSERT IGNORE INTO payment_tx(provider,tx_id,amount,content,result,raw) VALUES(?,?,?,?,?,?)', [$provider, $txId, $amount, mb_substr($content, 0, 255), 'đang xử lý', mb_substr($raw, 0, 3000)])->rowCount()) return 'trùng';
  $row = (int)q('SELECT id FROM payment_tx WHERE provider=? AND tx_id=?', [$provider, $txId])->fetchColumn(); $res = 'không khớp đơn'; $oid = null;
  if (preg_match('/BT[A-HJ-NP-Z2-9]{8}/', pay_norm($content), $m)) {
    $o = q('SELECT * FROM payment_orders WHERE code=?', [$m[0]])->fetch();
    if ($o) {
      $oid = (int)$o['id'];
      if ($o['status'] === 'paid') $res = 'đơn đã thanh toán trước đó';
      elseif ($o['status'] === 'cancelled') $res = 'đơn đã hủy (cần xử lý tay)';
      elseif ($amount < (int)$o['amount']) $res = 'thiếu tiền (cần '.(int)$o['amount'].')';
      else $res = pay_mark_paid($oid, $provider, $txId) ? 'đã kích hoạt' : 'không kích hoạt được';
    }
  }
  q('UPDATE payment_tx SET result=?,order_id=? WHERE id=?', [$res, $oid, $row]); return $res;
}
