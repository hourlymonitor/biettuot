<?php
// ---------- Nội dung: sửa/xóa, bình luận, thẻ, bài viết, đố vui, liên kết tiếp thị, gộp câu hỏi, AI polling, cron ----------

route('GET', '#^/sua/cau-hoi/(\d+)$#', function ($id) {
  require_login(); $r = q('SELECT * FROM questions WHERE id=?', [$id])->fetch(); if (!$r || !can_edit($r)) not_found();
  render('edit', ['kind' => 'question', 'row' => $r, 'tags' => implode(', ', array_column(question_tags((int)$id), 'name'))], 'Sửa câu hỏi - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/sua/cau-hoi/(\d+)$#', function ($id) {
  $u = require_login(); $r = q('SELECT * FROM questions WHERE id=?', [$id])->fetch(); if (!$r || !can_edit($r)) not_found();
  $title = trim((string)($_POST['title'] ?? '')); $body = trim((string)($_POST['body'] ?? ''));
  if (mb_strlen($title) < 10 || mb_strlen($title) > 200 || mb_strlen($body) > 5000) { flash('Tiêu đề 10-200 ký tự, nội dung tối đa 5000 ký tự.', 'err'); redirect('/sua/cau-hoi/'.$id); }
  q('INSERT INTO content_edits(type,target_id,user_id,old_title,old_body) VALUES(?,?,?,?,?)', ['question', $id, $u['id'], $r['title'], $r['body']]);
  q('UPDATE questions SET title=?,body=?,edited_at=NOW() WHERE id=?', [$title, $body, $id]); set_tags((int)$id, (string)($_POST['tags'] ?? ''));
  cache_clear(); flash('Đã lưu chỉnh sửa.', 'ok'); redirect(qurl($r));
});
route('GET', '#^/sua/tra-loi/(\d+)$#', function ($id) {
  require_login(); $a = q('SELECT * FROM answers WHERE id=?', [$id])->fetch(); if (!$a || !can_edit($a)) not_found();
  render('edit', ['kind' => 'answer', 'row' => $a], 'Sửa câu trả lời - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/sua/tra-loi/(\d+)$#', function ($id) {
  $u = require_login(); $a = q('SELECT a.*,q.slug qslug,q.id qid FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.id=?', [$id])->fetch(); if (!$a || !can_edit($a)) not_found();
  $body = trim((string)($_POST['body'] ?? ''));
  if (mb_strlen($body) < 10 || mb_strlen($body) > 5000) { flash('Câu trả lời cần từ 10 đến 5000 ký tự.', 'err'); redirect('/sua/tra-loi/'.$id); }
  q('INSERT INTO content_edits(type,target_id,user_id,old_body) VALUES(?,?,?,?)', ['answer', $id, $u['id'], $a['body']]);
  q('UPDATE answers SET body=?,edited_at=NOW() WHERE id=?', [$body, $id]); cache_clear(); flash('Đã lưu chỉnh sửa.', 'ok'); redirect('/hoi/'.$a['qslug'].'-'.$a['qid'].'#a'.$id);
});
route('POST', '#^/xoa/tra-loi$#', function () {
  require_login(); $a = q('SELECT a.*,q.slug qslug,q.id qid FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.id=?', [(int)($_POST['id'] ?? 0)])->fetch(); if (!$a || !can_edit($a)) not_found();
  hide_answer((int)$a['id']); flash('Đã xóa câu trả lời.', 'ok'); redirect('/hoi/'.$a['qslug'].'-'.$a['qid']);
});
route('POST', '#^/xoa/cau-hoi$#', function () {
  require_login(); $r = q('SELECT * FROM questions WHERE id=?', [(int)($_POST['id'] ?? 0)])->fetch(); if (!$r || !can_edit($r)) not_found();
  $human = (int)q('SELECT COUNT(*) FROM answers WHERE question_id=? AND is_ai=0 AND status=\'published\'', [$r['id']])->fetchColumn();
  if ($human > 0 && !is_admin() && me()['role'] !== 'collab') { flash('Câu hỏi đã có người trả lời nên không thể xóa. Hãy sửa nội dung hoặc báo quản trị viên.', 'err'); redirect(qurl($r)); }
  hide_question((int)$r['id']); flash('Đã xóa câu hỏi.', 'ok'); redirect('/');
});

route('POST', '#^/binh-luan$#', function () {
  $u = require_verified(); $aid = (int)($_POST['answer_id'] ?? 0); $body = trim((string)($_POST['body'] ?? ''));
  $a = q("SELECT a.*,q.slug qslug,q.id qid FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.id=? AND a.status='published' AND q.status='published'", [$aid])->fetch(); if (!$a) not_found();
  $back = '/hoi/'.$a['qslug'].'-'.$a['qid'].'#a'.$aid;
  if (!empty($_POST['hp_note'])) redirect('/');
  if (mb_strlen($body) < 2 || mb_strlen($body) > 500) flash('Bình luận cần từ 2 đến 500 ký tự.', 'err');
  elseif (over_limit('comments', 'user_id', (int)$u['id'], (int)pc('limits.comments_per_day'))) flash('Bạn đã đạt giới hạn bình luận hôm nay.', 'err');
  else {
    q('INSERT INTO comments(answer_id,user_id,body) VALUES(?,?,?)', [$aid, $u['id'], $body]);
    if ($a['user_id'] && (int)$a['user_id'] !== (int)$u['id']) notify((int)$a['user_id'], 'comment', $u['username'].' đã bình luận câu trả lời của bạn', $back);
    cache_clear();
  }
  redirect($back);
});
route('POST', '#^/binh-luan/xoa$#', function () {
  $u = require_login(); $c = q('SELECT c.*,q.slug qslug,q.id qid FROM comments c JOIN answers a ON a.id=c.answer_id JOIN questions q ON q.id=a.question_id WHERE c.id=?', [(int)($_POST['id'] ?? 0)])->fetch(); if (!$c) not_found();
  if ((int)$c['user_id'] !== (int)$u['id'] && !is_admin() && $u['role'] !== 'collab') not_found();
  q("UPDATE comments SET status='hidden' WHERE id=?", [$c['id']]); cache_clear(); redirect('/hoi/'.$c['qslug'].'-'.$c['qid'].'#a'.$c['answer_id']);
});

route('GET', '#^/the/([a-z0-9-]+)$#', function ($slug) {
  $t = q('SELECT * FROM tags WHERE slug=?', [$slug])->fetch(); if (!$t) not_found(); $page = page_no();
  render('list', ['qs' => list_questions('AND q.id IN (SELECT question_id FROM question_tags WHERE tag_id=?)', [$t['id']], $page), 'heading' => '#'.$t['name'], 'sub' => 'Các câu hỏi gắn thẻ "'.$t['name'].'"', 'page' => $page, 'base' => '/the/'.$slug],
    'Thẻ '.$t['name'].' - '.cfg('site_name'), 'Câu hỏi và câu trả lời về '.$t['name'], ['cache' => true]);
});
function article_list(?array $cat): void {
  $page = page_no(); $p = []; $w = "a.status='published'"; if ($cat) { $w .= ' AND a.category_id=?'; $p[] = $cat['id']; }
  $items = q("SELECT a.id,a.slug,a.title,a.published_at,LEFT(a.body,220) ex,c.name cat,c.slug cslug,c.icon,u.username FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id WHERE $w ORDER BY a.published_at DESC LIMIT 20 OFFSET ".(($page - 1) * 20), $p)->fetchAll();
  render('articles', compact('items', 'page', 'cat'), ($cat ? 'Bài viết về '.$cat['name'] : 'Bài viết').' - '.cfg('site_name'), 'Bài viết hướng dẫn và giải đáp được tổng hợp từ cộng đồng và cộng tác viên Biết Tuốt.', ['cache' => true]);
}
route('GET', '#^/bai-viet$#', fn() => article_list(null));
route('GET', '#^/bai-viet/chuyen-muc/([a-z0-9-]+)$#', function ($slug) { $c = q('SELECT * FROM categories WHERE slug=? AND active=1', [$slug])->fetch(); if (!$c) not_found(); article_list($c); });
route('GET', '#^/bai-viet/(?:.*-)?(\d+)$#', function ($id) {
  $art = q('SELECT a.*,c.name cat,c.slug cslug,c.is_sensitive csens,u.username FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id WHERE a.id=?', [$id])->fetch();
  $canEdit = $art && can_edit_article($art); if (!$art || ($art['status'] !== 'published' && !$canEdit)) not_found();
  $canon = '/bai-viet/'.$art['slug'].'-'.$id; if (rawurldecode((string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)) !== $canon) redirect($canon, 301);
  $rq = $art['question_id'] ? q("SELECT id,slug,title FROM questions WHERE id=? AND status='published'", [$art['question_id']])->fetch() : null;
  render('article', compact('art', 'rq', 'canEdit'), $art['title'].' - '.cfg('site_name'), mb_substr(trim(preg_replace('/[#*\-\s]+/u', ' ', $art['body'])), 0, 155), ['cache' => $art['status'] === 'published', 'noindex' => $art['status'] !== 'published', 'og' => ['title' => $art['title'], 'desc' => mb_substr(trim(preg_replace('/[#*\-\s]+/u', ' ', $art['body'])), 0, 155), 'image' => url('/og/a/'.(int)$id.'.png'), 'type' => 'article']]);
});

route('GET', '#^/do-vui$#', function () {
  $quiz = daily_quiz(); $mine = ($quiz && me()) ? (q('SELECT * FROM quiz_answers WHERE user_id=? AND quiz_id=?', [me()['id'], $quiz['id']])->fetch() ?: null) : null;
  render('quiz', compact('quiz', 'mine'), 'Đố vui hằng ngày - '.cfg('site_name'), 'Trả lời đố vui mỗi ngày để nhận điểm thưởng.');
});
route('POST', '#^/do-vui$#', function () {
  $u = require_verified(); $quiz = daily_quiz(); $c = (int)($_POST['choice'] ?? -1); if (!$quiz || $c < 0 || $c > 3) redirect('/do-vui');
  $ok = $c === (int)$quiz['answer_idx'] ? 1 : 0;
  if (q('INSERT IGNORE INTO quiz_answers(user_id,quiz_id,choice,correct) VALUES(?,?,?,?)', [$u['id'], $quiz['id'], $c, $ok])->rowCount()) {
    if ($ok) { earn((int)$u['id'], 'quiz', (int)$quiz['id']); flash('Chính xác! Bạn nhận điểm thưởng đố vui.', 'ok'); } else flash('Chưa đúng rồi, xem giải thích bên dưới nhé.');
  }
  redirect('/do-vui');
});
route('GET', '#^/go/(\d+)$#', function ($id) {
  $a = q('SELECT url FROM affiliates WHERE id=? AND active=1', [$id])->fetch(); if (!$a || !preg_match('#^https?://#i', $a['url'])) not_found();
  q('UPDATE affiliates SET clicks=clicks+1 WHERE id=?', [$id]); header('Location: '.$a['url'], true, 302);
});
route('POST', '#^/admin/gop$#', function () {
  mod_only(); $s = (int)($_POST['source'] ?? 0); $t = (int)($_POST['target'] ?? 0);
  $rs = q('SELECT * FROM questions WHERE id=?', [$s])->fetch(); $rt = q('SELECT * FROM questions WHERE id=?', [$t])->fetch();
  if ($rs && $rt && $s !== $t) {
    q('UPDATE answers SET question_id=?,is_best=0 WHERE question_id=?', [$t, $s]); q("UPDATE questions SET status='hidden',merged_into=? WHERE id=?", [$t, $s]);
    recount_answers($t); pts_reverse('question', $s); audit('merge', "$s>$t"); cache_clear();
    notify((int)$rs['user_id'], 'mod', 'Câu hỏi của bạn đã được gộp vào một câu hỏi tương tự.', qurl($rt)); flash('Đã gộp câu hỏi.', 'ok'); redirect(qurl($rt));
  }
  flash('Không thể gộp.', 'err'); redirect('/');
});

// Trình duyệt hỏi định kỳ trạng thái câu trả lời AI; nếu tác vụ còn chờ thì chạy luôn tại đây (không cần cron).
route('GET', '#^/api/ai-trang-thai$#', function () {
  header('Content-Type: application/json; charset=utf-8'); $id = (int)($_GET['id'] ?? 0);
  $has = fn() => (bool)q("SELECT 1 FROM answers WHERE question_id=? AND is_ai=1 AND status='published'", [$id])->fetchColumn();
  if (!$has()) { set_time_limit(60); jobs_run(1, 'ai_answer', $id); }
  $done = $has(); $st = q("SELECT status FROM jobs WHERE type='ai_answer' AND ref_id=? ORDER BY id DESC LIMIT 1", [$id])->fetchColumn();
  echo json_encode(['done' => $done, 'failed' => !$done && ($st === 'failed' || $st === false)]);
});
// Gọi từ cron của Hostinger mỗi 5 phút: https://tenmien/cron?key=CRON_KEY
route('GET', '#^/cron$#', function () {
  $k = (string)pc('cron_key'); if ($k === '' || !hash_equals($k, (string)($_GET['key'] ?? ''))) not_found();
  set_time_limit(180); set_setting('cron_last', (string)time()); $n = jobs_run(10); settle_due(); $bk = backup_maybe();
  try { if (feature('newsletter') && date('N') === '1' && (int)date('G') >= 8 && setting('newsletter_last') !== date('o-W')) { set_setting('newsletter_last', date('o-W')); news_send_all(); } } catch (Throwable $e) { app_log('bản tin: '.$e->getMessage()); }
  foreach (glob(ROOT.'/app/cache/og/*.png') ?: [] as $of) if (filemtime($of) < time() - 30 * 86400) @unlink($of); $al = alerts_check(); $h = md5(implode('|', $al)); $mail = (string)pc('admin_email');
  if ($al && $mail && (setting('alert_hash') !== $h || time() - (int)setting('alert_at', '0') > 86400)) {
    send_mail($mail, '[Biết Tuốt] Cảnh báo hệ thống', "Các cảnh báo:\n- ".implode("\n- ", $al)); set_setting('alert_hash', $h); set_setting('alert_at', (string)time());
  }
  try { q("UPDATE payment_orders SET status='expired' WHERE status='pending' AND expires_at<NOW()"); $rd = (int)setting('chat_retention_days', '180'); if ($rd > 0) { q('DELETE m FROM chat_messages m JOIN chat_threads t ON t.id=m.thread_id WHERE t.updated_at<DATE_SUB(NOW(),INTERVAL ? DAY)', [$rd]); q('DELETE FROM chat_threads WHERE updated_at<DATE_SUB(NOW(),INTERVAL ? DAY)', [$rd]); } } catch (Throwable $e) { app_log('cron dọn dẹp: '.$e->getMessage()); }
  q('DELETE FROM tokens WHERE expires_at<DATE_SUB(NOW(),INTERVAL 7 DAY)'); q("DELETE FROM jobs WHERE status='done' AND created_at<DATE_SUB(NOW(),INTERVAL 7 DAY)"); q('DELETE FROM login_log WHERE created_at<DATE_SUB(NOW(),INTERVAL 60 DAY)');
  header('Content-Type: text/plain'); echo "ok jobs=$n alerts=".count($al).($bk ? " $bk" : '');
});
