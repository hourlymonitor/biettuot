<?php
// Tiện ích: cài đặt, IP, nhật ký, cache trang, email, token, Turnstile, markdown tài liệu, Web Push (VAPID).
function setting(string $k, ?string $def = null): ?string { $a = settings_all(); return (array_key_exists($k, $a) && $a[$k] !== null) ? (string)$a[$k] : $def; }
function set_setting(string $k, string $v): void { q('REPLACE INTO settings(k,v) VALUES(?,?)', [$k, $v]); settings_all(true); }
// Mã hóa khóa API/token lưu trong CSDL (AES-256-CBC). Nên đặt 'app_key' cố định trong config.local.php; đổi app_key/mật khẩu DB sẽ làm khóa đã lưu không đọc được.
function secret_key(): string { return hash('sha256', (string)cfg('app_key', '').'|'.(string)cfg('db.pass', '').'|'.(string)cfg('db.name', ''), true); }
function secret_enc(string $s): string {
  if ($s === '') return ''; if (!function_exists('openssl_encrypt')) return 'p:'.base64_encode($s);
  $iv = random_bytes(16); return 'e:'.base64_encode($iv.openssl_encrypt($s, 'aes-256-cbc', secret_key(), OPENSSL_RAW_DATA, $iv));
}
function secret_dec(string $s): string {
  if ($s === '') return ''; if (strncmp($s, 'p:', 2) === 0) return (string)base64_decode(substr($s, 2));
  if (strncmp($s, 'e:', 2) === 0) { $raw = (string)base64_decode(substr($s, 2)); $d = openssl_decrypt(substr($raw, 16), 'aes-256-cbc', secret_key(), OPENSSL_RAW_DATA, substr($raw, 0, 16)); return $d === false ? '' : $d; }
  return $s;
}
function secret_mask(string $s): string { return $s === '' ? '(chưa có)' : (strlen($s) <= 8 ? '••••' : '••••'.substr($s, -4)); }
function client_ip(): string {
  foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $h)
    if (!empty($_SERVER[$h])) { $ip = trim(explode(',', $_SERVER[$h])[0]); if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip; }
  return '0.0.0.0';
}
function log_login(int $uid, bool $ok): void { q('INSERT INTO login_log(user_id,ip,ua,ok) VALUES(?,?,?,?)', [$uid, client_ip(), substr(md5($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 16), (int)$ok]); }
function audit(string $action, string $target = '', string $detail = ''): void {
  q('INSERT INTO audit_log(admin_id,action,target,detail) VALUES(?,?,?,?)', [(int)(me()['id'] ?? 0), mb_substr($action, 0, 30), mb_substr($target, 0, 60), mb_substr($detail, 0, 255)]);
}
// ----- Cache trang cho khách (chưa đăng nhập) -----
function cache_file(): string { return ROOT.'/app/cache/'.md5($_SERVER['REQUEST_URI'] ?? '/').'.html'; }
function cache_clear(): void { foreach (glob(ROOT.'/app/cache/*.html') ?: [] as $f) @unlink($f); }
function page_cacheable(): bool { return ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET' && feature('cache') && empty($_SESSION['uid']) && empty($_SESSION['flash']) && ($_SERVER['QUERY_STRING'] ?? '') === ''; }
// ----- Email -----
function send_mail(string $to, string $subject, string $text): bool {
  $from = (string)pc('mail.from'); $fn = (string)pc('mail.from_name');
  if (!filter_var($to, FILTER_VALIDATE_EMAIL) || $from === '') return false;
  $subj = '=?UTF-8?B?'.base64_encode($subject).'?=';
  $h = 'From: =?UTF-8?B?'.base64_encode($fn)."?= <$from>\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n";
  $body = chunk_split(base64_encode($text)); $smtp = (array)pc('mail.smtp');
  if (!empty($smtp['host'])) return smtp_send($smtp, $from, $to, "To: $to\r\nSubject: $subj\r\nDate: ".date('r')."\r\n".$h."\r\n".$body);
  return (bool)@mail($to, $subj, $body, $h);
}
function smtp_send(array $c, string $from, string $to, string $msg): bool {
  $secure = (string)($c['secure'] ?? 'ssl');
  $fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://').$c['host'].':'.(int)($c['port'] ?? 465), $en, $es, 10);
  if (!$fp) return false; stream_set_timeout($fp, 10);
  $rd = function () use ($fp) { $r = ''; while (($l = fgets($fp, 515)) !== false) { $r .= $l; if (isset($l[3]) && $l[3] === ' ') break; } return $r; };
  $cmd = function (string $s, string $ok) use ($fp, $rd) { fwrite($fp, $s."\r\n"); return strncmp($rd(), $ok, 3) === 0; };
  $rd(); $ok = $cmd('EHLO biettuot.local', '250');
  if ($ok && $secure === 'tls') $ok = $cmd('STARTTLS', '220') && stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) && $cmd('EHLO biettuot.local', '250');
  if ($ok && !empty($c['user'])) $ok = $cmd('AUTH LOGIN', '334') && $cmd(base64_encode($c['user']), '334') && $cmd(base64_encode((string)$c['pass']), '235');
  $ok = $ok && $cmd("MAIL FROM:<$from>", '250') && $cmd("RCPT TO:<$to>", '250') && $cmd('DATA', '354') && $cmd(str_replace("\n.", "\n..", $msg)."\r\n.", '250');
  @fwrite($fp, "QUIT\r\n"); fclose($fp); return $ok;
}
function token_make(int $uid, string $type, int $hours): string {
  $t = bin2hex(random_bytes(24));
  q('INSERT INTO tokens(user_id,type,token_hash,expires_at) VALUES(?,?,?,DATE_ADD(NOW(),INTERVAL ? HOUR))', [$uid, $type, hash('sha256', $t), $hours]);
  return $t;
}
function token_peek(string $t, string $type): ?array { return q('SELECT * FROM tokens WHERE token_hash=? AND type=? AND used=0 AND expires_at>NOW()', [hash('sha256', $t), $type])->fetch() ?: null; }
function token_use(string $t, string $type): ?int {
  $r = token_peek($t, $type); if (!$r) return null;
  return q('UPDATE tokens SET used=1 WHERE id=? AND used=0', [$r['id']])->rowCount() ? (int)$r['user_id'] : null;
}
function send_verification(int $uid, string $email, string $name): void {
  $link = url('/xac-minh?t='.token_make($uid, 'verify', 48));
  $body = "Chào $name,\n\nBấm vào liên kết sau để xác minh email (hiệu lực 48 giờ):\n$link\n\nNếu bạn không đăng ký tài khoản, hãy bỏ qua thư này.";
  if (!send_mail($email, 'Xác minh email Biết Tuốt', $body)) job_add('mail', 0, ['to' => $email, 'subject' => 'Xác minh email Biết Tuốt', 'body' => $body]);
}
// ----- Cloudflare Turnstile (bỏ qua nếu chưa cấu hình) -----
function turnstile_widget(): string {
  $s = (string)pc('turnstile.site');
  return $s === '' ? '' : '<div class="cf-turnstile" data-sitekey="'.e($s).'"></div><script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>';
}
function turnstile_ok(): bool {
  $sec = (string)pc('turnstile.secret'); if ($sec === '') return true;
  $tok = (string)($_POST['cf-turnstile-response'] ?? ''); if ($tok === '') return false;
  $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
  curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(['secret' => $sec, 'response' => $tok, 'remoteip' => client_ip()]), CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8]);
  $r = json_decode((string)curl_exec($ch), true); curl_close($ch); return !empty($r['success']);
}
// ----- Markdown tài liệu (bài viết): ## tiêu đề, ### tiểu mục, **đậm**, danh sách "- " -----
function md_doc(string $t): string {
  $t = preg_replace('/\*\*(.+?)\*\*/s', '<strong>$1</strong>', e(trim($t))); $out = ''; $list = false;
  foreach (preg_split('/\R/', $t) as $l) {
    if (preg_match('/^\s*[-*•]\s+(.*)$/', $l, $m)) { if (!$list) { $out .= '<ul>'; $list = true; } $out .= '<li>'.$m[1].'</li>'; continue; }
    if ($list) { $out .= '</ul>'; $list = false; }
    if (preg_match('/^###\s+(.*)$/', $l, $m)) $out .= '<h3>'.$m[1].'</h3>';
    elseif (preg_match('/^##?\s+(.*)$/', $l, $m)) $out .= '<h2>'.$m[1].'</h2>';
    elseif (trim($l) !== '') $out .= '<p>'.$l.'</p>';
  }
  return $out.($list ? '</ul>' : '');
}
// ----- Web Push (không kèm nội dung; service worker tự lấy thông báo mới nhất) -----
function b64u(string $s): string { return rtrim(strtr(base64_encode($s), '+/', '-_'), '='); }
function vapid_generate(): bool {
  $k = openssl_pkey_new(['curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC]); if (!$k) return false;
  openssl_pkey_export($k, $pem); $d = openssl_pkey_get_details($k)['ec'];
  set_setting('vapid_pub', b64u("\x04".str_pad($d['x'], 32, "\0", STR_PAD_LEFT).str_pad($d['y'], 32, "\0", STR_PAD_LEFT))); set_setting('vapid_priv', $pem);
  return true;
}
function vapid_jwt(string $aud): string {
  $h = b64u(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
  $c = b64u(json_encode(['aud' => $aud, 'exp' => time() + 43200, 'sub' => 'mailto:'.((string)pc('admin_email') ?: 'admin@example.com')]));
  openssl_sign("$h.$c", $der, (string)setting('vapid_priv'), OPENSSL_ALGO_SHA256);
  $rl = ord($der[3]); $r = substr($der, 4, $rl); $sl = ord($der[5 + $rl]); $s = substr($der, 6 + $rl, $sl);
  return "$h.$c.".b64u(str_pad(ltrim($r, "\0"), 32, "\0", STR_PAD_LEFT).str_pad(ltrim($s, "\0"), 32, "\0", STR_PAD_LEFT));
}
function push_send_one(string $endpoint): int {
  $pub = setting('vapid_pub'); $p = parse_url($endpoint); if (!$pub || empty($p['host'])) return 0;
  $ch = curl_init($endpoint);
  curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '', CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8,
    CURLOPT_HTTPHEADER => ['Authorization: vapid t='.vapid_jwt($p['scheme'].'://'.$p['host']).', k='.$pub, 'TTL: 3600', 'Content-Length: 0']]);
  curl_exec($ch); $c = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch); return $c;
}
function push_user(int $uid): bool {
  foreach (q('SELECT id,endpoint FROM push_subs WHERE user_id=?', [$uid])->fetchAll() as $s) {
    $c = push_send_one($s['endpoint']); if ($c === 404 || $c === 410) q('DELETE FROM push_subs WHERE id=?', [$s['id']]);
  }
  return true;
}
