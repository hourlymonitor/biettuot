<?php
// ---------- Chương trình cộng tác viên (CTV): đăng ký, khu vực làm việc, viết/sửa bài, lượt xem bài ----------
function ctv_only(): array {
  global $path; $u = require_login(); if (!in_array($u['role'], ['collab', 'admin'], true)) not_found();
  if (!ctv_terms_ok($u) && $path !== '/ctv/dieu-khoan') redirect('/ctv/dieu-khoan');
  return $u;
}

route('GET', '#^/cong-tac-vien$#', function () {
  $u = me() ? fresh_user((int)me()['id']) : null;
  $app = $u ? (q('SELECT * FROM ctv_applications WHERE user_id=? ORDER BY id DESC LIMIT 1', [$u['id']])->fetch() ?: null) : null;
  $myCats = ($u && $u['role'] === 'collab') ? q('SELECT c.name FROM mod_categories m JOIN categories c ON c.id=m.category_id WHERE m.user_id=?', [$u['id']])->fetchAll(PDO::FETCH_COLUMN) : [];
  render('ctv_info', compact('u', 'app', 'myCats'), 'Chương trình cộng tác viên - '.cfg('site_name'), 'Trở thành cộng tác viên: viết bài, kiểm duyệt trong lĩnh vực bạn phụ trách và nhận chia sẻ doanh thu.');
});
route('POST', '#^/cong-tac-vien$#', function () {
  $u = require_verified(true);
  if ($u['role'] !== 'user') { flash('Bạn đã là cộng tác viên hoặc quản trị viên.'); redirect('/ctv'); }
  if (q("SELECT 1 FROM ctv_applications WHERE user_id=? AND status='pending'", [$u['id']])->fetchColumn()) { flash('Đơn của bạn đang chờ xét duyệt.'); redirect('/cong-tac-vien'); }
  if (empty($_POST['agree'])) { flash('Bạn cần đồng ý Điều khoản cộng tác viên để ứng tuyển.', 'err'); redirect('/cong-tac-vien'); }
  $f = mb_substr(trim((string)($_POST['fields'] ?? '')), 0, 255); $ex = mb_substr(trim((string)($_POST['experience'] ?? '')), 0, 2000);
  if ($f === '' || mb_strlen($ex) < 20) { flash('Hãy nhập lĩnh vực muốn phụ trách và giới thiệu kinh nghiệm (tối thiểu 20 ký tự).', 'err'); redirect('/cong-tac-vien'); }
  q('INSERT INTO ctv_applications(user_id,areas,experience) VALUES(?,?,?)', [$u['id'], $f, $ex]);
  q('INSERT IGNORE INTO terms_acceptance(user_id,doc,version,ip) VALUES(?,?,?,?)', [$u['id'], 'ctv', ctv_terms_ver(), client_ip()]);
  foreach (q("SELECT id FROM users WHERE role='admin'")->fetchAll(PDO::FETCH_COLUMN) as $aid) notify((int)$aid, 'mod', 'Có đơn đăng ký cộng tác viên mới từ '.$u['username'], '/admin/he-thong?t=ctv');
  flash('Đã gửi đơn đăng ký. Chúng tôi sẽ phản hồi sớm.', 'ok'); redirect('/cong-tac-vien');
});
route('GET', '#^/ctv$#', function () {
  $u = ctv_only(); $uid = (int)$u['id']; $cats = $u['role'] === 'admin' ? [] : ctv_cats($uid); $ym = date('Y-m'); $in = $cats ? implode(',', $cats) : '';
  $stat = ['articles' => (int)q("SELECT COUNT(*) FROM articles WHERE author_id=? AND status='published' AND published_at>=DATE_FORMAT(NOW(),'%Y-%m-01')", [$uid])->fetchColumn(),
    'views' => (int)q('SELECT COALESCE(SUM(s.views),0) FROM article_stats s JOIN articles a ON a.id=s.article_id WHERE a.author_id=? AND s.ym=?', [$uid, $ym])->fetchColumn(),
    'xp' => (int)q("SELECT COALESCE(SUM(delta),0) FROM point_ledger WHERE user_id=? AND earned=1 AND delta>0 AND status='confirmed' AND created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')", [$uid])->fetchColumn()];
  $stat['score'] = $stat['xp'] * (float)pc('ctv.w_xp') + $stat['articles'] * (float)pc('ctv.w_article') + $stat['views'] * (float)pc('ctv.w_view');
  $mine = q('SELECT a.id,a.title,a.status,a.views,c.name cat FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.author_id=? ORDER BY a.id DESC LIMIT 20', [$uid])->fetchAll();
  $editable = q('SELECT a.id,a.title,a.status,a.views,u.username,c.name cat FROM articles a LEFT JOIN categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id WHERE (a.author_id IS NULL OR a.author_id<>?) '.($in ? "AND a.category_id IN ($in) " : '').'ORDER BY a.id DESC LIMIT 20', [$uid])->fetchAll();
  $paid = q("SELECT * FROM point_ledger WHERE user_id=? AND kind='revshare' ORDER BY id DESC LIMIT 6", [$uid])->fetchAll();
  $catNames = $in ? q("SELECT name FROM categories WHERE id IN ($in)")->fetchAll(PDO::FETCH_COLUMN) : [];
  render('ctv_dash', compact('u', 'stat', 'mine', 'editable', 'paid', 'catNames'), 'Khu vực cộng tác viên - '.cfg('site_name'), '', ['noindex' => true]);
});
route('GET', '#^/ctv/bai-viet/moi$#', function () {
  $u = ctv_only(); render('ctv_article', ['art' => null, 'cats' => ctv_article_cats($u), 'direct' => ctv_direct($u)], 'Viết bài mới - '.cfg('site_name'), '', ['noindex' => true]);
});
route('GET', '#^/ctv/bai-viet/(\d+)/sua$#', function ($id) {
  $u = ctv_only(); $art = q('SELECT * FROM articles WHERE id=?', [$id])->fetch(); if (!$art || !can_edit_article($art)) not_found();
  $edits = q("SELECT e.*,u.username FROM content_edits e LEFT JOIN users u ON u.id=e.user_id WHERE e.type='article' AND e.target_id=? ORDER BY e.id DESC LIMIT 5", [$id])->fetchAll();
  render('ctv_article', ['art' => $art, 'cats' => ctv_article_cats($u), 'direct' => ctv_direct($u), 'edits' => $edits], 'Sửa bài viết - '.cfg('site_name'), '', ['noindex' => true]);
});
function ctv_save_article(?array $art, array $u): void {
  $title = trim(mb_substr((string)($_POST['title'] ?? ''), 0, 200)); $body = trim((string)($_POST['body'] ?? '')); $cid = (int)($_POST['category_id'] ?? 0); $act = (string)($_POST['act'] ?? 'save');
  $back = $art ? '/ctv/bai-viet/'.$art['id'].'/sua' : '/ctv/bai-viet/moi';
  if (mb_strlen($title) < 10 || mb_strlen($body) < 100 || !ctv_can_cat($u, $cid) || !q('SELECT 1 FROM categories WHERE id=?', [$cid])->fetchColumn()) {
    flash('Tiêu đề tối thiểu 10 ký tự, nội dung tối thiểu 100 ký tự và phải chọn lĩnh vực bạn phụ trách.', 'err'); redirect($back);
  }
  $status = $act === 'publish' ? (ctv_direct($u) ? 'published' : 'pending') : ($art['status'] ?? 'draft');
  if (!$art) { q('INSERT INTO articles(title,slug,body,status,category_id,author_id,published_at) VALUES(?,?,?,?,?,?,?)', [$title, slugify($title), $body, $status, $cid, $u['id'], $status === 'published' ? date('Y-m-d H:i:s') : null]); $id = (int)db()->lastInsertId(); $authorId = (int)$u['id']; }
  else {
    $id = (int)$art['id']; $authorId = (int)($art['author_id'] ?? 0);
    q('INSERT INTO content_edits(type,target_id,user_id,old_title,old_body) VALUES(?,?,?,?,?)', ['article', $id, $u['id'], $art['title'], $art['body']]);
    $pubAt = ($status === 'published' && empty($art['published_at'])) ? date('Y-m-d H:i:s') : ($art['published_at'] ?? null);
    q('UPDATE articles SET title=?,body=?,category_id=?,status=?,updated_at=NOW(),published_at=? WHERE id=?', [$title, $body, $cid, $status, $pubAt, $id]);
  }
  if ($status === 'published' && (!$art || $art['status'] !== 'published') && $authorId) { earn($authorId, 'article', $id); check_badges($authorId); }
  if ($status === 'pending' && (!$art || $art['status'] !== 'pending')) foreach (q("SELECT id FROM users WHERE role='admin'")->fetchAll(PDO::FETCH_COLUMN) as $aid) notify((int)$aid, 'mod', $u['username'].' gửi bài chờ duyệt: '.mb_substr($title, 0, 80), '/admin/he-thong?t=noidung');
  cache_clear();
  flash($status === 'published' ? 'Đã đăng bài viết.' : ($status === 'pending' ? 'Đã gửi bài chờ quản trị viên duyệt.' : 'Đã lưu.'), 'ok'); redirect('/ctv');
}
route('POST', '#^/ctv/bai-viet/moi$#', function () { ctv_save_article(null, ctv_only()); });
route('POST', '#^/ctv/bai-viet/(\d+)/sua$#', function ($id) {
  $u = ctv_only(); $art = q('SELECT * FROM articles WHERE id=?', [$id])->fetch(); if (!$art || !can_edit_article($art)) not_found(); ctv_save_article($art, $u);
});
route('POST', '#^/ctv/bai-viet/trang-thai$#', function () {
  $u = ctv_only(); $art = q('SELECT * FROM articles WHERE id=?', [(int)($_POST['id'] ?? 0)])->fetch(); if (!$art || !can_edit_article($art)) not_found(); $act = (string)($_POST['act'] ?? '');
  if ($act === 'unpublish') { q("UPDATE articles SET status='draft' WHERE id=?", [$art['id']]); flash('Đã gỡ bài về bản nháp.', 'ok'); }
  elseif ($act === 'delete' && ($u['role'] === 'admin' || ((int)$art['author_id'] === (int)$u['id'] && $art['status'] !== 'published'))) { q('DELETE FROM articles WHERE id=?', [$art['id']]); flash('Đã xóa bài.', 'ok'); }
  else flash('Bạn không thể thực hiện thao tác này (chỉ xóa được bài nháp của chính mình).', 'err');
  cache_clear(); audit('article:'.$act, '#'.$art['id']); redirect('/ctv');
});
// Đếm lượt xem bài viết bằng ảnh 1x1 (trang khách được cache nên không đếm ở máy chủ khi trúng cache)
route('GET', '#^/api/xem$#', function () {
  $id = (int)($_GET['a'] ?? 0);
  if ($id && empty($_SESSION['av'][$id]) && !preg_match('/bot|crawl|spider|slurp|preview|monitor/i', $_SERVER['HTTP_USER_AGENT'] ?? '')) {
    $_SESSION['av'][$id] = 1;
    if (q("UPDATE articles SET views=views+1 WHERE id=? AND status='published'", [$id])->rowCount()) q('INSERT INTO article_stats(article_id,ym,views) VALUES(?,?,1) ON DUPLICATE KEY UPDATE views=views+1', [$id, date('Y-m')]);
  }
  header('Content-Type: image/gif'); header('Cache-Control: no-store'); echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
});
