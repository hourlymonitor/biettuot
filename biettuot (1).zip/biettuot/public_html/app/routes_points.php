<?php
// ---------- Ví điểm, thử thách, quà tặng, xếp hạng, chia sẻ doanh thu ----------

route('GET', '#^/vi$#', function () {
  $u = require_login(); settle_due((int)$u['id']); $u = fresh_user((int)$u['id']);
  $pending = (int)q("SELECT COALESCE(SUM(delta),0) FROM point_ledger WHERE user_id=? AND status='pending'", [$u['id']])->fetchColumn();
  $ledger = q('SELECT * FROM point_ledger WHERE user_id=? ORDER BY id DESC LIMIT 30', [$u['id']])->fetchAll();
  $chs = [];
  foreach (q('SELECT * FROM challenges WHERE active=1 ORDER BY id')->fetchAll() as $c) {
    [, $key] = ch_period($c['period']);
    $c['prog'] = min((int)$c['target'], ch_progress($c, (int)$u['id'])); $c['done'] = $c['prog'] >= (int)$c['target'];
    $c['claimed'] = (bool)q("SELECT 1 FROM point_ledger WHERE user_id=? AND kind='challenge' AND ref_id=? AND src_user_id=?", [$u['id'], $c['id'], $key])->fetchColumn();
    $chs[] = $c;
  }
  $reds = q('SELECT r.*,w.name FROM redemptions r JOIN rewards w ON w.id=r.reward_id WHERE r.user_id=? ORDER BY r.id DESC LIMIT 20', [$u['id']])->fetchAll();
  render('wallet', compact('u', 'pending', 'ledger', 'chs', 'reds'), 'Ví điểm của tôi - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/vi/thong-tin$#', function () {
  $u = require_login();
  q('UPDATE users SET payout_info=? WHERE id=?', [mb_substr(trim((string)($_POST['payout_info'] ?? '')), 0, 255), $u['id']]);
  flash('Đã lưu thông tin nhận quà.', 'ok'); redirect('/vi');
});
route('POST', '#^/thu-thach/nhan$#', function () {
  $u = require_login(); $c = q('SELECT * FROM challenges WHERE id=? AND active=1', [(int)($_POST['id'] ?? 0)])->fetch(); if (!$c) not_found();
  [, $key] = ch_period($c['period']);
  if (ch_progress($c, (int)$u['id']) < (int)$c['target']) flash('Bạn chưa hoàn thành thử thách này.', 'err');
  elseif (pts((int)$u['id'], (int)$c['reward'], 'challenge', (int)$c['id'], $key, 'Thử thách: '.$c['title'])) flash('Đã nhận thưởng thử thách. Điểm sẽ khả dụng sau thời gian giữ.', 'ok');
  else flash('Bạn đã nhận thưởng thử thách này rồi.', 'err');
  redirect('/vi');
});
route('GET', '#^/xep-hang$#', function () {
  $rows = q("SELECT u.username,u.xp,u.role,SUM(l.delta) m FROM point_ledger l JOIN users u ON u.id=l.user_id
             WHERE l.earned=1 AND l.delta>0 AND l.status='confirmed' AND u.banned=0 AND l.created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')
             GROUP BY u.id ORDER BY m DESC LIMIT 20")->fetchAll();
  render('leaderboard', compact('rows'), 'Bảng xếp hạng tháng - '.cfg('site_name'), 'Những người đóng góp nhiều nhất tháng này.');
});
route('GET', '#^/qua-tang$#', function () {
  $me = me() ? fresh_user((int)me()['id']) : null;
  render('rewards', ['rw' => q('SELECT * FROM rewards WHERE active=1 ORDER BY cost_points')->fetchAll(), 'me' => $me], 'Đổi quà tặng - '.cfg('site_name'), 'Dùng điểm đóng góp để đổi thẻ điện thoại, tiền và vật phẩm.');
});
route('POST', '#^/doi-qua$#', function () {
  $u = require_verified((bool)pc('redeem.require_verified')); $uid = (int)$u['id'];
  $w = q('SELECT * FROM rewards WHERE id=? AND active=1', [(int)($_POST['reward_id'] ?? 0)])->fetch(); if (!$w) not_found();
  $contact = mb_substr(trim((string)($_POST['contact'] ?? '')), 0, 255); $f = fresh_user($uid); $cost = (int)$w['cost_points']; $err = null;
  $contrib = (int)q("SELECT (SELECT COUNT(*) FROM answers WHERE user_id=? AND is_ai=0 AND status='published')+(SELECT COUNT(*) FROM questions WHERE user_id=? AND status='published')", [$uid, $uid])->fetchColumn();
  $spent = (int)q("SELECT COALESCE(SUM(vnd_value),0) FROM redemptions WHERE status<>'rejected' AND created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')")->fetchColumn();
  $budget = (int)pc('redeem.budget_vnd_month');
  if ($contact === '') $err = 'Hãy nhập thông tin nhận quà (số điện thoại, địa chỉ hoặc tài khoản nhận tiền).';
  elseif (tier_of((int)$f['xp'])['idx'] < (int)$w['min_tier']) $err = 'Cấp bậc của bạn chưa đủ để đổi quà này.';
  elseif (time() - strtotime($f['created_at']) < (int)pc('redeem.min_age_days') * 86400) $err = 'Tài khoản cần hoạt động ít nhất '.(int)pc('redeem.min_age_days').' ngày mới được đổi quà.';
  elseif ($contrib < (int)pc('redeem.min_contrib')) $err = 'Bạn cần đăng ít nhất '.(int)pc('redeem.min_contrib').' câu hỏi/câu trả lời mới được đổi quà.';
  elseif ((int)q('SELECT COUNT(*) FROM redemptions WHERE user_id=? AND created_at>=CURDATE()', [$uid])->fetchColumn() >= (int)(is_premium($f) ? pc('premium.redeem_max_per_day') : pc('redeem.max_per_day'))) $err = 'Bạn đã đạt giới hạn đổi quà hôm nay.';
  elseif ($budget > 0 && $spent + (int)$w['vnd_value'] > $budget) $err = 'Quỹ quà tặng tháng này đã hết, hãy quay lại vào tháng sau.';
  if (!$err) {
    db()->beginTransaction();
    try {
      if ((int)q('SELECT points FROM users WHERE id=? FOR UPDATE', [$uid])->fetchColumn() < $cost) throw new RuntimeException('Bạn không đủ điểm khả dụng.');
      $st = (int)q('SELECT stock FROM rewards WHERE id=? FOR UPDATE', [$w['id']])->fetchColumn();
      if ($st === 0) throw new RuntimeException('Quà này đã hết hàng.');
      if ($st > 0) q('UPDATE rewards SET stock=stock-1 WHERE id=?', [$w['id']]);
      q('INSERT INTO redemptions(user_id,reward_id,cost_points,vnd_value,contact) VALUES(?,?,?,?,?)', [$uid, $w['id'], $cost, $w['vnd_value'], $contact]);
      $rid = (int)db()->lastInsertId();
      pts($uid, -$cost, 'redeem', $rid, 0, 'Đổi quà: '.$w['name'], 0, false);
      q('UPDATE users SET payout_info=? WHERE id=?', [$contact, $uid]);
      db()->commit();
    } catch (Throwable $e) { db()->rollBack(); $err = $e instanceof RuntimeException ? $e->getMessage() : 'Có lỗi xảy ra, hãy thử lại.'; }
  }
  if ($err) { flash($err, 'err'); redirect('/qua-tang'); }
  flash('Đã gửi yêu cầu đổi quà. Quản trị viên sẽ xử lý và liên hệ qua thông tin bạn cung cấp.', 'ok'); redirect('/vi');
});

// Chương trình chia sẻ doanh thu nay dành cho cộng tác viên (xem routes_ctv.php)
route('GET', '#^/chia-se-doanh-thu$#', fn() => redirect('/cong-tac-vien', 301));

// ---------- Quản trị điểm/quà/thành viên (chỉ admin) ----------
route('GET', '#^/admin/diem$#', function () {
  admin_only(); $t = in_array($_GET['t'] ?? '', ['qua', 'thuthach', 'user', 'doanhthu'], true) ? $_GET['t'] : 'qua'; $d = ['t' => $t];
  if ($t === 'qua') {
    $d['queue'] = q("SELECT r.*,u.username,w.name wname,w.type FROM redemptions r JOIN users u ON u.id=r.user_id JOIN rewards w ON w.id=r.reward_id WHERE r.status='pending' ORDER BY r.id")->fetchAll();
    $d['done'] = q("SELECT r.*,u.username,w.name wname FROM redemptions r JOIN users u ON u.id=r.user_id JOIN rewards w ON w.id=r.reward_id WHERE r.status<>'pending' ORDER BY r.id DESC LIMIT 15")->fetchAll();
    $d['rewards'] = q('SELECT * FROM rewards ORDER BY id DESC')->fetchAll();
    $d['spent'] = (int)q("SELECT COALESCE(SUM(vnd_value),0) FROM redemptions WHERE status<>'rejected' AND created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')")->fetchColumn();
  } elseif ($t === 'thuthach') $d['chs'] = q('SELECT * FROM challenges ORDER BY id DESC')->fetchAll();
  elseif ($t === 'user') { $s = trim((string)($_GET['s'] ?? '')); $d['s'] = $s; $d['cats'] = cats(); $d['mc'] = q('SELECT user_id,category_id FROM mod_categories')->fetchAll(); $d['users'] = q('SELECT id,username,email,email_verified,role,banned,points,xp,shares,expert_title,created_at FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 40', ["%$s%", "%$s%"])->fetchAll(); }
  else $d['runs'] = q('SELECT * FROM revenue_runs ORDER BY id DESC LIMIT 12')->fetchAll();
  render('admin_pts', $d, 'Quản trị điểm - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/diem/act$#', function () {
  admin_only(); $act = (string)($_POST['act'] ?? ''); $id = (int)($_POST['id'] ?? 0); $note = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 190); $tab = 'qua'; audit('pts:'.$act, '#'.$id, $note);
  switch ($act) {
    case 'redeem_ok':
      q("UPDATE redemptions SET status='fulfilled',admin_note=?,updated_at=NOW() WHERE id=? AND status='pending'", [$note, $id]);
      if ($ru = q('SELECT user_id FROM redemptions WHERE id=?', [$id])->fetchColumn()) notify((int)$ru, 'redeem', 'Đơn đổi quà #'.$id.' đã được gửi quà. '.$note, '/vi', true); break;
    case 'redeem_no':
      $r = q("SELECT * FROM redemptions WHERE id=? AND status='pending'", [$id])->fetch();
      if ($r) {
        q("UPDATE redemptions SET status='rejected',admin_note=?,updated_at=NOW() WHERE id=?", [$note, $id]);
        pts((int)$r['user_id'], (int)$r['cost_points'], 'refund', $id, 0, 'Hoàn điểm đơn #'.$id, 0, false);
        q('UPDATE rewards SET stock=stock+1 WHERE id=? AND stock>=0', [$r['reward_id']]);
        notify((int)$r['user_id'], 'redeem', 'Đơn đổi quà #'.$id.' bị từ chối và đã hoàn điểm. '.$note, '/vi', true);
      } break;
    case 'reward_add':
      $type = in_array($_POST['type'] ?? '', ['item', 'cash', 'phonecard'], true) ? $_POST['type'] : 'item';
      q('INSERT INTO rewards(name,type,cost_points,vnd_value,stock,min_tier,description) VALUES(?,?,?,?,?,?,?)',
        [mb_substr(trim((string)($_POST['name'] ?? '')), 0, 120) ?: 'Quà tặng', $type, max(1, (int)($_POST['cost'] ?? 1)), max(0, (int)($_POST['vnd'] ?? 0)), (int)($_POST['stock'] ?? -1), max(0, (int)($_POST['min_tier'] ?? 0)), mb_substr(trim((string)($_POST['desc'] ?? '')), 0, 255)]); break;
    case 'reward_toggle': q('UPDATE rewards SET active=1-active WHERE id=?', [$id]); break;
    case 'ch_add':
      $tab = 'thuthach'; $m = in_array($_POST['metric'] ?? '', ['answers', 'questions', 'upvotes', 'best', 'checkins'], true) ? $_POST['metric'] : 'answers';
      $p = in_array($_POST['period'] ?? '', ['daily', 'weekly', 'once'], true) ? $_POST['period'] : 'daily';
      q('INSERT INTO challenges(title,metric,target,period,reward) VALUES(?,?,?,?,?)', [mb_substr(trim((string)($_POST['title'] ?? '')), 0, 150) ?: 'Thử thách', $m, max(1, (int)($_POST['target'] ?? 1)), $p, max(1, (int)($_POST['reward'] ?? 1))]); break;
    case 'ch_toggle': $tab = 'thuthach'; q('UPDATE challenges SET active=1-active WHERE id=?', [$id]); break;
    case 'user_role': $tab = 'user'; q("UPDATE users SET role=? WHERE id=? AND role<>'admin'", [($_POST['role'] ?? '') === 'collab' ? 'collab' : 'user', $id]); break;
    case 'user_ban': $tab = 'user'; q("UPDATE users SET banned=1 WHERE id=? AND role<>'admin'", [$id]); q("UPDATE point_ledger SET status='reversed' WHERE user_id=? AND status='pending'", [$id]); break;
    case 'user_verify': $tab = 'user'; q('UPDATE users SET email_verified=1 WHERE id=?', [$id]); break;
    case 'user_cats':
      $tab = 'user'; q('DELETE FROM mod_categories WHERE user_id=?', [$id]);
      foreach ((array)($_POST['cats'] ?? []) as $cc) q('INSERT IGNORE INTO mod_categories(user_id,category_id) VALUES(?,?)', [$id, (int)$cc]); break;
    case 'user_expert':
      $tab = 'user'; $et = mb_substr(trim((string)($_POST['title'] ?? '')), 0, 80); q('UPDATE users SET expert_title=? WHERE id=?', [$et, $id]);
      if ($et !== '') notify($id, 'mod', '✔ Bạn đã được xác minh là chuyên gia: '.$et, '/cai-dat'); break;
    case 'user_unban': $tab = 'user'; q('UPDATE users SET banned=0 WHERE id=?', [$id]); break;
    case 'user_adjust': $tab = 'user'; $amt = (int)($_POST['amount'] ?? 0); if ($amt !== 0) pts($id, $amt, 'admin', 0, random_int(1, 2000000000), $note ?: 'Điều chỉnh bởi quản trị', 0, false); break;
  }
  flash('Đã thực hiện.', 'ok'); redirect('/admin/diem?t='.$tab);
});
route('POST', '#^/admin/diem/doanh-thu$#', function () {
  admin_only(); audit('revshare', (string)($_POST['ym'] ?? ''), empty($_POST['confirm']) ? 'preview' : 'run'); $ym = (string)($_POST['ym'] ?? ''); $other = max(0, (int)($_POST['revenue'] ?? 0)); $prem = 0;
  if (!empty($_POST['auto']) && preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $ym)) { try { $prem = (int)q("SELECT COALESCE(SUM(amount),0) FROM payment_orders WHERE status='paid' AND paid_at>=? AND paid_at<DATE_ADD(?,INTERVAL 1 MONTH)", ["$ym-01 00:00:00", "$ym-01 00:00:00"])->fetchColumn(); } catch (Throwable $e) {} }
  $rev = $prem + $other; $back = '/admin/diem?t=doanhthu';
  if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $ym) || $ym >= date('Y-m')) { flash('Tháng không hợp lệ (chỉ chia cho tháng đã kết thúc).', 'err'); redirect($back); }
  if (q('SELECT 1 FROM revenue_runs WHERE month=?', [$ym])->fetchColumn()) { flash('Tháng này đã được chia.', 'err'); redirect($back); }
  $calc = revshare_calc($ym, $rev);
  if (empty($_POST['confirm'])) { render('admin_pts', ['t' => 'doanhthu', 'preview' => $calc, 'ym' => $ym, 'rev' => $rev, 'prem' => $prem, 'other' => $other, 'runs' => q('SELECT * FROM revenue_runs ORDER BY id DESC LIMIT 12')->fetchAll()], 'Xem trước chia doanh thu', '', ['noindex' => true]); return; }
  foreach ($calc['rows'] as $r) pts((int)$r['uid'], (int)$r['pts'], 'revshare', (int)str_replace('-', '', $ym), 0, "Chia sẻ doanh thu tháng $ym", 0, false);
  q('INSERT INTO revenue_runs(month,revenue_vnd,pool_points,total_shares,total_xp) VALUES(?,?,?,?,?)', [$ym, $rev, $calc['pool'], count($calc['rows']), (int)round($calc['total'])]);
  flash('Đã chia '.number_format(array_sum(array_column($calc['rows'], 'pts'))).' điểm cho '.count($calc['rows']).' thành viên.', 'ok'); redirect($back);
});
