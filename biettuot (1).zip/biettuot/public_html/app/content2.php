<?php
// Nội dung & tăng trưởng: quy tắc riêng theo lĩnh vực, nhu cầu nội dung, soạn nháp bằng AI, nút chia sẻ, thiết bị khách.
function category_rules(?array $c): string {
  if (!$c) return ''; $s = '';
  if (!empty($c['ai_prompt'])) $s .= ' Quy tắc riêng của lĩnh vực: '.trim((string)$c['ai_prompt']);
  if (!empty($c['is_sensitive'])) $s .= ' Đây là lĩnh vực nhạy cảm: chỉ đưa thông tin tổng quát, nhắc rõ chỉ mang tính tham khảo và khuyên hỏi chuyên gia.';
  return $s;
}
// Ghi nhận câu hỏi mà site chưa có nội dung phù hợp (để giao cộng tác viên viết bài)
function gap_log(string $query, string $field = 'chung'): void {
  if (!feature('content_gaps')) return;
  $n = mb_strtolower(trim(preg_replace('/\s+/u', ' ', $query))); if (mb_strlen($n) < 8 || mb_strlen($n) > 200) return;
  try {
    $cid = $field !== 'chung' ? (q('SELECT id FROM categories WHERE slug=?', [$field])->fetchColumn() ?: null) : null;
    q('INSERT INTO content_gaps(qhash,query,field,category_id) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE hits=hits+1,last_at=NOW()', [substr(md5($n), 0, 16), mb_substr($query, 0, 250), $field, $cid]);
  } catch (Throwable $e) { app_log('gap_log: '.$e->getMessage()); }
}
// Soạn bản nháp bài viết (AI nếu có, nếu không thì dàn bài trống). Trả về id bài nháp.
function draft_from_topic(array $u, string $topic, int $cid, ?int $gapId = null): int {
  $cat = q('SELECT name,ai_prompt,is_sensitive FROM categories WHERE id=?', [$cid])->fetch() ?: null;
  $topic = trim(mb_substr($topic, 0, 200)); $title = $topic; $body = '';
  if (feature('ai_drafts') && ai_providers()) {
    $srcs = rag_sources($topic, 3);
    $sys = "Bạn là biên tập viên của website Biết Tuốt. Viết bài giải thích tiếng Việt chuẩn SEO về chủ đề được cho. Dòng đầu tiên CHỈ là tiêu đề bài (không có ký hiệu #), tiếp theo là nội dung: đoạn mở đầu trả lời ngắn gọn; 3-5 mục dùng '## Tiêu đề'; dùng '- ' khi liệt kê; kết bằng mục '## Lưu ý'. Khoảng 450-650 từ. Không bịa số liệu hay nguồn; không sao chép nguyên văn; không dùng bảng."
      .category_rules($cat).rag_prompt($srcs)." Đây là BẢN NHÁP để cộng tác viên chỉnh sửa và kiểm chứng.";
    $res = ai_complete($sys, "Chủ đề: $topic", (int)$u['id'], 1600, 60, 'article');
    if ($res) {
      $lines = preg_split('/\R/', trim($res['text']), 2); $t = trim((string)preg_replace('/^[#\s*]+|[*\s]+$/u', '', (string)$lines[0]));
      if (mb_strlen($t) >= 10) { $title = mb_substr($t, 0, 200); $body = trim((string)($lines[1] ?? '')); } else $body = trim($res['text']);
    }
  }
  if (mb_strlen($body) < 100) $body = "## Mở đầu\n(Trả lời ngắn gọn câu hỏi: $topic)\n\n## Nội dung chính\n- ...\n- ...\n\n## Lưu ý\n(Thông tin chỉ mang tính tham khảo.)\n";
  if (mb_strlen($title) < 10) $title = str_pad($title, 10, '.');
  q("INSERT INTO articles(title,slug,body,status,category_id,author_id) VALUES(?,?,?,'draft',?,?)", [$title, slugify($title), $body, $cid, $u['id']]); $id = (int)db()->lastInsertId();
  if ($gapId) q("UPDATE content_gaps SET status='assigned',assigned_to=?,article_id=? WHERE id=?", [$u['id'], $id, $gapId]);
  return $id;
}
function share_buttons(string $path, string $title): string {
  $u = url($path); $e = rawurlencode($u); $t = rawurlencode($title);
  return '<div class="share"><span class="muted">Chia sẻ:</span> <a href="https://www.facebook.com/sharer/sharer.php?u='.$e.'" target="_blank" rel="noopener nofollow">Facebook</a> <a href="https://twitter.com/intent/tweet?url='.$e.'&text='.$t.'" target="_blank" rel="noopener nofollow">X</a> '
    .'<button type="button" class="link" data-copy="'.e($u).'">Sao chép liên kết</button> <button type="button" class="link" data-share="'.e($u).'" data-title="'.e($title).'" hidden>Chia sẻ…</button></div>';
}
function chat_device(): string {
  $d = (string)($_COOKIE['bt_dev'] ?? '');
  if (!preg_match('/^[a-f0-9]{16}$/', $d)) { $d = bin2hex(random_bytes(8)); if (!headers_sent()) setcookie('bt_dev', $d, ['expires' => time() + 31536000, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]); }
  return $d;
}
function ctv_terms_ver(): int { return max(1, (int)setting('terms_ctv_ver', '1')); }
function ctv_terms_ok(array $u): bool { return $u['role'] !== 'collab' || (bool)q("SELECT 1 FROM terms_acceptance WHERE user_id=? AND doc='ctv' AND version=?", [$u['id'], ctv_terms_ver()])->fetchColumn(); }
function ctv_terms_text(): string {
  return (string)setting('terms_ctv', "## Điều khoản cộng tác viên (BẢN MẪU - cần luật sư rà soát trước khi áp dụng)\n\n- Cộng tác viên viết nội dung do chính mình sáng tạo, không sao chép nguyên văn nội dung có bản quyền của người khác, và chịu trách nhiệm về tính chính xác của nội dung mình đăng.\n- Với lĩnh vực sức khỏe, pháp luật, tài chính, tâm lý: chỉ đưa thông tin tổng quát, không chẩn đoán hay tư vấn cá nhân.\n- Biết Tuốt được quyền chỉnh sửa, ẩn hoặc gỡ nội dung vi phạm; nội dung CTV đăng được website sử dụng, hiển thị và phân phối.\n- Phần chia sẻ doanh thu phụ thuộc doanh thu thực tế và quyết định của quản trị, không bảo đảm có thu nhập; nghĩa vụ thuế (nếu có) thuộc về người nhận.\n- Hai bên có thể chấm dứt cộng tác bất cứ lúc nào bằng thông báo.\n");
}
function chat_save(int $uid, int $tid, string $mode, string $field, string $title, string $userMsg, string $reply): int {
  if ($tid && !q('SELECT 1 FROM chat_threads WHERE id=? AND user_id=?', [$tid, $uid])->fetchColumn()) $tid = 0;
  if (!$tid) {
    if ((int)q('SELECT COUNT(*) FROM chat_threads WHERE user_id=?', [$uid])->fetchColumn() >= 200) {
      $old = (int)q('SELECT id FROM chat_threads WHERE user_id=? ORDER BY updated_at LIMIT 1', [$uid])->fetchColumn();
      if ($old) { q('DELETE FROM chat_messages WHERE thread_id=?', [$old]); q('DELETE FROM chat_threads WHERE id=?', [$old]); }
    }
    q('INSERT INTO chat_threads(user_id,title,mode,field) VALUES(?,?,?,?)', [$uid, mb_substr($title, 0, 100), $mode, $field]); $tid = (int)db()->lastInsertId();
  } elseif ((int)q('SELECT COUNT(*) FROM chat_messages WHERE thread_id=?', [$tid])->fetchColumn() >= 400) return $tid;
  q('INSERT INTO chat_messages(thread_id,role,content) VALUES(?,?,?)', [$tid, 'user', $userMsg]);
  q('INSERT INTO chat_messages(thread_id,role,content) VALUES(?,?,?)', [$tid, 'assistant', $reply]);
  q('UPDATE chat_threads SET updated_at=NOW(),mode=?,field=? WHERE id=?', [$mode, $field, $tid]);
  return $tid;
}
