<?php
// ---------- Quản trị hệ thống: thống kê, gian lận, nội dung, đối soát, quảng cáo & premium, nhật ký, sao lưu ----------
route('GET', '#^/admin/he-thong$#', function () {
  admin_only(); $t = in_array($_GET['t'] ?? '', ['thongke', 'gianlan', 'noidung', 'doisoat', 'quangcao', 'nhatky', 'ctv', 'chuyenmuc', 'uudai'], true) ? $_GET['t'] : 'thongke'; $d = ['t' => $t];
  $one = fn(string $sql, array $p = []) => (int)q($sql, $p)->fetchColumn();
  if ($t === 'thongke') {
    $d['kpi'] = ['users' => $one('SELECT COUNT(*) FROM users'), 'new7' => $one('SELECT COUNT(*) FROM users WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)'),
      'q7' => $one('SELECT COUNT(*) FROM questions WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)'), 'a7' => $one('SELECT COUNT(*) FROM answers WHERE is_ai=0 AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)'),
      'dau' => $one('SELECT COUNT(*) FROM users WHERE last_checkin=CURDATE()'), 'mau' => $one('SELECT COUNT(*) FROM users WHERE last_checkin>=DATE_SUB(CURDATE(),INTERVAL 30 DAY)')];
    $days = []; for ($i = 13; $i >= 0; $i--) $days[date('Y-m-d', strtotime("-$i day"))] = ['q' => 0, 'a' => 0];
    foreach (q('SELECT DATE(created_at) d,COUNT(*) n FROM questions WHERE created_at>=DATE_SUB(CURDATE(),INTERVAL 13 DAY) GROUP BY DATE(created_at)')->fetchAll() as $r) if (isset($days[$r['d']])) $days[$r['d']]['q'] = (int)$r['n'];
    foreach (q('SELECT DATE(created_at) d,COUNT(*) n FROM answers WHERE is_ai=0 AND created_at>=DATE_SUB(CURDATE(),INTERVAL 13 DAY) GROUP BY DATE(created_at)')->fetchAll() as $r) if (isset($days[$r['d']])) $days[$r['d']]['a'] = (int)$r['n'];
    $d['days'] = $days; $m = "created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')";
    $d['pts'] = ['issued' => $one("SELECT COALESCE(SUM(delta),0) FROM point_ledger WHERE earned=1 AND delta>0 AND status<>'reversed' AND $m"), 'spent' => -$one("SELECT COALESCE(SUM(delta),0) FROM point_ledger WHERE kind='redeem' AND $m"),
      'outstanding' => $one('SELECT COALESCE(SUM(points),0) FROM users WHERE banned=0'), 'vnd' => (int)pc('points.vnd_per_point')];
    $d['redeemVnd'] = $one("SELECT COALESCE(SUM(vnd_value),0) FROM redemptions WHERE status<>'rejected' AND $m");
    $d['ai'] = q('SELECT provider,SUM(ok) ok,COUNT(*) n FROM ai_log WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) GROUP BY provider')->fetchAll(); $d['alerts'] = alerts_check();
  } elseif ($t === 'gianlan') {
    $sub = 'SELECT v.user_id a,x.user_id b,COUNT(*) c FROM votes v JOIN answers x ON x.id=v.answer_id WHERE v.value=1 AND x.user_id IS NOT NULL AND v.user_id<>x.user_id GROUP BY v.user_id,x.user_id';
    $d['ips'] = q("SELECT l.ip,COUNT(DISTINCT l.user_id) n,GROUP_CONCAT(DISTINCT u.username SEPARATOR ', ') names FROM login_log l JOIN users u ON u.id=l.user_id WHERE l.ok=1 AND l.user_id>0 AND l.created_at>=DATE_SUB(NOW(),INTERVAL 14 DAY) GROUP BY l.ip HAVING n>=3 ORDER BY n DESC LIMIT 30")->fetchAll();
    $d['rings'] = q("SELECT p1.a ida,p1.b idb,ua.username na,ub.username nb,p1.c ab,p2.c ba FROM ($sub) p1 JOIN ($sub) p2 ON p2.a=p1.b AND p2.b=p1.a JOIN users ua ON ua.id=p1.a JOIN users ub ON ub.id=p1.b WHERE p1.a<p1.b AND p1.c>=3 AND p2.c>=3 ORDER BY p1.c+p2.c DESC LIMIT 30")->fetchAll();
    $d['heavy'] = q("SELECT p.a ida,ua.username na,ub.username nb,p.c FROM ($sub) p JOIN users ua ON ua.id=p.a JOIN users ub ON ub.id=p.b WHERE p.c>=8 ORDER BY p.c DESC LIMIT 20")->fetchAll();
    $d['fast'] = q("SELECT id,username,points,xp,created_at FROM users WHERE banned=0 AND role='user' AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) AND xp>=150 ORDER BY xp DESC LIMIT 20")->fetchAll();
  } elseif ($t === 'noidung') {
    $d['hot'] = q("SELECT q.id,q.title,q.views,q.answers_count FROM questions q WHERE q.status='published' AND q.answers_count>=1 AND q.id NOT IN (SELECT question_id FROM articles WHERE question_id IS NOT NULL) ORDER BY q.views DESC LIMIT 10")->fetchAll();
    $d['arts'] = q("SELECT a.id,a.title,a.status,a.created_at,u.username,c.name cat FROM articles a LEFT JOIN users u ON u.id=a.author_id LEFT JOIN categories c ON c.id=a.category_id ORDER BY (a.status='pending') DESC,a.id DESC LIMIT 30")->fetchAll(); $d['quizzes'] = q('SELECT * FROM quizzes ORDER BY id DESC LIMIT 20')->fetchAll(); $d['qotd'] = qotd();
    $d['edit'] = !empty($_GET['edit']) ? (q('SELECT * FROM articles WHERE id=?', [(int)$_GET['edit']])->fetch() ?: null) : null;
  } elseif ($t === 'doisoat') {
    $m = preg_match('/^\d{4}-\d{2}$/', (string)($_GET['m'] ?? '')) ? $_GET['m'] : date('Y-m'); $d['m'] = $m;
    $d['rows'] = q("SELECT r.*,u.username,w.name wname,w.type FROM redemptions r JOIN users u ON u.id=r.user_id JOIN rewards w ON w.id=r.reward_id WHERE r.status='fulfilled' AND r.updated_at>=? AND r.updated_at<DATE_ADD(?,INTERVAL 1 MONTH) ORDER BY r.updated_at", ["$m-01", "$m-01"])->fetchAll();
    $d['pendingVnd'] = $one("SELECT COALESCE(SUM(vnd_value),0) FROM redemptions WHERE status='pending'"); $d['outstanding'] = $one('SELECT COALESCE(SUM(points),0) FROM users WHERE banned=0') * (int)pc('points.vnd_per_point');
  } elseif ($t === 'quangcao') {
    $d['ad'] = ['top' => (string)setting('ad_top', ''), 'inline' => (string)setting('ad_inline', ''), 'pay' => (string)setting('premium_pay_info', '')];
    $d['affs'] = q('SELECT * FROM affiliates ORDER BY id DESC LIMIT 30')->fetchAll(); $d['cats'] = cats();
    $d['plans'] = premium_plans(); $d['reqs'] = q("SELECT p.*,u.username,u.email FROM premium_requests p JOIN users u ON u.id=p.user_id WHERE p.status='pending' ORDER BY p.id")->fetchAll(); $d['premCount'] = $one('SELECT COUNT(*) FROM users WHERE premium_until>NOW()');
  } elseif ($t === 'ctv') {
    $d['apps'] = q("SELECT a.*,u.username,u.email,u.xp FROM ctv_applications a JOIN users u ON u.id=a.user_id WHERE a.status='pending' ORDER BY a.id")->fetchAll(); $d['cats'] = cats();
    $d['ctvs'] = q("SELECT u.id,u.username,u.email,(SELECT COUNT(*) FROM articles WHERE author_id=u.id AND status='published') arts,
      (SELECT COALESCE(SUM(s.views),0) FROM article_stats s JOIN articles a ON a.id=s.article_id WHERE a.author_id=u.id AND s.ym=DATE_FORMAT(NOW(),'%Y-%m')) vm,
      (SELECT GROUP_CONCAT(c.name SEPARATOR ', ') FROM mod_categories m JOIN categories c ON c.id=m.category_id WHERE m.user_id=u.id) cats FROM users u WHERE u.role='collab' AND u.banned=0 ORDER BY u.id")->fetchAll();
  } elseif ($t === 'chuyenmuc') {
    $d['allcats'] = q('SELECT c.*,(SELECT COUNT(*) FROM questions WHERE category_id=c.id) qn,(SELECT COUNT(*) FROM articles WHERE category_id=c.id) an FROM categories c ORDER BY c.sort_order,c.id')->fetchAll();
  } elseif ($t === 'uudai') {
    $d['events'] = q('SELECT * FROM holiday_events ORDER BY recurring DESC,start_date')->fetchAll(); $d['plans'] = premium_plans(); $d['premCount'] = $one('SELECT COUNT(*) FROM users WHERE premium_until>NOW()');
  } else {
    $d['audit'] = q('SELECT a.*,u.username FROM audit_log a LEFT JOIN users u ON u.id=a.admin_id ORDER BY a.id DESC LIMIT 40')->fetchAll();
    $d['jobs'] = q('SELECT status,COUNT(*) n FROM jobs GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR); $d['failed'] = q("SELECT id,type,ref_id,tries,created_at FROM jobs WHERE status='failed' ORDER BY id DESC LIMIT 10")->fetchAll();
    $d['vapid'] = (string)setting('vapid_pub', ''); $d['cron'] = (string)pc('cron_key') !== '' ? url('/cron?key='.pc('cron_key')) : '';
    $f = ROOT.'/app/logs/error.log'; $d['errlog'] = is_file($f) ? implode('', array_slice(file($f), -30)) : '';
    $d['mailOk'] = !empty(pc('mail.smtp')['host']) ? 'SMTP: '.pc('mail.smtp')['host'] : 'mail() của PHP';
  }
  render('admin_sys', $d, 'Hệ thống - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/he-thong/act$#', function () {
  admin_only(); $act = (string)($_POST['act'] ?? ''); $id = (int)($_POST['id'] ?? 0); $tab = 'noidung'; audit('sys:'.$act, '#'.$id);
  $txt = fn(string $k, int $n = 255) => mb_substr(trim((string)($_POST[$k] ?? '')), 0, $n);
  switch ($act) {
    case 'article_gen': if (!feature('ai_articles')) { flash('Tính năng AI viết bài đang tắt (Admin → Tính năng).', 'err'); break; } set_time_limit(120); job_add('article', $id); jobs_run(1, 'article', $id); flash('Đã gửi yêu cầu viết bài nháp (xem danh sách bài viết bên dưới).', 'ok'); break;
    case 'article_save': q('UPDATE articles SET title=?,body=? WHERE id=?', [$txt('title', 200), trim((string)($_POST['body'] ?? '')), $id]); flash('Đã lưu bài viết.', 'ok'); break;
    case 'article_pub':
      $ar = q('SELECT * FROM articles WHERE id=?', [$id])->fetch();
      if ($ar) {
        q("UPDATE articles SET status='published',published_at=COALESCE(published_at,NOW()),slug=? WHERE id=?", [slugify($ar['title']), $id]);
        if ($ar['author_id'] && $ar['status'] !== 'published') { earn((int)$ar['author_id'], 'article', $id); notify((int)$ar['author_id'], 'mod', 'Bài viết của bạn đã được duyệt và đăng: '.mb_substr($ar['title'], 0, 80), '/bai-viet/'.slugify($ar['title']).'-'.$id, true); check_badges((int)$ar['author_id']); }
      }
      cache_clear(); flash('Đã đăng bài viết.', 'ok'); break;
    case 'article_unpub': q("UPDATE articles SET status='draft' WHERE id=?", [$id]); cache_clear(); break;
    case 'article_del': q('DELETE FROM articles WHERE id=?', [$id]); cache_clear(); break;
    case 'qotd_set': if (q("SELECT 1 FROM questions WHERE id=? AND status='published'", [$id])->fetchColumn()) { q('REPLACE INTO daily_questions(day,question_id) VALUES(CURDATE(),?)', [$id]); cache_clear(); flash('Đã đặt câu hỏi của ngày.', 'ok'); } break;
    case 'quiz_add':
      $o = array_map(fn($i) => mb_substr(trim((string)($_POST['opt'.$i] ?? '')), 0, 120), [1, 2, 3, 4]);
      if ($txt('question', 300) !== '' && !in_array('', $o, true)) q('INSERT INTO quizzes(question,options,answer_idx,explanation) VALUES(?,?,?,?)', [$txt('question', 300), json_encode($o, JSON_UNESCAPED_UNICODE), max(0, min(3, (int)($_POST['answer'] ?? 0))), $txt('explain', 300)]);
      break;
    case 'quiz_del': q('DELETE FROM quizzes WHERE id=?', [$id]); break;
    case 'quiz_gen': if (!feature('ai_quizgen')) { flash('Tính năng AI tạo đố vui đang tắt (Admin → Tính năng).', 'err'); break; } set_time_limit(120); job_add('quizgen', 0, ['topic' => $txt('topic', 80) ?: 'kiến thức phổ thông']); jobs_run(1, 'quizgen'); flash('Đã yêu cầu AI tạo đố vui.', 'ok'); break;
    case 'ads_save': $tab = 'quangcao'; set_setting('ad_top', trim((string)($_POST['ad_top'] ?? ''))); set_setting('ad_inline', trim((string)($_POST['ad_inline'] ?? ''))); set_setting('premium_pay_info', trim((string)($_POST['premium_pay_info'] ?? ''))); cache_clear(); flash('Đã lưu.', 'ok'); break;
    case 'aff_add':
      $tab = 'quangcao'; $url = $txt('url', 500);
      if ($txt('name', 100) !== '' && preg_match('#^https?://#i', $url)) q('INSERT INTO affiliates(name,url,text,category_id) VALUES(?,?,?,?)', [$txt('name', 100), $url, $txt('text', 200), ((int)($_POST['category_id'] ?? 0)) ?: null]); else flash('Cần tên và liên kết bắt đầu bằng http(s)://', 'err'); break;
    case 'aff_toggle': $tab = 'quangcao'; q('UPDATE affiliates SET active=1-active WHERE id=?', [$id]); cache_clear(); break;
    case 'prem_ok':
      $tab = 'quangcao'; $pr = q("SELECT * FROM premium_requests WHERE id=? AND status='pending'", [$id])->fetch();
      if ($pr) {
        $days = (int)(premium_plans()[$pr['plan']]['days'] ?? 30); $pn = premium_plans()[$pr['plan']]['name'] ?? 'Premium';
        q("UPDATE premium_requests SET status='approved' WHERE id=?", [$id]); q('UPDATE users SET premium_until=DATE_ADD(GREATEST(NOW(),COALESCE(premium_until,NOW())),INTERVAL ? DAY) WHERE id=?', [$days, $pr['user_id']]);
        notify((int)$pr['user_id'], 'premium', "$pn của bạn đã được kích hoạt (+$days ngày).", '/cai-dat', true);
      } break;
    case 'prem_no': $tab = 'quangcao'; q("UPDATE premium_requests SET status='rejected' WHERE id=?", [$id]); break;
    case 'ai_test': $tab = 'nhatky'; foreach (ai_test() as $line) flash($line, 'info'); break;
    case 'ctv_ok':
      $tab = 'ctv'; $ap = q("SELECT * FROM ctv_applications WHERE id=? AND status='pending'", [$id])->fetch();
      if ($ap) {
        q("UPDATE ctv_applications SET status='approved' WHERE id=?", [$id]); q("UPDATE users SET role='collab' WHERE id=? AND role='user'", [$ap['user_id']]); q('DELETE FROM mod_categories WHERE user_id=?', [$ap['user_id']]);
        foreach ((array)($_POST['cats'] ?? []) as $cc) q('INSERT IGNORE INTO mod_categories(user_id,category_id) VALUES(?,?)', [$ap['user_id'], (int)$cc]);
        notify((int)$ap['user_id'], 'mod', '🎉 Đơn cộng tác viên của bạn đã được duyệt! Vào Khu vực CTV để bắt đầu viết bài.', '/ctv', true);
      } break;
    case 'ctv_no': $tab = 'ctv'; q("UPDATE ctv_applications SET status='rejected' WHERE id=?", [$id]); break;
    case 'ctv_remove': $tab = 'ctv'; q("UPDATE users SET role='user' WHERE id=? AND role='collab'", [$id]); q('DELETE FROM mod_categories WHERE user_id=?', [$id]); break;
    case 'cat_add':
      $tab = 'chuyenmuc'; $nm = $txt('name', 80); $slug = mb_substr(slugify($nm), 0, 50);
      if ($nm !== '' && q('INSERT IGNORE INTO categories(slug,name,description,sort_order,icon,is_sensitive) VALUES(?,?,?,?,?,?)', [$slug, $nm, $txt('description', 255), (int)($_POST['sort_order'] ?? 50), $txt('icon', 8), !empty($_POST['sensitive']) ? 1 : 0])->rowCount()) cache_clear(); else flash('Tên trống hoặc chuyên mục đã tồn tại.', 'err'); break;
    case 'cat_save': $tab = 'chuyenmuc'; q('UPDATE categories SET name=?,icon=?,sort_order=?,is_sensitive=?,ai_prompt=?,long_desc=? WHERE id=?', [$txt('name', 80), $txt('icon', 8), (int)($_POST['sort_order'] ?? 0), !empty($_POST['sensitive']) ? 1 : 0, $txt('ai_prompt', 1500) ?: null, $txt('long_desc', 4000) ?: null, $id]); cache_clear(); break;
    case 'cat_toggle': $tab = 'chuyenmuc'; q('UPDATE categories SET active=1-active WHERE id=?', [$id]); cache_clear(); break;
    case 'holiday_add':
      $tab = 'uudai'; $sd = (string)($_POST['start_date'] ?? ''); $ed = (string)($_POST['end_date'] ?? $sd);
      if ($txt('name', 120) !== '' && strtotime($sd) && strtotime($ed) && $ed >= $sd) q('INSERT INTO holiday_events(name,start_date,end_date,recurring,bonus_points,premium_bonus) VALUES(?,?,?,?,?,?)', [$txt('name', 120), $sd, $ed, !empty($_POST['recurring']) ? 1 : 0, max(0, (int)($_POST['bonus_points'] ?? 0)), max(0, (int)($_POST['premium_bonus'] ?? 0))]); else flash('Cần tên và ngày hợp lệ.', 'err'); break;
    case 'holiday_toggle': $tab = 'uudai'; q('UPDATE holiday_events SET active=1-active WHERE id=?', [$id]); break;
    case 'clear_log': $tab = 'nhatky'; @file_put_contents(ROOT.'/app/logs/error.log', ''); flash('Đã xóa nhật ký lỗi.', 'ok'); break;
    case 'db_sync': $tab = 'nhatky'; $lg = schema_sync(db()); foreach (array_slice($lg, 0, 40) as $l) flash($l, strncmp($l, '✘', 3) === 0 ? 'err' : 'info'); break;
    case 'vapid_gen': $tab = 'nhatky'; flash(vapid_generate() ? 'Đã tạo khóa VAPID. Bật push trong config: push => [enabled => true].' : 'Không tạo được khóa (máy chủ thiếu OpenSSL EC).', 'ok'); break;
    case 'retry_jobs': $tab = 'nhatky'; q("UPDATE jobs SET status='pending',tries=0 WHERE status='failed'"); break;
  }
  redirect('/admin/he-thong?t='.$tab);
});
route('GET', '#^/admin/xuat-csv$#', function () {
  admin_only(); $m = preg_match('/^\d{4}-\d{2}$/', (string)($_GET['m'] ?? '')) ? $_GET['m'] : date('Y-m'); audit('csv', $m);
  header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="doisoat-'.$m.'.csv"'); echo "\xEF\xBB\xBF"; $o = fopen('php://output', 'w');
  fputcsv($o, ['Ma don', 'Thanh vien', 'Email', 'Qua', 'Loai', 'Gia tri (VND)', 'Diem', 'Thong tin nhan', 'Ma giao dich/Ghi chu', 'Ngay xu ly']);
  foreach (q("SELECT r.*,u.username,u.email,w.name wname,w.type FROM redemptions r JOIN users u ON u.id=r.user_id JOIN rewards w ON w.id=r.reward_id WHERE r.status='fulfilled' AND r.updated_at>=? AND r.updated_at<DATE_ADD(?,INTERVAL 1 MONTH) ORDER BY r.updated_at", ["$m-01", "$m-01"]) as $r)
    fputcsv($o, [$r['id'], $r['username'], $r['email'], $r['wname'], $r['type'], $r['vnd_value'], $r['cost_points'], $r['contact'], $r['admin_note'], $r['updated_at']]);
  fclose($o);
});
route('POST', '#^/admin/sao-luu$#', function () {
  admin_only(); audit('backup'); set_time_limit(300);
  header('Content-Type: application/sql; charset=utf-8'); header('Content-Disposition: attachment; filename="biettuot-'.date('Ymd-His').'.sql"');
  echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n";
  foreach (db()->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $t) {
    echo "\nDROP TABLE IF EXISTS `$t`;\n".db()->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1].";\n";
    $st = db()->query("SELECT * FROM `$t`");
    while ($r = $st->fetch(PDO::FETCH_NUM)) echo "INSERT INTO `$t` VALUES (".implode(',', array_map(fn($v) => $v === null ? 'NULL' : db()->quote((string)$v), $r)).");\n";
  }
});
