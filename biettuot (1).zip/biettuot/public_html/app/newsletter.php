<?php
// Bản tin email hằng tuần (đăng ký 2 bước, hủy 1 chạm, gửi dần qua hàng đợi để không vượt hạn mức email của hosting).
function news_digest(): array {
  $qs = q("SELECT id,slug,title,answers_count,views FROM questions WHERE status='published' AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY) ORDER BY views DESC,answers_count DESC LIMIT 5")->fetchAll();
  $arts = feature('articles') ? q("SELECT id,slug,title FROM articles WHERE status='published' AND published_at>=DATE_SUB(NOW(),INTERVAL 14 DAY) ORDER BY published_at DESC LIMIT 3")->fetchAll() : [];
  return ['questions' => $qs, 'articles' => $arts];
}
function news_build(array $sub, array $dig): array {
  $body = "Chào bạn,\n\nĐây là những nội dung nổi bật trên Biết Tuốt tuần này:\n";
  if ($dig['questions']) { $body .= "\n❓ CÂU HỎI ĐƯỢC QUAN TÂM\n"; foreach ($dig['questions'] as $r) $body .= '- '.$r['title'].' ('.(int)$r['answers_count']." trả lời)\n  ".url(qurl($r))."\n"; }
  if ($dig['articles']) { $body .= "\n📰 BÀI VIẾT MỚI\n"; foreach ($dig['articles'] as $r) $body .= '- '.$r['title']."\n  ".url('/bai-viet/'.$r['slug'].'-'.$r['id'])."\n"; }
  $body .= "\n🤖 Có thắc mắc? Hỏi Trợ lý AI miễn phí: ".url('/tro-ly')."\n\n--\n".(string)setting('newsletter_footer', 'Biết Tuốt')."\nHủy nhận bản tin: ".url('/ban-tin/huy?t='.$sub['token'])."\n";
  return ['Bản tin Biết Tuốt tuần này: '.date('d/m'), $body];
}
function news_subscribe(string $email, ?int $uid = null, bool $confirmed = false): ?array {
  $email = strtolower(trim($email)); if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) return null;
  $s = q('SELECT * FROM newsletter_subs WHERE email=?', [$email])->fetch();
  if ($s) { q('UPDATE newsletter_subs SET unsub_at=NULL,user_id=COALESCE(user_id,?),confirmed=? WHERE id=?', [$uid, ($confirmed || $s['confirmed']) ? 1 : 0, $s['id']]); return q('SELECT * FROM newsletter_subs WHERE id=?', [$s['id']])->fetch(); }
  q('INSERT INTO newsletter_subs(email,user_id,token,confirmed,confirmed_at) VALUES(?,?,?,?,?)', [$email, $uid, bin2hex(random_bytes(16)), $confirmed ? 1 : 0, $confirmed ? date('Y-m-d H:i:s') : null]);
  return q('SELECT * FROM newsletter_subs WHERE email=?', [$email])->fetch();
}
function news_confirm_mail(array $s): void {
  $b = "Bạn (hoặc ai đó) đã đăng ký nhận bản tin Biết Tuốt bằng email này.\nBấm liên kết để xác nhận: ".url('/ban-tin/xac-nhan?t='.$s['token'])."\n\nNếu không phải bạn, hãy bỏ qua thư này.";
  if (!send_mail($s['email'], 'Xác nhận đăng ký bản tin Biết Tuốt', $b)) job_add('mail', 0, ['to' => $s['email'], 'subject' => 'Xác nhận đăng ký bản tin Biết Tuốt', 'body' => $b]);
}
// Xếp hàng gửi cho toàn bộ người đã xác nhận; mỗi thư cách nhau vài giây. Trả về số thư đã xếp.
function news_send_all(): int {
  $dig = news_digest(); if (!$dig['questions'] && !$dig['articles']) return 0; $n = 0;
  foreach (q('SELECT * FROM newsletter_subs WHERE confirmed=1 AND unsub_at IS NULL ORDER BY id LIMIT 2000')->fetchAll() as $i => $s) { [$sub, $body] = news_build($s, $dig); job_add('mail', 0, ['to' => $s['email'], 'subject' => $sub, 'body' => $body], $i * 4); $n++; }
  return $n;
}
