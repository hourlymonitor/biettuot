<?php
// ---------- Trợ lý AI: 3 chế độ, dựa trên kho nội dung của site (RAG), lưu lịch sử vào tài khoản, chia sẻ bằng liên kết ----------
function jexit(array $a): void { echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }
function chat_need_user(): array {
  header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
  $u = me(); if (!$u || !feature('chat_history')) { http_response_code(401); jexit(['error' => 'login', 'message' => 'Vui lòng đăng nhập.', 'threads' => []]); }
  return $u;
}
route('GET', '#^/tro-ly$#', function () {
  $fields = [['chung', 'Mọi lĩnh vực', '🌐']]; foreach (cats() as $c) $fields[] = [$c['slug'], $c['name'], $c['icon']];
  render('chat', ['modes' => chat_modes(), 'fields' => $fields, 'serverAi' => (bool)ai_providers(), 'q0' => mb_substr(trim((string)($_GET['q'] ?? '')), 0, 500), 'loggedIn' => (bool)me(),
    'sync' => (bool)(me() && feature('chat_history')), 'csrf' => csrf_token(), 'share' => feature('chat_share'), 'image' => (bool)(feature('chat_image') && me()), 'tsSite' => (!me() && feature('chat_abuse') && (string)pc('turnstile.secret') !== '' && (int)($_SESSION['ts_ok'] ?? 0) < time() - 43200) ? (string)pc('turnstile.site') : ''],
    'Trợ lý AI Biết Tuốt - Hỏi gì cũng biết', 'Trợ lý AI tiếng Việt: học tập, công việc, nấu ăn, du lịch, sức khỏe, pháp luật và mọi thắc mắc. Trả lời tức thì.', ['chat' => true]);
});
route('POST', '#^/api/chat$#', function () {
  header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
  if (($_SERVER['HTTP_SEC_FETCH_SITE'] ?? 'same-origin') === 'cross-site') { http_response_code(403); jexit(['error' => 'bad', 'message' => 'Yêu cầu không hợp lệ.']); }
  $u = me(); $ip = client_ip(); $dev = chat_device();
  if ($u && !hash_equals((string)($_SESSION['csrf'] ?? ''), (string)($_POST['_csrf'] ?? ''))) { http_response_code(419); jexit(['error' => 'csrf', 'message' => 'Phiên làm việc đã hết hạn, hãy tải lại trang.']); }
  if (!$u && !feature('chat_guest')) jexit(['error' => 'login', 'message' => 'Vui lòng đăng nhập để dùng Trợ lý AI.']);
  if ($u) { $lim = is_premium($u) ? (int)pc('premium.chat_per_day') : (int)pc('chat.user_per_day'); $used = (int)q('SELECT COUNT(*) FROM chat_log WHERE user_id=? AND created_at>=CURDATE()', [$u['id']])->fetchColumn(); }
  else { $lim = (int)pc('chat.guest_per_day'); $used = (int)q('SELECT COUNT(*) FROM chat_log WHERE user_id=0 AND (ip=? OR device=?) AND created_at>=CURDATE()', [$ip, $dev])->fetchColumn(); }
  if ($used >= $lim) jexit(['error' => 'limit', 'message' => $u ? 'Bạn đã dùng hết lượt trò chuyện hôm nay. Nâng cấp Premium để có thêm lượt.' : "Khách được $lim lượt/ngày. Hãy đăng nhập để có nhiều lượt hơn."]);
  $raw = json_decode((string)($_POST['messages'] ?? '[]'), true); if (!is_array($raw)) jexit(['error' => 'bad', 'message' => 'Dữ liệu không hợp lệ.']);
  $msgs = [];
  foreach (array_slice($raw, -10) as $m) {
    $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user'; $c = trim(mb_substr((string)($m['content'] ?? ''), 0, 2000)); if ($c === '') continue;
    if ($msgs && $msgs[count($msgs) - 1]['role'] === $role) $msgs[count($msgs) - 1]['content'] .= "\n".$c; else $msgs[] = ['role' => $role, 'content' => $c];
  }
  while ($msgs && $msgs[0]['role'] !== 'user') array_shift($msgs);
  if (!$msgs || $msgs[count($msgs) - 1]['role'] !== 'user') jexit(['error' => 'bad', 'message' => 'Hãy nhập câu hỏi.']);
  if (!ai_providers()) jexit(['error' => 'no_ai', 'message' => 'Trợ lý AI chưa được cấu hình. Quản trị viên hãy thêm AI tại Admin → AI.']);
  $mode = array_key_exists($_POST['mode'] ?? '', chat_modes()) ? $_POST['mode'] : 'smart'; if ($mode === 'deep' && !$u) $mode = 'smart';
  $field = preg_replace('/[^a-z0-9-]/', '', (string)($_POST['field'] ?? 'chung')) ?: 'chung'; [, , $max, $to] = chat_modes()[$mode];
  $last = $msgs[count($msgs) - 1]['content']; $hash = substr(md5(mb_strtolower(trim($last))), 0, 16);
  if (feature('chat_abuse')) {
    $who = $u ? 'user_id=?' : 'user_id=0 AND (ip=? OR device=?)'; $wp = $u ? [$u['id']] : [$ip, $dev];
    if ((int)q("SELECT COUNT(*) FROM chat_log WHERE $who AND created_at>=DATE_SUB(NOW(),INTERVAL 2 SECOND)", $wp)->fetchColumn()) jexit(['error' => 'fast', 'message' => 'Bạn gửi quá nhanh, hãy đợi vài giây.']);
    if (!$u && (int)q('SELECT COUNT(*) FROM chat_log WHERE user_id=0 AND (ip=? OR device=?) AND created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)', [$ip, $dev])->fetchColumn() >= 12) jexit(['error' => 'limit', 'message' => 'Bạn đã gửi khá nhiều tin trong giờ qua. Hãy nghỉ một lát hoặc đăng nhập.']);
    if ((int)q("SELECT COUNT(*) FROM chat_log WHERE $who AND msg_hash=? AND created_at>=DATE_SUB(NOW(),INTERVAL 10 MINUTE)", array_merge($wp, [$hash]))->fetchColumn() >= 2) jexit(['error' => 'dup', 'message' => 'Tin nhắn này vừa được gửi nhiều lần. Hãy thử một câu hỏi khác.']);
    if (!$u && (string)pc('turnstile.secret') !== '' && (int)($_SESSION['ts_ok'] ?? 0) < time() - 43200) jexit(['error' => 'verify', 'message' => 'Vui lòng xác minh bạn là người thật trước khi chat.']);
  }
  $image = null; $imgRaw = (string)($_POST['image'] ?? '');
  if ($imgRaw !== '') {
    if (!$u || !feature('chat_image')) jexit(['error' => 'bad', 'message' => 'Hỏi bằng ảnh chỉ dành cho thành viên đăng nhập (tính năng có thể đang tắt).']);
    if (!preg_match('#^data:(image/(?:jpeg|png|webp));base64,#', substr($imgRaw, 0, 40), $im) || strlen($imgRaw) > 2900000) jexit(['error' => 'bad', 'message' => 'Ảnh không hợp lệ hoặc quá lớn (tối đa khoảng 2MB).']);
    $b64 = substr($imgRaw, strlen($im[0])); $dec = base64_decode($b64, true);
    if ($dec === false || (function_exists('getimagesizefromstring') && !@getimagesizefromstring($dec))) jexit(['error' => 'bad', 'message' => 'Không đọc được ảnh này.']);
    if ((int)q('SELECT COUNT(*) FROM chat_log WHERE user_id=? AND img=1 AND created_at>=CURDATE()', [$u['id']])->fetchColumn() >= (is_premium($u) ? 40 : 10)) jexit(['error' => 'limit', 'message' => 'Bạn đã dùng hết lượt hỏi bằng ảnh hôm nay.']);
    if (!array_filter(ai_providers(), fn($p) => !empty($p['vision']))) jexit(['error' => 'no_ai', 'message' => 'Chưa có AI nào được bật "hỗ trợ ảnh" (Admin → AI).']);
    $image = ['mime' => $im[1], 'data' => $b64];
  }
  $img = $image !== null;
  $srcs = feature('chat_rag') ? rag_sources($last) : [];
  $res = ai_complete(chat_system($mode, $field).rag_prompt($srcs), $msgs, $u ? (int)$u['id'] : null, $max, $to, 'chat', $image);
  if (!$res) jexit(['error' => 'busy', 'message' => 'Các AI đang bận hoặc hết hạn mức, hãy thử lại sau ít phút.']);
  q('INSERT INTO chat_log(user_id,ip,device,msg_hash,img) VALUES(?,?,?,?,?)', [$u['id'] ?? 0, $ip, $dev, $hash, $img ? 1 : 0]);
  if (!$srcs && feature('chat_rag')) gap_log($last, $field);
  $cited = $rest = [];
  foreach ($srcs as $i => $s) { if (preg_match('/\['.($i + 1).'\]/', $res['text'])) $cited[] = $s; else $rest[] = $s; }
  $seen = array_column($cited, 'url'); $rel = [];
  foreach (array_merge($rest, $srcs ? [] : array_map(fn($r) => ['title' => $r['title'], 'url' => qurl($r)], search_questions(mb_substr($last, 0, 200), 1, 3))) as $s) { if (!in_array($s['url'], $seen, true)) { $rel[] = ['t' => $s['title'], 'u' => $s['url']]; $seen[] = $s['url']; } }
  $tid = 0;
  if ($u && feature('chat_history')) { try { $tid = chat_save((int)$u['id'], (int)($_POST['thread'] ?? 0), $mode, $field, $msgs[0]['content'], ($img ? '[ảnh] ' : '').$last, $res['text']); } catch (Throwable $e) { app_log('chat_save: '.$e->getMessage()); } }
  jexit(['reply' => $res['text'], 'sources' => array_map(fn($s) => ['t' => $s['title'], 'u' => $s['url']], $cited), 'related' => array_slice($rel, 0, 3), 'left' => max(0, $lim - $used - 1), 'mode' => $mode, 'thread' => $tid]);
});
route('GET', '#^/api/chat/threads$#', function () {
  $u = chat_need_user();
  $rows = q('SELECT id,title,(share_token IS NOT NULL) shared FROM chat_threads WHERE user_id=? ORDER BY updated_at DESC LIMIT 60', [$u['id']])->fetchAll();
  jexit(['threads' => array_map(fn($r) => ['id' => (int)$r['id'], 'title' => $r['title'], 'shared' => (bool)$r['shared']], $rows)]);
});
route('GET', '#^/api/chat/thread$#', function () {
  $u = chat_need_user(); $t = q('SELECT * FROM chat_threads WHERE id=? AND user_id=?', [(int)($_GET['id'] ?? 0), $u['id']])->fetch();
  if (!$t) { http_response_code(404); jexit(['error' => 'nf']); }
  jexit(['id' => (int)$t['id'], 'mode' => $t['mode'], 'field' => $t['field'], 'messages' => q('SELECT role,content FROM chat_messages WHERE thread_id=? ORDER BY id LIMIT 400', [$t['id']])->fetchAll()]);
});
route('POST', '#^/api/chat/delete$#', function () {
  $u = chat_need_user();
  if (!empty($_POST['all'])) { q('DELETE m FROM chat_messages m JOIN chat_threads t ON t.id=m.thread_id WHERE t.user_id=?', [$u['id']]); q('DELETE FROM chat_threads WHERE user_id=?', [$u['id']]); }
  else { $id = (int)($_POST['id'] ?? 0); if (q('SELECT 1 FROM chat_threads WHERE id=? AND user_id=?', [$id, $u['id']])->fetchColumn()) { q('DELETE FROM chat_messages WHERE thread_id=?', [$id]); q('DELETE FROM chat_threads WHERE id=?', [$id]); } }
  jexit(['ok' => true]);
});
route('POST', '#^/api/chat/share$#', function () {
  $u = chat_need_user(); if (!feature('chat_share')) jexit(['error' => 'off', 'message' => 'Tính năng chia sẻ đang tắt.']);
  $id = (int)($_POST['id'] ?? 0); $t = q('SELECT id,share_token FROM chat_threads WHERE id=? AND user_id=?', [$id, $u['id']])->fetch();
  if (!$t) { http_response_code(404); jexit(['error' => 'nf']); }
  if ($t['share_token']) { q('UPDATE chat_threads SET share_token=NULL WHERE id=?', [$id]); jexit(['url' => null]); }
  $tok = bin2hex(random_bytes(16)); q('UPDATE chat_threads SET share_token=? WHERE id=?', [$tok, $id]); jexit(['url' => url('/chia-se/'.$tok)]);
});
route('GET', '#^/chia-se/([a-f0-9]{32})$#', function ($tok) {
  $t = q('SELECT id,title,created_at FROM chat_threads WHERE share_token=?', [$tok])->fetch(); if (!$t) not_found();
  $m = q('SELECT role,content FROM chat_messages WHERE thread_id=? ORDER BY id LIMIT 400', [$t['id']])->fetchAll();
  render('chat_shared', compact('t', 'm'), $t['title'].' - Trợ lý AI Biết Tuốt', '', ['noindex' => true]);
});
route('POST', '#^/api/chat/verify$#', function () {
  header('Content-Type: application/json; charset=utf-8');
  if (turnstile_ok()) { $_SESSION['ts_ok'] = time(); jexit(['ok' => true]); }
  jexit(['error' => 'verify', 'message' => 'Xác minh không thành công, hãy thử lại.']);
});
