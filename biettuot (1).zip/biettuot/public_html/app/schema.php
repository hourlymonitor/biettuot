<?php
// Định nghĩa CSDL dạng mã + bộ đồng bộ an toàn chạy nhiều lần (idempotent). Dùng bởi install.php và Admin > Hệ thống.
// Không phụ thuộc phần còn lại của ứng dụng (chỉ cần PDO) để vẫn chạy được khi CSDL đang ở trạng thái dở dang.
const SCHEMA_VERSION = 7;
function schema_tables(): array {
  $e = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
  return [
  'users' => "CREATE TABLE users (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, username VARCHAR(30) NOT NULL UNIQUE, email VARCHAR(190) NOT NULL UNIQUE, pass_hash VARCHAR(255) NOT NULL,
    role ENUM('user','collab','admin') NOT NULL DEFAULT 'user', banned TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    points INT NOT NULL DEFAULT 0, xp INT NOT NULL DEFAULT 0, shares INT NOT NULL DEFAULT 0, streak INT NOT NULL DEFAULT 0, last_checkin DATE NULL, payout_info VARCHAR(255) NOT NULL DEFAULT '',
    email_verified TINYINT(1) NOT NULL DEFAULT 0, email_notify TINYINT(1) NOT NULL DEFAULT 1, bio VARCHAR(200) NOT NULL DEFAULT '', ref_code VARCHAR(12) NULL UNIQUE, referred_by INT UNSIGNED NULL,
    signup_ip VARCHAR(45) NOT NULL DEFAULT '', last_ip VARCHAR(45) NOT NULL DEFAULT '', premium_until DATETIME NULL, birthday DATE NULL, birthday_set TINYINT(1) NOT NULL DEFAULT 0) $e",
  'categories' => "CREATE TABLE categories (id TINYINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(50) NOT NULL UNIQUE, name VARCHAR(80) NOT NULL, description VARCHAR(255) NOT NULL DEFAULT '',
    sort_order INT NOT NULL DEFAULT 0, icon VARCHAR(8) NOT NULL DEFAULT '', active TINYINT(1) NOT NULL DEFAULT 1, is_sensitive TINYINT(1) NOT NULL DEFAULT 0) $e",
  'questions' => "CREATE TABLE questions (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, category_id TINYINT UNSIGNED NOT NULL, title VARCHAR(200) NOT NULL, slug VARCHAR(220) NOT NULL,
    body TEXT NOT NULL, status ENUM('published','pending','hidden') NOT NULL DEFAULT 'published', views INT UNSIGNED NOT NULL DEFAULT 0, answers_count INT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ai_summary TEXT NULL, summary_n INT NOT NULL DEFAULT 0, merged_into INT UNSIGNED NULL, edited_at DATETIME NULL,
    KEY idx_cat (category_id,status,created_at), KEY idx_new (status,created_at), KEY idx_user (user_id,created_at)) $e",
  'answers' => "CREATE TABLE answers (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NULL, is_ai TINYINT(1) NOT NULL DEFAULT 0,
    ai_provider VARCHAR(40) NULL, ai_model VARCHAR(80) NULL, body TEXT NOT NULL, score INT NOT NULL DEFAULT 0, is_best TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('published','pending','hidden') NOT NULL DEFAULT 'published', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, edited_at DATETIME NULL,
    KEY idx_q (question_id,status), KEY idx_user (user_id,created_at)) $e",
  'votes' => "CREATE TABLE votes (user_id INT UNSIGNED NOT NULL, answer_id INT UNSIGNED NOT NULL, value TINYINT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id,answer_id)) $e",
  'reports' => "CREATE TABLE reports (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, target_type ENUM('question','answer') NOT NULL, target_id INT UNSIGNED NOT NULL,
    reason VARCHAR(255) NOT NULL DEFAULT '', resolved TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) $e",
  'ai_log' => "CREATE TABLE ai_log (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, provider VARCHAR(40) NOT NULL, ok TINYINT(1) NOT NULL, http_code SMALLINT NOT NULL DEFAULT 0, note VARCHAR(255) NOT NULL DEFAULT '',
    user_id INT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_day (created_at,provider,ok)) $e",
  'ai_cooldown' => "CREATE TABLE ai_cooldown (provider VARCHAR(40) PRIMARY KEY, until_at DATETIME NOT NULL, reason VARCHAR(120) NOT NULL DEFAULT '') $e",
  'ai_providers' => "CREATE TABLE ai_providers (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(40) NOT NULL UNIQUE, label VARCHAR(80) NOT NULL DEFAULT '', ptype ENUM('anthropic','openai') NOT NULL DEFAULT 'openai',
    base_url VARCHAR(255) NOT NULL DEFAULT '', model VARCHAR(120) NOT NULL DEFAULT '', api_key TEXT NULL, priority INT NOT NULL DEFAULT 100, daily_limit INT NULL, is_fallback TINYINT(1) NOT NULL DEFAULT 0,
    chat_only TINYINT(1) NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1, last_test_at DATETIME NULL, last_test_ok TINYINT(1) NULL, last_test_note VARCHAR(255) NOT NULL DEFAULT '',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) $e",
  'point_ledger' => "CREATE TABLE point_ledger (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, delta INT NOT NULL, kind VARCHAR(20) NOT NULL, ref_id INT UNSIGNED NOT NULL DEFAULT 0,
    src_user_id INT UNSIGNED NOT NULL DEFAULT 0, status ENUM('pending','confirmed','reversed') NOT NULL DEFAULT 'confirmed', earned TINYINT(1) NOT NULL DEFAULT 1, available_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    note VARCHAR(190) NOT NULL DEFAULT '', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_once (user_id,kind,ref_id,src_user_id), KEY idx_user (user_id,id), KEY idx_pending (status,available_at),
    KEY idx_month (earned,status,created_at)) $e",
  'rewards' => "CREATE TABLE rewards (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, type ENUM('item','cash','phonecard') NOT NULL DEFAULT 'item', cost_points INT NOT NULL, vnd_value INT NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT -1, min_tier TINYINT NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1, description VARCHAR(255) NOT NULL DEFAULT '') $e",
  'redemptions' => "CREATE TABLE redemptions (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, reward_id INT UNSIGNED NOT NULL, cost_points INT NOT NULL, vnd_value INT NOT NULL DEFAULT 0,
    status ENUM('pending','fulfilled','rejected') NOT NULL DEFAULT 'pending', contact VARCHAR(255) NOT NULL DEFAULT '', admin_note VARCHAR(190) NOT NULL DEFAULT '', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL, KEY idx_user (user_id,created_at), KEY idx_status (status,created_at)) $e",
  'challenges' => "CREATE TABLE challenges (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(150) NOT NULL, metric ENUM('answers','questions','upvotes','best','checkins') NOT NULL, target INT NOT NULL,
    period ENUM('daily','weekly','once') NOT NULL DEFAULT 'daily', reward INT NOT NULL, active TINYINT(1) NOT NULL DEFAULT 1) $e",
  'revenue_runs' => "CREATE TABLE revenue_runs (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, month CHAR(7) NOT NULL UNIQUE, revenue_vnd BIGINT NOT NULL, pool_points INT NOT NULL, total_shares INT NOT NULL, total_xp INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) $e",
  'tokens' => "CREATE TABLE tokens (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, type VARCHAR(12) NOT NULL, token_hash CHAR(64) NOT NULL, expires_at DATETIME NOT NULL, used TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_hash (token_hash), KEY idx_user (user_id,type,created_at)) $e",
  'jobs' => "CREATE TABLE jobs (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, type VARCHAR(20) NOT NULL, ref_id INT UNSIGNED NOT NULL DEFAULT 0, payload TEXT NULL, status ENUM('pending','running','done','failed') NOT NULL DEFAULT 'pending',
    tries TINYINT NOT NULL DEFAULT 0, run_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, started_at DATETIME NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_run (status,run_at), KEY idx_ref (type,ref_id)) $e",
  'notifications' => "CREATE TABLE notifications (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, type VARCHAR(20) NOT NULL, text VARCHAR(255) NOT NULL, url VARCHAR(255) NOT NULL DEFAULT '/',
    is_read TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_user (user_id,is_read,id)) $e",
  'follows' => "CREATE TABLE follows (user_id INT UNSIGNED NOT NULL, type ENUM('question','user','category') NOT NULL, target_id INT UNSIGNED NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id,type,target_id), KEY idx_target (type,target_id)) $e",
  'tags' => "CREATE TABLE tags (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, slug VARCHAR(40) NOT NULL UNIQUE, name VARCHAR(40) NOT NULL) $e",
  'question_tags' => "CREATE TABLE question_tags (question_id INT UNSIGNED NOT NULL, tag_id INT UNSIGNED NOT NULL, PRIMARY KEY (question_id,tag_id), KEY idx_tag (tag_id)) $e",
  'comments' => "CREATE TABLE comments (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, answer_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, body VARCHAR(500) NOT NULL,
    status ENUM('published','hidden') NOT NULL DEFAULT 'published', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_a (answer_id,status)) $e",
  'content_edits' => "CREATE TABLE content_edits (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, type ENUM('question','answer','article') NOT NULL, target_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL,
    old_title VARCHAR(200) NULL, old_body TEXT NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_t (type,target_id)) $e",
  'user_badges' => "CREATE TABLE user_badges (user_id INT UNSIGNED NOT NULL, code VARCHAR(20) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id,code)) $e",
  'login_log' => "CREATE TABLE login_log (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL DEFAULT 0, ip VARCHAR(45) NOT NULL, ua CHAR(16) NOT NULL DEFAULT '', ok TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_ip (ip,ok,created_at), KEY idx_user (user_id)) $e",
  'audit_log' => "CREATE TABLE audit_log (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, admin_id INT UNSIGNED NOT NULL DEFAULT 0, action VARCHAR(30) NOT NULL, target VARCHAR(60) NOT NULL DEFAULT '',
    detail VARCHAR(255) NOT NULL DEFAULT '', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) $e",
  'settings' => "CREATE TABLE settings (k VARCHAR(40) PRIMARY KEY, v TEXT NULL) $e",
  'daily_questions' => "CREATE TABLE daily_questions (day DATE PRIMARY KEY, question_id INT UNSIGNED NOT NULL) $e",
  'quizzes' => "CREATE TABLE quizzes (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question VARCHAR(300) NOT NULL, options TEXT NOT NULL, answer_idx TINYINT NOT NULL, explanation VARCHAR(300) NOT NULL DEFAULT '',
    day DATE NULL UNIQUE, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) $e",
  'quiz_answers' => "CREATE TABLE quiz_answers (user_id INT UNSIGNED NOT NULL, quiz_id INT UNSIGNED NOT NULL, choice TINYINT NOT NULL, correct TINYINT(1) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id,quiz_id)) $e",
  'articles' => "CREATE TABLE articles (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, question_id INT UNSIGNED NULL, title VARCHAR(200) NOT NULL, slug VARCHAR(220) NOT NULL, body MEDIUMTEXT NOT NULL,
    status ENUM('draft','pending','published') NOT NULL DEFAULT 'draft', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, published_at DATETIME NULL, category_id TINYINT UNSIGNED NULL, author_id INT UNSIGNED NULL,
    views INT UNSIGNED NOT NULL DEFAULT 0, updated_at DATETIME NULL, KEY idx_s (status,published_at), KEY idx_cat (category_id,status,published_at)) $e",
  'article_stats' => "CREATE TABLE article_stats (article_id INT UNSIGNED NOT NULL, ym CHAR(7) NOT NULL, views INT UNSIGNED NOT NULL DEFAULT 0, PRIMARY KEY (article_id,ym)) $e",
  'mod_categories' => "CREATE TABLE mod_categories (user_id INT UNSIGNED NOT NULL, category_id TINYINT UNSIGNED NOT NULL, PRIMARY KEY (user_id,category_id)) $e",
  'affiliates' => "CREATE TABLE affiliates (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, url VARCHAR(500) NOT NULL, text VARCHAR(200) NOT NULL DEFAULT '', category_id TINYINT UNSIGNED NULL,
    clicks INT UNSIGNED NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1) $e",
  'premium_requests' => "CREATE TABLE premium_requests (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, note VARCHAR(255) NOT NULL DEFAULT '', status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, plan VARCHAR(10) NOT NULL DEFAULT 'month') $e",
  'push_subs' => "CREATE TABLE push_subs (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, endpoint TEXT NOT NULL, endpoint_hash CHAR(32) NOT NULL UNIQUE, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_user (user_id)) $e",
  'holiday_events' => "CREATE TABLE holiday_events (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, start_date DATE NOT NULL, end_date DATE NOT NULL, recurring TINYINT(1) NOT NULL DEFAULT 1,
    bonus_points INT NOT NULL DEFAULT 0, premium_bonus INT NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1) $e",
  'ctv_applications' => "CREATE TABLE ctv_applications (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, areas VARCHAR(255) NOT NULL DEFAULT '', experience TEXT NOT NULL,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_u (user_id,status)) $e",
  'chat_log' => "CREATE TABLE chat_log (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL DEFAULT 0, ip VARCHAR(45) NOT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_u (user_id,created_at), KEY idx_ip (ip,created_at)) $e",
  'chat_threads' => "CREATE TABLE chat_threads (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, title VARCHAR(120) NOT NULL DEFAULT '', mode VARCHAR(8) NOT NULL DEFAULT 'smart',
    field VARCHAR(50) NOT NULL DEFAULT 'chung', share_token CHAR(32) NULL UNIQUE, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_user (user_id,updated_at)) $e",
  'chat_messages' => "CREATE TABLE chat_messages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, thread_id INT UNSIGNED NOT NULL, role ENUM('user','assistant') NOT NULL, content TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_t (thread_id,id)) $e",
  'payment_orders' => "CREATE TABLE payment_orders (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, plan VARCHAR(10) NOT NULL, base_amount INT NOT NULL, discount INT NOT NULL DEFAULT 0, amount INT NOT NULL,
    coupon VARCHAR(30) NULL, code VARCHAR(20) NOT NULL UNIQUE, status ENUM('pending','paid','expired','cancelled') NOT NULL DEFAULT 'pending', provider VARCHAR(12) NOT NULL DEFAULT '', tx_id VARCHAR(64) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, expires_at DATETIME NOT NULL, paid_at DATETIME NULL, KEY idx_user (user_id,created_at), KEY idx_status (status,expires_at)) $e",
  'payment_tx' => "CREATE TABLE payment_tx (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, provider VARCHAR(12) NOT NULL, tx_id VARCHAR(64) NOT NULL, amount BIGINT NOT NULL DEFAULT 0, content VARCHAR(255) NOT NULL DEFAULT '',
    order_id INT UNSIGNED NULL, result VARCHAR(60) NOT NULL DEFAULT '', raw TEXT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uq_tx (provider,tx_id)) $e",
  'coupons' => "CREATE TABLE coupons (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, code VARCHAR(30) NOT NULL UNIQUE, kind ENUM('percent','fixed') NOT NULL DEFAULT 'percent', value INT NOT NULL, max_uses INT NOT NULL DEFAULT 0,
    uses INT NOT NULL DEFAULT 0, expires_at DATETIME NULL, active TINYINT(1) NOT NULL DEFAULT 1, plan VARCHAR(10) NOT NULL DEFAULT '') $e",
  'content_gaps' => "CREATE TABLE content_gaps (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, qhash CHAR(16) NOT NULL UNIQUE, query VARCHAR(255) NOT NULL, field VARCHAR(50) NOT NULL DEFAULT 'chung',
    category_id TINYINT UNSIGNED NULL, hits INT NOT NULL DEFAULT 1, first_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, last_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('open','assigned','done','ignored') NOT NULL DEFAULT 'open', assigned_to INT UNSIGNED NULL, article_id INT UNSIGNED NULL, KEY idx_st (status,hits)) $e",
  'newsletter_subs' => "CREATE TABLE newsletter_subs (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(190) NOT NULL UNIQUE, user_id INT UNSIGNED NULL, token CHAR(32) NOT NULL UNIQUE,
    confirmed TINYINT(1) NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, confirmed_at DATETIME NULL, unsub_at DATETIME NULL) $e",
  'terms_acceptance' => "CREATE TABLE terms_acceptance (user_id INT UNSIGNED NOT NULL, doc VARCHAR(20) NOT NULL, version INT NOT NULL, accepted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ip VARCHAR(45) NOT NULL DEFAULT '', PRIMARY KEY (user_id,doc,version)) $e",
  ];
}
// Cột bổ sung cho bảng đã tồn tại từ các phiên bản cũ: bảng => [cột => [định nghĩa, SQL chạy ngay sau khi thêm (tùy chọn)]]
function schema_columns(): array {
  return [
    'users' => ['points' => ['INT NOT NULL DEFAULT 0'], 'xp' => ['INT NOT NULL DEFAULT 0'], 'shares' => ['INT NOT NULL DEFAULT 0'], 'streak' => ['INT NOT NULL DEFAULT 0'], 'last_checkin' => ['DATE NULL'],
      'payout_info' => ["VARCHAR(255) NOT NULL DEFAULT ''"], 'email_verified' => ['TINYINT(1) NOT NULL DEFAULT 0', 'UPDATE users SET email_verified=1'], 'email_notify' => ['TINYINT(1) NOT NULL DEFAULT 1'],
      'bio' => ["VARCHAR(200) NOT NULL DEFAULT ''"], 'ref_code' => ['VARCHAR(12) NULL'], 'referred_by' => ['INT UNSIGNED NULL'], 'signup_ip' => ["VARCHAR(45) NOT NULL DEFAULT ''"], 'last_ip' => ["VARCHAR(45) NOT NULL DEFAULT ''"],
      'premium_until' => ['DATETIME NULL'], 'birthday' => ['DATE NULL'], 'birthday_set' => ['TINYINT(1) NOT NULL DEFAULT 0'],
      'totp_secret' => ['VARCHAR(255) NULL'], 'totp_enabled' => ['TINYINT(1) NOT NULL DEFAULT 0'], 'totp_recovery' => ['TEXT NULL'], 'expert_title' => ["VARCHAR(80) NOT NULL DEFAULT ''"], 'deleted_at' => ['DATETIME NULL']],
    'votes' => ['created_at' => ['DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP']],
    'questions' => ['ai_summary' => ['TEXT NULL'], 'summary_n' => ['INT NOT NULL DEFAULT 0'], 'merged_into' => ['INT UNSIGNED NULL'], 'edited_at' => ['DATETIME NULL']],
    'answers' => ['edited_at' => ['DATETIME NULL']],
    'categories' => ['icon' => ["VARCHAR(8) NOT NULL DEFAULT ''"], 'active' => ['TINYINT(1) NOT NULL DEFAULT 1'], 'is_sensitive' => ['TINYINT(1) NOT NULL DEFAULT 0'], 'ai_prompt' => ['TEXT NULL'], 'long_desc' => ['TEXT NULL']],
    'articles' => ['category_id' => ['TINYINT UNSIGNED NULL', 'UPDATE articles a JOIN questions q ON q.id=a.question_id SET a.category_id=q.category_id'], 'author_id' => ['INT UNSIGNED NULL'],
      'views' => ['INT UNSIGNED NOT NULL DEFAULT 0'], 'updated_at' => ['DATETIME NULL']],
    'ai_log' => ['tokens_in' => ['INT NOT NULL DEFAULT 0'], 'tokens_out' => ['INT NOT NULL DEFAULT 0'], 'cost_usd' => ['DECIMAL(12,6) NOT NULL DEFAULT 0'], 'purpose' => ["VARCHAR(12) NOT NULL DEFAULT ''"]],
    'ai_providers' => ['price_in' => ['DECIMAL(10,4) NOT NULL DEFAULT 0'], 'price_out' => ['DECIMAL(10,4) NOT NULL DEFAULT 0'], 'monthly_limit' => ['INT NULL'], 'monthly_budget_usd' => ['DECIMAL(10,2) NULL'], 'vision' => ['TINYINT(1) NOT NULL DEFAULT 0']],
    'chat_log' => ['device' => ["CHAR(16) NOT NULL DEFAULT ''"], 'msg_hash' => ["CHAR(16) NOT NULL DEFAULT ''"], 'img' => ['TINYINT(1) NOT NULL DEFAULT 0']],
    'premium_requests' => ['plan' => ["VARCHAR(10) NOT NULL DEFAULT 'month'"]],
  ];
}
// Mở rộng ENUM: [bảng, cột, giá trị cần có, định nghĩa đầy đủ]
function schema_enums(): array {
  return [['users', 'role', 'collab', "ENUM('user','collab','admin') NOT NULL DEFAULT 'user'"], ['answers', 'status', 'pending', "ENUM('published','pending','hidden') NOT NULL DEFAULT 'published'"],
    ['articles', 'status', 'pending', "ENUM('draft','pending','published') NOT NULL DEFAULT 'draft'"], ['content_edits', 'type', 'article', "ENUM('question','answer','article') NOT NULL"]];
}
function schema_seed_categories(): array {
  return [['meo-vat', 'Mẹo vặt đời sống', 'Nấu ăn, giặt giũ, sửa đồ, tiết kiệm trong sinh hoạt hằng ngày', 1, '🏠', 0], ['khoa-hoc', 'Khoa học & Tại sao', 'Những câu hỏi "tại sao" về thế giới xung quanh', 2, '🔬', 0],
    ['cong-nghe', 'Công nghệ & AI', 'Điện thoại, máy tính, phần mềm và trí tuệ nhân tạo', 3, '💻', 0], ['suc-khoe', 'Sức khỏe & Y tế', 'Chăm sóc sức khỏe, dinh dưỡng, bệnh thường gặp (thông tin tham khảo)', 4, '🩺', 1],
    ['am-thuc', 'Ẩm thực & Nấu ăn', 'Công thức, mẹo bếp, món ngon mọi miền', 5, '🍜', 0], ['giao-duc', 'Giáo dục & Học tập', 'Học tập, thi cử, du học, phương pháp học hiệu quả', 6, '📚', 0],
    ['kinh-doanh', 'Kinh doanh & Khởi nghiệp', 'Bán hàng, marketing, quản lý, khởi nghiệp', 7, '💼', 0], ['tai-chinh', 'Tài chính & Đầu tư', 'Tiết kiệm, ngân hàng, thuế, đầu tư (thông tin tham khảo)', 8, '💰', 1],
    ['phap-luat', 'Pháp luật & Thủ tục', 'Quy định, giấy tờ, thủ tục hành chính (thông tin tham khảo)', 9, '⚖', 1], ['du-lich', 'Du lịch & Khám phá', 'Điểm đến, kinh nghiệm đi lại, ăn ở', 10, '🧳', 0],
    ['the-thao', 'Thể thao & Sức bền', 'Bóng đá, chạy bộ, tập luyện, các môn thể thao', 11, '⚽', 0], ['giai-tri', 'Giải trí & Phim ảnh', 'Phim, nhạc, game, sách và sự kiện', 12, '🎬', 0],
    ['van-hoa', 'Văn hóa & Lịch sử', 'Lịch sử, phong tục, lễ hội, danh nhân', 13, '🏛', 0], ['gia-dinh', 'Gia đình & Trẻ em', 'Nuôi dạy con, hôn nhân, cuộc sống gia đình', 14, '👪', 0],
    ['lam-dep', 'Làm đẹp & Thời trang', 'Chăm sóc da, tóc, phối đồ', 15, '💄', 0], ['xe-co', 'Xe cộ & Giao thông', 'Ô tô, xe máy, bảo dưỡng, luật giao thông cơ bản', 16, '🚗', 0],
    ['nha-cua', 'Nhà cửa & Xây dựng', 'Sửa chữa, nội thất, xây dựng, phong thủy', 17, '🔨', 0], ['viec-lam', 'Việc làm & Kỹ năng', 'Tìm việc, CV, phỏng vấn, kỹ năng mềm', 18, '🧠', 0],
    ['thu-cung', 'Thú cưng & Cây cảnh', 'Chăm sóc chó mèo, cá cảnh, cây trồng', 19, '🐶', 0], ['tam-ly', 'Tâm lý & Cuộc sống', 'Cảm xúc, các mối quan hệ, phát triển bản thân', 20, '💭', 1],
    ['moi-truong', 'Môi trường & Nông nghiệp', 'Thiên nhiên, nông nghiệp, tiết kiệm năng lượng', 21, '🌱', 0]];
}
function schema_sync(PDO $pdo): array {
  $log = []; $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $run = function (string $label, string $sql, array $p = []) use ($pdo, &$log) {
    try { $s = $pdo->prepare($sql); $s->execute($p); $log[] = '✔ '.$label; return true; } catch (Throwable $e) { $log[] = '✘ '.$label.' - '.$e->getMessage(); return false; }
  };
  $one = function (string $sql, array $p = []) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($p); return $s->fetchColumn(); };
  try { $pdo->exec('SET NAMES utf8mb4'); $db = (string)$pdo->query('SELECT DATABASE()')->fetchColumn(); } catch (Throwable $e) { return ['✘ Không kết nối được CSDL: '.$e->getMessage()]; }
  $tableExists = fn(string $t) => (bool)$one('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=? AND table_name=?', [$db, $t]);
  $colType = fn(string $t, string $c) => $one('SELECT COLUMN_TYPE FROM information_schema.columns WHERE table_schema=? AND table_name=? AND column_name=?', [$db, $t, $c]);
  foreach (schema_tables() as $t => $ddl) if (!$tableExists($t)) $run("Tạo bảng $t", $ddl);
  // Thống nhất collation (tránh lỗi "Illegal mix of collations" giữa các bảng tạo ở các phiên bản khác nhau)
  foreach (array_keys(schema_tables()) as $t) {
    if (!$tableExists($t)) continue;
    $coll = (string)$one('SELECT table_collation FROM information_schema.tables WHERE table_schema=? AND table_name=?', [$db, $t]);
    if ($coll !== '' && $coll !== 'utf8mb4_unicode_ci') $run("Chuẩn hóa collation bảng $t ($coll → utf8mb4_unicode_ci)", "ALTER TABLE `$t` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
  }
  foreach (schema_columns() as $t => $cols) {
    if (!$tableExists($t)) continue;
    foreach ($cols as $c => $def) {
      if ($colType($t, $c) !== false) continue;
      if ($run("Thêm cột $t.$c", "ALTER TABLE `$t` ADD COLUMN `$c` {$def[0]}") && !empty($def[1])) $run("Khởi tạo dữ liệu $t.$c", $def[1]);
    }
  }
  foreach (schema_enums() as [$t, $c, $need, $def]) {
    if (!$tableExists($t)) continue; $type = (string)$colType($t, $c);
    if ($type !== '' && strpos($type, "'$need'") === false) $run("Mở rộng $t.$c", "ALTER TABLE `$t` MODIFY `$c` $def");
  }
  if ($tableExists('questions') && !$one("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=? AND table_name='questions' AND index_name='ft_q'", [$db])) $run('Tạo chỉ mục tìm kiếm FULLTEXT', 'ALTER TABLE questions ADD FULLTEXT ft_q (title,body)');
  if ($tableExists('users') && !$one("SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=? AND table_name='users' AND column_name='ref_code' AND non_unique=0", [$db])) $run('Tạo chỉ mục duy nhất users.ref_code', 'ALTER TABLE users ADD UNIQUE KEY uq_ref (ref_code)');
  if ($tableExists('categories')) foreach (schema_seed_categories() as [$slug, $name, $desc, $sort, $icon, $sens]) {
    $pdo->prepare('INSERT IGNORE INTO categories(slug,name,description,sort_order,icon,is_sensitive) VALUES(?,?,?,?,?,?)')->execute([$slug, $name, $desc, $sort, $icon, $sens]);
    $pdo->prepare("UPDATE categories SET icon=?,is_sensitive=? WHERE slug=? AND icon=''")->execute([$icon, $sens, $slug]);
  }
  $log[] = '✔ Dữ liệu chuyên mục (lĩnh vực) đã được đồng bộ';
  $seed = function (string $table, string $sql, array $rows) use ($pdo, $tableExists, $one, &$log) {
    if ($tableExists($table) && !(int)$one("SELECT COUNT(*) FROM `$table`")) { $st = $pdo->prepare($sql); foreach ($rows as $r) $st->execute($r); $log[] = "✔ Dữ liệu mẫu cho $table"; }
  };
  $seed('holiday_events', 'INSERT INTO holiday_events(name,start_date,end_date,recurring,bonus_points,premium_bonus) VALUES(?,?,?,?,?,?)', [
    ['Tết Dương lịch', '2027-01-01', '2027-01-01', 1, 20, 30], ['Tết Nguyên Đán 2027 (30 Tết đến mùng 3 - hãy kiểm tra lại ngày)', '2027-02-05', '2027-02-08', 0, 50, 100],
    ['Quốc tế Phụ nữ 8/3', '2027-03-08', '2027-03-08', 1, 15, 25], ['Giải phóng miền Nam 30/4 - Quốc tế Lao động 1/5', '2027-04-30', '2027-05-01', 1, 20, 30], ['Quốc khánh 2/9', '2026-09-02', '2026-09-02', 1, 20, 30],
    ['Ngày Phụ nữ Việt Nam 20/10', '2026-10-20', '2026-10-20', 1, 15, 25], ['Ngày Nhà giáo Việt Nam 20/11', '2026-11-20', '2026-11-20', 1, 15, 25], ['Giáng sinh', '2026-12-24', '2026-12-25', 1, 15, 25]]);
  $seed('quizzes', 'INSERT INTO quizzes(question,options,answer_idx,explanation) VALUES(?,?,?,?)', [
    ['Hành tinh nào gần Mặt Trời nhất?', '["Sao Kim","Sao Thủy","Trái Đất","Sao Hỏa"]', 1, 'Sao Thủy là hành tinh gần Mặt Trời nhất.'], ['Nước nguyên chất sôi ở bao nhiêu độ C ở áp suất khí quyển thông thường?', '["90","100","110","120"]', 1, 'Ở mực nước biển, nước sôi ở 100 độ C.'],
    ['Loài thú nào sau đây biết bay thật sự?', '["Dơi","Sóc bay","Chim cánh cụt","Cá heo"]', 0, 'Dơi là loài thú duy nhất bay thực sự bằng cánh.'], ['Thủ đô của Nhật Bản là gì?', '["Osaka","Kyoto","Tokyo","Nagoya"]', 2, 'Tokyo là thủ đô của Nhật Bản.'],
    ['Khí nào chiếm tỷ lệ lớn nhất trong khí quyển Trái Đất?', '["Oxy","Nitơ","Cacbon đioxit","Argon"]', 1, 'Nitơ chiếm khoảng 78% khí quyển.']]);
  $seed('challenges', 'INSERT INTO challenges(title,metric,target,period,reward) VALUES(?,?,?,?,?)', [['Điểm danh 3 ngày trong tuần', 'checkins', 3, 'weekly', 5], ['Trả lời 3 câu hỏi hôm nay', 'answers', 3, 'daily', 3],
    ['Đặt 1 câu hỏi hôm nay', 'questions', 1, 'daily', 1], ['Nhận 10 lượt bình chọn hữu ích trong tuần', 'upvotes', 10, 'weekly', 10], ['Có 1 câu trả lời được chọn tốt nhất trong tuần', 'best', 1, 'weekly', 10]]);
  $seed('rewards', 'INSERT INTO rewards(name,type,cost_points,vnd_value,stock,min_tier,description) VALUES(?,?,?,?,?,?,?)', [
    ['Thẻ điện thoại 20.000đ', 'phonecard', 800, 20000, -1, 1, 'Gửi mã thẻ qua số điện thoại/Zalo bạn cung cấp'], ['Thẻ điện thoại 50.000đ', 'phonecard', 2000, 50000, -1, 1, 'Gửi mã thẻ qua số điện thoại/Zalo bạn cung cấp'],
    ['Tiền mặt 100.000đ (chuyển khoản)', 'cash', 4000, 100000, -1, 2, 'Cần cấp Bạc trở lên; có thể phải xác minh danh tính'], ['Áo thun Biết Tuốt', 'item', 4800, 120000, 20, 2, 'Giao tận nơi trong nước']]);
  if ($tableExists('articles') && $tableExists('questions')) $run('Gán chuyên mục cho bài viết cũ', 'UPDATE articles a JOIN questions q ON q.id=a.question_id SET a.category_id=q.category_id WHERE a.category_id IS NULL');
  $run('Ghi nhận phiên bản CSDL '.SCHEMA_VERSION, 'REPLACE INTO settings(k,v) VALUES(?,?)', ['schema_version', (string)SCHEMA_VERSION]);
  return $log;
}
