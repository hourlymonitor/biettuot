<?php
// ---------- Quản trị vận hành: sức khỏe hệ thống & sao lưu, chi phí AI, bản tin, điều khoản, bảng kê CTV ----------
route('GET', '#^/admin/suc-khoe$#', function () {
  admin_only(); $checks = health_checks(); $f = ROOT.'/app/logs/error.log'; $log = is_file($f) ? implode('', array_slice(file($f), -40)) : '';
  $bundle = 'Biết Tuốt - báo cáo hệ thống '.date('Y-m-d H:i')."\nPHP ".PHP_VERSION.' | CSDL phiên bản '.(int)setting('schema_version', '0').'/'.SCHEMA_VERSION."\n";
  foreach ($checks as $items) foreach ($items as [$l, $st, $n]) if ($st !== 'ok') $bundle .= "[$st] $l: $n\n";
  $bundle .= "\n--- Nhật ký lỗi (40 dòng gần nhất) ---\n".$log;
  $selftest = $_SESSION['selftest'] ?? null; unset($_SESSION['selftest']);
  render('admin_health', ['checks' => $checks, 'backups' => backup_list(), 'bundle' => $bundle, 'selftest' => $selftest, 'keep' => (int)setting('backup_keep', '7'), 'lastBackup' => (int)setting('backup_last', '0')], 'Sức khỏe hệ thống - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/suc-khoe$#', function () {
  admin_only(); @set_time_limit(180); $act = (string)($_POST['act'] ?? ''); audit('health:'.$act);
  switch ($act) {
    case 'selftest': $_SESSION['selftest'] = selftest_run(); break;
    case 'mail_test':
      $to = (string)pc('admin_email'); if ($to === '') $to = (string)me()['email'];
      $ok = send_mail($to, '[Biết Tuốt] Thư kiểm tra', 'Nếu bạn đọc được thư này, việc gửi email của website hoạt động bình thường.');
      set_setting('mail_test_result', ($ok ? 'ok' : 'lỗi').' lúc '.date('d/m H:i').' tới '.$to); flash($ok ? "Đã gửi thư thử tới $to (kiểm tra cả thư rác)." : "Gửi thư thử THẤT BẠI tới $to. Hãy kiểm tra cấu hình email/SMTP.", $ok ? 'ok' : 'err'); break;
    case 'backup_now': [$ok, $msg] = backup_run(); flash(($ok ? '✔ ' : '✘ ').$msg, $ok ? 'ok' : 'err'); break;
    case 'backup_del': $f = (string)($_POST['f'] ?? ''); if (preg_match('/^\d{8}-\d{6}\.sql\.gz$/', $f)) @unlink(backup_dir().'/'.$f); break;
    case 'backup_cfg': set_setting('backup_keep', (string)max(1, min(60, (int)($_POST['keep'] ?? 7)))); flash('Đã lưu số bản sao lưu giữ lại.', 'ok'); break;
  }
  redirect('/admin/suc-khoe');
});
route('GET', '#^/admin/sao-luu/tai$#', function () {
  admin_only(); $f = (string)($_GET['f'] ?? ''); $p = backup_dir().'/'.$f;
  if (!preg_match('/^\d{8}-\d{6}\.sql\.gz$/', $f) || !is_file($p)) not_found();
  audit('backup:download', $f); header('Content-Type: application/gzip'); header('Content-Disposition: attachment; filename="'.$f.'"'); header('Content-Length: '.filesize($p)); readfile($p);
});

route('GET', '#^/admin/chi-phi-ai$#', function () {
  admin_only(); $m = "created_at>=DATE_FORMAT(NOW(),'%Y-%m-01')"; $d = ['ok' => true];
  try {
    $d['byProv'] = q("SELECT provider,COUNT(*) calls,SUM(ok) okc,COALESCE(SUM(tokens_in),0) tin,COALESCE(SUM(tokens_out),0) tout,COALESCE(SUM(cost_usd),0) cost FROM ai_log WHERE $m GROUP BY provider ORDER BY cost DESC,calls DESC")->fetchAll();
    $d['byPurpose'] = q("SELECT purpose,COUNT(*) calls,COALESCE(SUM(cost_usd),0) cost FROM ai_log WHERE $m AND ok=1 GROUP BY purpose ORDER BY cost DESC,calls DESC")->fetchAll();
    $d['topUsers'] = q("SELECT l.user_id,u.username,COUNT(*) calls,COALESCE(SUM(l.cost_usd),0) cost FROM ai_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.created_at>=DATE_FORMAT(NOW(),'%Y-%m-01') AND l.ok=1 AND l.user_id IS NOT NULL GROUP BY l.user_id,u.username ORDER BY cost DESC,calls DESC LIMIT 15")->fetchAll();
    $days = []; for ($i = 13; $i >= 0; $i--) $days[date('Y-m-d', strtotime("-$i day"))] = ['n' => 0, 'c' => 0.0];
    foreach (q('SELECT DATE(created_at) d,COUNT(*) n,COALESCE(SUM(cost_usd),0) c FROM ai_log WHERE ok=1 AND created_at>=DATE_SUB(CURDATE(),INTERVAL 13 DAY) GROUP BY DATE(created_at)')->fetchAll() as $r) if (isset($days[$r['d']])) $days[$r['d']] = ['n' => (int)$r['n'], 'c' => (float)$r['c']];
    $d['days'] = $days; $d['spendDay'] = ai_spend('day'); $d['spendMonth'] = ai_spend('month');
  } catch (Throwable $e) { $d['ok'] = false; $d += ['byProv' => [], 'byPurpose' => [], 'topUsers' => [], 'days' => [], 'spendDay' => 0.0, 'spendMonth' => 0.0]; }
  $d['rate'] = (float)setting('ai_usd_vnd', '26000'); $d['cfg'] = ['day' => setting('ai_budget_day_usd', '0'), 'month' => setting('ai_budget_month_usd', '0'), 'action' => setting('ai_budget_action', 'fallback')];
  $d['caps'] = []; foreach (['chat', 'answer', 'moderation', 'summary', 'article', 'quiz'] as $p) $d['caps'][$p] = (int)setting('ai_cap_'.$p.'_day', '0');
  render('admin_cost', $d, 'Chi phí AI - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/chi-phi-ai$#', function () {
  admin_only(); audit('ai_budget');
  set_setting('ai_budget_day_usd', (string)max(0, (float)($_POST['day'] ?? 0))); set_setting('ai_budget_month_usd', (string)max(0, (float)($_POST['month'] ?? 0)));
  set_setting('ai_budget_action', ($_POST['action'] ?? '') === 'stop' ? 'stop' : 'fallback'); set_setting('ai_usd_vnd', (string)max(1000, (float)($_POST['rate'] ?? 26000)));
  foreach (['chat', 'answer', 'moderation', 'summary', 'article', 'quiz'] as $p) set_setting('ai_cap_'.$p.'_day', (string)max(0, (int)($_POST['cap_'.$p] ?? 0)));
  flash('Đã lưu ngân sách AI. (Nhớ bật tính năng "Ngân sách AI" ở Admin → Tính năng.)', 'ok'); redirect('/admin/chi-phi-ai');
});

route('GET', '#^/admin/ban-tin$#', function () {
  admin_only(); $ok = true; $st = ['conf' => 0, 'unconf' => 0, 'unsub' => 0];
  try { $st = ['conf' => (int)q('SELECT COUNT(*) FROM newsletter_subs WHERE confirmed=1 AND unsub_at IS NULL')->fetchColumn(), 'unconf' => (int)q('SELECT COUNT(*) FROM newsletter_subs WHERE confirmed=0 AND unsub_at IS NULL')->fetchColumn(), 'unsub' => (int)q('SELECT COUNT(*) FROM newsletter_subs WHERE unsub_at IS NOT NULL')->fetchColumn()]; } catch (Throwable $e) { $ok = false; }
  $dig = news_digest(); [$sub, $body] = news_build(['token' => 'XXXX'], $dig);
  render('admin_news', ['ok' => $ok, 'st' => $st, 'sub' => $sub, 'body' => $body, 'footer' => (string)setting('newsletter_footer', ''), 'last' => (string)setting('newsletter_last', ''), 'empty' => !$dig['questions'] && !$dig['articles']], 'Bản tin - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/ban-tin$#', function () {
  admin_only(); @set_time_limit(120); $act = (string)($_POST['act'] ?? ''); audit('news:'.$act);
  if ($act === 'footer') { set_setting('newsletter_footer', mb_substr(trim((string)($_POST['footer'] ?? '')), 0, 500)); flash('Đã lưu chân thư.', 'ok'); }
  elseif ($act === 'send_test') { [$sub, $body] = news_build(['token' => 'TEST'], news_digest()); $to = (string)pc('admin_email') ?: (string)me()['email']; flash(send_mail($to, '[Thử] '.$sub, $body) ? "Đã gửi thử tới $to." : 'Gửi thử thất bại, kiểm tra cấu hình email.', 'info'); }
  elseif ($act === 'send_all') { $n = news_send_all(); flash($n ? "Đã xếp hàng $n thư; hệ thống gửi dần (cần cron chạy)." : 'Chưa có nội dung mới trong tuần hoặc chưa có người đăng ký.', $n ? 'ok' : 'err'); }
  redirect('/admin/ban-tin');
});

route('GET', '#^/admin/dieu-khoan$#', function () {
  admin_only(); $ver = ctv_terms_ver();
  render('admin_terms', ['text' => ctv_terms_text(), 'ver' => $ver, 'accepted' => (int)q("SELECT COUNT(*) FROM terms_acceptance WHERE doc='ctv' AND version=?", [$ver])->fetchColumn(),
    'ctvs' => (int)q("SELECT COUNT(*) FROM users WHERE role='collab' AND banned=0")->fetchColumn(), 'siteVer' => max(1, (int)setting('terms_site_ver', '1'))], 'Điều khoản - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/dieu-khoan$#', function () {
  admin_only(); audit('terms'); set_setting('terms_ctv', trim((string)($_POST['text'] ?? '')));
  if (!empty($_POST['bump'])) set_setting('terms_ctv_ver', (string)(ctv_terms_ver() + 1));
  if (!empty($_POST['bump_site'])) set_setting('terms_site_ver', (string)(max(1, (int)setting('terms_site_ver', '1')) + 1));
  flash('Đã lưu điều khoản.'.(!empty($_POST['bump']) ? ' Cộng tác viên sẽ phải đồng ý lại.' : ''), 'ok'); redirect('/admin/dieu-khoan');
});
// Bảng kê chia sẻ doanh thu của toàn bộ CTV trong một tháng (phục vụ kê khai / chi trả)
route('GET', '#^/admin/xuat-ctv$#', function () {
  admin_only(); $m = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', (string)($_GET['m'] ?? '')) ? $_GET['m'] : date('Y-m', strtotime('first day of last month')); audit('csv-ctv', $m);
  header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="bang-ke-ctv-'.$m.'.csv"'); echo "\xEF\xBB\xBF"; $o = fopen('php://output', 'w'); $vp = (int)pc('points.vnd_per_point');
  fputcsv($o, ['Thang', 'Ten dang nhap', 'Email', 'Thong tin nhan thuong', 'Diem duoc chia', 'Quy doi uoc tinh (VND)', 'So bai dang', 'Luot xem bai']);
  foreach (q("SELECT u.id,u.username,u.email,u.payout_info,COALESCE(SUM(l.delta),0) pts FROM users u LEFT JOIN point_ledger l ON l.user_id=u.id AND l.kind='revshare' AND l.ref_id=? AND l.status<>'reversed' WHERE u.role='collab' GROUP BY u.id,u.username,u.email,u.payout_info ORDER BY pts DESC", [(int)str_replace('-', '', $m)])->fetchAll() as $r) {
    $art = (int)q("SELECT COUNT(*) FROM articles WHERE author_id=? AND status='published' AND published_at>=? AND published_at<DATE_ADD(?,INTERVAL 1 MONTH)", [$r['id'], "$m-01 00:00:00", "$m-01 00:00:00"])->fetchColumn();
    $views = (int)q('SELECT COALESCE(SUM(s.views),0) FROM article_stats s JOIN articles a ON a.id=s.article_id WHERE a.author_id=? AND s.ym=?', [$r['id'], $m])->fetchColumn();
    fputcsv($o, [$m, $r['username'], $r['email'], $r['payout_info'], $r['pts'], (int)$r['pts'] * $vp, $art, $views]);
  }
  fclose($o);
});
