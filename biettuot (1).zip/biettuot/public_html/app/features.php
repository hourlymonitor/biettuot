<?php
// Bật/tắt tính năng từ Admin > Tính năng. Giá trị lưu trong bảng settings với khóa feat_<tên>.
function feature_groups(): array {
  return ['core' => '🧱 Cốt lõi', 'ai' => '🤖 Trí tuệ nhân tạo', 'content' => '📰 Nội dung', 'points' => '⭐ Điểm & quà tặng', 'paid' => '💎 Chương trình trả phí', 'community' => '👥 Cộng đồng', 'money' => '💰 Kiếm tiền', 'tech' => '⚙️ Kỹ thuật'];
}
// khóa => [nhóm, tên, mô tả, mặc định]
function feature_defs(): array {
  return [
    'maintenance' => ['core', 'Chế độ bảo trì', 'Chỉ quản trị viên truy cập được; khách thấy trang "đang bảo trì".', false],
    'registration' => ['core', 'Cho phép đăng ký thành viên mới', 'Tắt nếu muốn tạm ngừng nhận thành viên.', true],
    'ask' => ['core', 'Đặt câu hỏi', 'Thành viên được đăng câu hỏi mới.', true],
    'answers' => ['core', 'Trả lời câu hỏi', 'Thành viên được đăng câu trả lời.', true],
    'comments' => ['core', 'Bình luận dưới câu trả lời', '', true],
    'votes' => ['core', 'Bình chọn câu trả lời', 'Bình chọn lên/xuống (ảnh hưởng điểm thưởng).', true],
    'require_verified' => ['core', 'Bắt buộc xác minh email để đăng bài', 'Chỉ bật khi email xác minh đã gửi ổn định. Đổi quà/CTV/Premium luôn cần xác minh.', false],
    'cache' => ['core', 'Cache trang cho khách', 'Tăng tốc cho khách chưa đăng nhập (làm mới sau 2 phút).', true],
    'chat' => ['ai', 'Trợ lý AI trò chuyện (/tro-ly)', 'Trang chat với 3 chế độ Nhanh/Thông minh/Chuyên sâu.', true],
    'chat_guest' => ['ai', 'Khách chưa đăng nhập dùng được trợ lý', 'Tắt = bắt buộc đăng nhập để chat.', true],
    'ai_answers' => ['ai', 'AI tự trả lời câu hỏi mới', 'Mỗi câu hỏi mới nhận một câu trả lời nháp từ AI.', true],
    'ai_moderation' => ['ai', 'AI kiểm duyệt nội dung của thành viên mới', 'Phân loại spam/vi phạm trước khi đăng.', true],
    'ai_summary' => ['ai', 'AI tóm tắt câu trả lời', 'Tự tóm tắt khi câu hỏi có từ 3 câu trả lời.', true],
    'ai_articles' => ['ai', 'AI viết bài nháp từ câu hỏi hay', 'Nút "Tạo bài nháp bằng AI" trong Admin > Nội dung.', true],
    'ai_quizgen' => ['ai', 'AI tạo câu đố vui', '', true],
    'chat_rag' => ['ai', 'Trợ lý dựa trên kho nội dung của site', 'Trợ lý tìm câu hỏi/câu trả lời/bài viết liên quan trên Biết Tuốt để trả lời và trích dẫn nguồn.', true],
    'chat_history' => ['ai', 'Lưu lịch sử chat vào tài khoản', 'Thành viên xem lại cuộc trò chuyện trên mọi thiết bị; có thể xóa bất cứ lúc nào.', true],
    'chat_share' => ['ai', 'Chia sẻ cuộc trò chuyện bằng liên kết', 'Thành viên tạo liên kết công khai (ai có liên kết đều xem được).', true],
    'articles' => ['content', 'Bài viết', 'Mục bài viết SEO và lượt xem bài.', true],
    'qotd' => ['content', 'Câu hỏi của ngày', 'Hiển thị ở trang chủ, trả lời nhận thêm điểm.', true],
    'quiz' => ['content', 'Đố vui hằng ngày', '', true],
    'points' => ['points', 'Hệ thống điểm & ví', 'Tắt = không cộng điểm, ẩn ví điểm.', true],
    'checkin' => ['points', 'Điểm danh hằng ngày', '', true],
    'challenges' => ['points', 'Thử thách', '', true],
    'rewards' => ['points', 'Đổi quà tặng', 'Đổi điểm lấy thẻ điện thoại, tiền, vật phẩm.', true],
    'leaderboard' => ['points', 'Bảng xếp hạng', '', true],
    'badges' => ['points', 'Huy hiệu thành tựu', '', true],
    'referral' => ['points', 'Giới thiệu bạn bè', '', true],
    'birthday_holiday' => ['points', 'Quà sinh nhật & lễ Tết', '', true],
    'ctv' => ['paid', 'Chương trình cộng tác viên', 'Ứng tuyển, khu vực CTV, viết/sửa bài theo lĩnh vực, chia sẻ doanh thu.', true],
    'premium' => ['paid', 'Gói Premium (tháng/năm)', '', true],
    'pay_auto' => ['paid', 'Thanh toán Premium tự động (QR + đối soát)', 'Hiện mã VietQR và tự kích hoạt khi nhận chuyển khoản. Cần cấu hình ở Admin > Thanh toán.', false],
    'follows' => ['community', 'Theo dõi câu hỏi/chuyên mục/thành viên', '', true],
    'notifications' => ['community', 'Thông báo trong trang', '', true],
    'profiles' => ['community', 'Hồ sơ công khai (/u/...)', '', true],
    'ads' => ['money', 'Hiển thị quảng cáo', 'Cần dán mã quảng cáo ở Admin > Quảng cáo.', true],
    'affiliates' => ['money', 'Liên kết tiếp thị', '', true],
    'pwa' => ['tech', 'Ứng dụng cài được (PWA)', 'Manifest + service worker.', true],
    'push' => ['tech', 'Thông báo đẩy (Web Push)', 'Cần tạo khóa VAPID ở Admin > Hệ thống.', false],
    'chat_abuse' => ['ai', 'Chống lạm dụng chat', 'Giới hạn tốc độ, chặn tin trùng lặp, đếm theo thiết bị, yêu cầu Turnstile cho khách (nếu đã cấu hình).', true],
    'ai_budget' => ['ai', 'Ngân sách AI', 'Áp dụng trần chi phí/lượt theo ngày, tháng, tính năng (Admin > Chi phí AI).', true],
    'chat_image' => ['ai', 'Hỏi trợ lý bằng ảnh', 'Cần đánh dấu "hỗ trợ ảnh" cho AI tương ứng ở Admin > AI; chỉ thành viên đăng nhập.', false],
    'content_gaps' => ['content', 'Bảng nhu cầu nội dung', 'Ghi nhận câu hỏi mà site chưa có nội dung để giao cộng tác viên viết.', true],
    'ai_drafts' => ['content', 'AI soạn bản nháp bài viết cho cộng tác viên', '', true],
    'og_images' => ['tech', 'Ảnh xem trước khi chia sẻ (Open Graph)', 'Tạo ảnh riêng cho từng câu hỏi/bài viết khi chia sẻ lên mạng xã hội.', true],
    'auto_backup' => ['tech', 'Sao lưu tự động hằng ngày', 'Cần cron; lưu trong app/backups.', true],
    'newsletter' => ['community', 'Bản tin email hằng tuần', 'Biểu mẫu đăng ký ở chân trang + gửi tự động sáng thứ Hai (cần cron và email gửi ổn định).', false],
    'experts' => ['community', 'Danh bạ chuyên gia / cộng tác viên (/chuyen-gia)', '', true],
    '2fa' => ['core', 'Xác thực hai lớp (2FA)', 'Thành viên có thể bật 2FA ở Cài đặt.', true],
    'enforce_2fa' => ['core', 'Bắt buộc 2FA cho quản trị viên và CTV', 'Họ sẽ bị chuyển tới trang bật 2FA trước khi vào khu vực quản trị/CTV.', false],
    'data_tools' => ['core', 'Xuất / xóa dữ liệu cá nhân', 'Thành viên tự tải dữ liệu hoặc xóa tài khoản ở Cài đặt.', true],
    'fab' => ['tech', 'Nút nổi "Hỏi trợ lý" (máy tính)', '', true],
  ];
}
function settings_all(bool $reload = false): array {
  static $c = null;
  if ($c === null || $reload) { try { $c = q('SELECT k,v FROM settings')->fetchAll(PDO::FETCH_KEY_PAIR); } catch (Throwable $e) { $c = []; } }
  return $c;
}
function feature(string $k): bool {
  $v = settings_all()['feat_'.$k] ?? null;
  if ($v === null) { if ($k === 'require_verified') return (bool)cfg('require_verified', false); $d = feature_defs()[$k] ?? null; return $d ? (bool)$d[3] : true; }
  return (string)$v === '1';
}
function feature_set(string $k, bool $on): void { set_setting('feat_'.$k, $on ? '1' : '0'); }
// Đường dẫn => tính năng. Khi tính năng tắt, người dùng thường thấy trang "đang tạm tắt"; quản trị viên vẫn truy cập để kiểm tra.
function feature_gates(): array {
  return ['#^/tro-ly(/|$)#' => 'chat', '#^/api/chat#' => 'chat', '#^/chia-se/#' => 'chat_share', '#^/chuyen-gia#' => 'experts', '#^/cai-dat/du-lieu#' => 'data_tools', '#^/(cai-dat/2fa|dang-nhap/2fa)#' => '2fa', '#^/ban-tin#' => 'newsletter', '#^/(thanh-toan|api/thanh-toan)#' => 'premium', '#^/bai-viet#' => 'articles', '#^/api/xem$#' => 'articles', '#^/(cong-tac-vien|ctv)(/|$)#' => 'ctv',
    '#^/(vi|thu-thach)(/|$)#' => 'points', '#^/(qua-tang|doi-qua)(/|$)#' => 'rewards', '#^/do-vui$#' => 'quiz', '#^/xep-hang$#' => 'leaderboard', '#^/goi-thanh-vien$#' => 'premium',
    '#^/go/#' => 'affiliates', '#^/binh-luan#' => 'comments', '#^/vote$#' => 'votes', '#^/hoi-moi$#' => 'ask', '#^/tra-loi$#' => 'answers', '#^/ai-tra-loi$#' => 'ai_answers',
    '#^/theo-doi$#' => 'follows', '#^/(thong-bao|api/thong-bao-moi)$#' => 'notifications', '#^/push/#' => 'push', '#^/u/#' => 'profiles', '#^/dang-ky$#' => 'registration'];
}
