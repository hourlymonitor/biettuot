<?php
$method = $_SERVER['REQUEST_METHOD'];
$path = '/'.trim(rawurldecode((string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)), '/');
if ($method === 'POST' && $path !== '/api/chat' && $path !== '/ban-tin/dang-ky' && strpos($path, '/webhook/') !== 0) csrf_check();   // /api/chat có giới hạn riêng; trang khách được cache nên không nhúng token

// ---- Bảo trì, kiểm tra CSDL, bật/tắt tính năng ----
if (!cfg('skip_schema_check') && !schema_current() && !preg_match('#^/(dang-nhap|dang-xuat|admin|cron|webhook)#', $path)) {
  http_response_code(503); header('Retry-After: 300');
  echo '<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Đang nâng cấp</title><body style="font-family:system-ui;max-width:560px;margin:15vh auto;padding:0 16px;text-align:center"><h1>🛠 Hệ thống đang được nâng cấp</h1><p>Vui lòng quay lại sau ít phút.</p><p style="color:#666;font-size:.9rem">Quản trị viên: chạy <code>/install.php</code> để cập nhật cơ sở dữ liệu.</p></body></html>'; exit;
}
if (feature('maintenance') && !is_admin() && !preg_match('#^/(dang-nhap|dang-xuat|admin|cron|webhook)#', $path)) { http_response_code(503); header('Retry-After: 600'); render('maintenance', [], 'Đang bảo trì', '', ['noindex' => true]); exit; }
foreach (feature_gates() as $__re => $__fk) {
  if (!preg_match($__re, $path) || feature($__fk) || is_admin()) continue;
  if (strpos($path, '/api/') === 0) { header('Content-Type: application/json; charset=utf-8'); http_response_code(403); echo json_encode(['error' => 'off', 'message' => 'Tính năng đang tạm tắt.']); exit; }
  http_response_code(403); render('feature_off', ['fname' => feature_defs()[$__fk][1]], 'Tính năng đang tạm tắt', '', ['noindex' => true]); exit;
}
if (feature('enforce_2fa') && feature('2fa') && ($__u = me()) && in_array($__u['role'], ['admin', 'collab'], true) && empty($__u['totp_enabled']) && preg_match('#^/(admin|ctv)#', $path)) { flash('Hãy bật xác thực hai lớp (2FA) để vào khu vực này.', 'err'); redirect('/cai-dat/2fa'); }
if ($method === 'GET' && strpos($path, '/api/') !== 0 && ($cu = me())) { try { daily_checkin($cu); if (random_int(1, 40) === 1) settle_due(); } catch (Throwable $e) { app_log('checkin/settle: '.$e->getMessage()); } }

function route(string $verb, string $re, callable $fn): void {
  global $method, $path;
  if ($method !== $verb || !preg_match($re, $path, $m)) return;
  array_shift($m); $fn(...$m); exit;
}
function qurl(array $r): string { return '/hoi/'.$r['slug'].'-'.$r['id']; }
function cats(): array { static $c; return $c ??= q('SELECT * FROM categories ORDER BY sort_order,id')->fetchAll(); }
function list_questions(string $where, array $p, int $page, int $per = 15): array {
  $off = max(0, $page - 1) * $per;
  return q("SELECT q.*,c.name cat,c.slug cslug,u.username FROM questions q JOIN categories c ON c.id=q.category_id JOIN users u ON u.id=q.user_id
            WHERE q.status='published' $where ORDER BY q.created_at DESC LIMIT $per OFFSET $off", $p)->fetchAll();
}
function save_ai_answer(int $qid, string $title, string $body, ?int $uid): bool {
  set_time_limit(90);
  $cp = q('SELECT c.ai_prompt,c.is_sensitive FROM questions q JOIN categories c ON c.id=q.category_id WHERE q.id=?', [$qid])->fetch() ?: null; $r = ai_answer($title, $body, $uid, category_rules($cp)); if (!$r) return false;
  q('INSERT INTO answers(question_id,is_ai,ai_provider,ai_model,body) VALUES(?,1,?,?,?)', [$qid, $r['provider'], $r['model'], $r['text']]);
  q('UPDATE questions SET answers_count=answers_count+1 WHERE id=?', [$qid]); cache_clear();
  return true;
}
function page_no(): int { return max(1, (int)($_GET['page'] ?? 1)); }

// ---------- Trang công khai ----------
route('GET', '#^/$#', function () {
  render('list', ['qs' => list_questions('', [], page_no()), 'heading' => 'Câu hỏi mới nhất', 'page' => page_no(), 'base' => '/', 'hero' => true, 'qotd' => feature('qotd') ? qotd() : null, 'quiz' => feature('quiz') ? daily_quiz() : null, 'ptags' => popular_tags()],
    cfg('site_name').' - Hỏi gì cũng có câu trả lời', 'Hỏi đáp tiếng Việt: AI trả lời tức thì, cộng đồng bổ sung và bình chọn.', ['cache' => true, 'home' => true]);
});
route('GET', '#^/c/([a-z0-9-]+)$#', function ($slug) {
  $c = q('SELECT * FROM categories WHERE slug=?', [$slug])->fetch(); if (!$c) not_found(); $page = page_no(); $landing = null;
  if ($page === 1) {
    $landing = ['long' => (string)($c['long_desc'] ?? ''),
      'articles' => feature('articles') ? q("SELECT id,slug,title FROM articles WHERE status='published' AND category_id=? ORDER BY published_at DESC LIMIT 4", [$c['id']])->fetchAll() : [],
      'unanswered' => q("SELECT id,slug,title FROM questions WHERE status='published' AND category_id=? AND answers_count<=1 ORDER BY created_at DESC LIMIT 5", [$c['id']])->fetchAll(),
      'ctvs' => feature('ctv') ? q("SELECT u.username,u.expert_title FROM mod_categories m JOIN users u ON u.id=m.user_id WHERE m.category_id=? AND u.role='collab' AND u.banned=0 LIMIT 8", [$c['id']])->fetchAll() : []];
  }
  render('list', ['qs' => list_questions('AND q.category_id=?', [$c['id']], $page), 'heading' => $c['icon'].' '.$c['name'], 'sub' => $c['description'], 'page' => $page, 'base' => '/c/'.$slug, 'followBtn' => follow_button('category', (int)$c['id'], 'Theo dõi chuyên mục'), 'landing' => $landing],
    $c['name'].' - hỏi đáp & bài viết - '.cfg('site_name'), $c['description'], ['cache' => true, 'og' => ['title' => $c['name'].' - '.cfg('site_name'), 'desc' => $c['description']]]);
});
route('GET', '#^/tim$#', function () {
  $s = trim((string)($_GET['q'] ?? '')); $page = page_no();
  $qs0 = search_questions($s, $page); if (!$qs0 && $page === 1 && mb_strlen($s) >= 8) gap_log($s);
  render('list', ['qs' => $qs0, 'heading' => $s !== '' ? 'Kết quả cho: '.$s : 'Tìm kiếm', 'page' => $page, 'base' => '/tim?q='.rawurlencode($s), 'searchbox' => true, 'q_text' => $s], 'Tìm kiếm', '', ['noindex' => true]);
});
route('GET', '#^/api/tuong-tu$#', function () {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(array_map(fn($r) => ['t' => $r['title'], 'u' => qurl($r)], search_questions((string)($_GET['q'] ?? ''), 1, 5)), JSON_UNESCAPED_UNICODE);
});
route('GET', '#^/trang/(gioi-thieu|quy-dinh|bao-mat|dieu-khoan)$#', function ($s) {
  render('page', ['slug' => $s], 'Biết Tuốt - '.$s, '');
});
route('GET', '#^/robots\.txt$#', function () {
  header('Content-Type: text/plain');
  echo cfg('noindex') ? "User-agent: *\nDisallow: /\n" : "User-agent: *\nDisallow: /admin\nDisallow: /tim\nDisallow: /api/\nSitemap: ".url('/sitemap.xml')."\n";
});
route('GET', '#^/sitemap\.xml$#', function () {
  header('Content-Type: application/xml; charset=utf-8');
  echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
  echo '<url><loc>'.e(url('/')).'</loc></url><url><loc>'.e(url('/bai-viet')).'</loc></url>';
  foreach (cats() as $c) echo '<url><loc>'.e(url('/c/'.$c['slug'])).'</loc></url>';
  foreach (q('SELECT DISTINCT t.slug FROM tags t JOIN question_tags qt ON qt.tag_id=t.id') as $t) echo '<url><loc>'.e(url('/the/'.$t['slug'])).'</loc></url>';
  foreach (q("SELECT id,slug,published_at FROM articles WHERE status='published' ORDER BY id DESC LIMIT 2000") as $a)
    echo '<url><loc>'.e(url('/bai-viet/'.$a['slug'].'-'.$a['id'])).'</loc><lastmod>'.date('c', strtotime($a['published_at'])).'</lastmod></url>';
  foreach (q("SELECT id,slug,created_at FROM questions WHERE status='published' ORDER BY id DESC LIMIT 5000") as $r)
    echo '<url><loc>'.e(url(qurl($r))).'</loc><lastmod>'.date('c', strtotime($r['created_at'])).'</lastmod></url>';
  echo '</urlset>';
});

// ---------- Câu hỏi ----------
route('GET', '#^/hoi-moi$#', function () { require_verified(); render('ask', ['old' => ['title' => mb_substr(trim((string)($_GET['title'] ?? '')), 0, 200), 'body' => mb_substr(trim((string)($_GET['body'] ?? '')), 0, 5000)]], 'Đặt câu hỏi - '.cfg('site_name'), '', ['noindex' => true]); });
route('POST', '#^/hoi-moi$#', function () {
  $u = require_verified();
  if (!empty($_POST['hp_note'])) redirect('/');
  $title = trim((string)($_POST['title'] ?? '')); $body = trim((string)($_POST['body'] ?? '')); $cid = (int)($_POST['category'] ?? 0); $tags = trim((string)($_POST['tags'] ?? ''));
  $fail = function (string $m) use ($title, $body, $cid, $tags) { render('ask', ['err' => $m, 'old' => compact('title', 'body', 'cid', 'tags')], 'Đặt câu hỏi - '.cfg('site_name'), '', ['noindex' => true]); };
  $err = null;
  if (mb_strlen($title) < 10 || mb_strlen($title) > 200) $err = 'Tiêu đề cần từ 10 đến 200 ký tự.';
  elseif (mb_strlen($body) > 5000) $err = 'Nội dung tối đa 5000 ký tự.';
  elseif (!q('SELECT 1 FROM categories WHERE id=?', [$cid])->fetchColumn()) $err = 'Hãy chọn chuyên mục.';
  elseif (!turnstile_ok()) $err = 'Xác minh chống robot không thành công, hãy thử lại.';
  elseif (over_limit('questions', 'user_id', $u['id'], (int)cfg('limits.questions_per_day', 5))) $err = 'Hôm nay bạn đã đặt đủ số câu hỏi cho phép.';
  if ($err) { $fail($err); return; }
  $status = 'published';
  if (preg_match_all('#https?://#i', $title.' '.$body) > 1) $status = 'pending';
  elseif (low_trust($u)) {
    $m = ai_moderate($title."\n".$body, (int)$u['id']);
    if ($m['verdict'] === 'block') { $fail('Nội dung có vẻ vi phạm quy định cộng đồng nên không thể đăng.'); return; }
    if ($m['verdict'] === 'review') $status = 'pending';
  }
  $slug = slugify($title);
  q('INSERT INTO questions(user_id,category_id,title,slug,body,status) VALUES(?,?,?,?,?,?)', [$u['id'], $cid, $title, $slug, $body, $status]);
  $id = (int)db()->lastInsertId(); set_tags($id, $tags); follow_set((int)$u['id'], 'question', $id); $link = '/hoi/'.$slug.'-'.$id;
  if ($status === 'published') {
    earn((int)$u['id'], 'question', $id); check_badges((int)$u['id']);
    notify_followers('category', $cid, 'question', 'Câu hỏi mới: '.mb_substr($title, 0, 90), $link, [(int)$u['id']], 100);
    notify_followers('user', (int)$u['id'], 'question', $u['username'].' vừa đặt câu hỏi: '.mb_substr($title, 0, 80), $link, [(int)$u['id']], 100);
    if (feature('ai_answers') && ai_providers() && !over_limit('ai_log', 'user_id', $u['id'], ai_limit_for($u), 'AND ok=1')) job_add('ai_answer', $id);
  } else flash('Câu hỏi đang chờ kiểm duyệt, chúng tôi sẽ thông báo khi được duyệt.');
  cache_clear(); redirect($link);
});
route('GET', '#^/hoi/(?:.*-)?(\d+)$#', function ($id) {
  $r = q('SELECT q.*,c.name cat,c.slug cslug,c.is_sensitive csens,u.username,u.xp,u.role,u.premium_until,u.expert_title FROM questions q JOIN categories c ON c.id=q.category_id JOIN users u ON u.id=q.user_id WHERE q.id=?', [$id])->fetch();
  if ($r && $r['merged_into']) redirect('/hoi/x-'.(int)$r['merged_into'], 301);
  $me = me(); $own = $r && $me && ((int)$me['id'] === (int)$r['user_id'] || is_admin());
  if (!$r || ($r['status'] !== 'published' && !$own)) not_found();
  $canon = qurl($r);
  if (rawurldecode((string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)) !== $canon) redirect($canon, 301);
  q('UPDATE questions SET views=views+1 WHERE id=?', [$id]);
  $answers = q("SELECT a.*,u.username,u.xp,u.role,u.premium_until,u.expert_title FROM answers a LEFT JOIN users u ON u.id=a.user_id WHERE a.question_id=? AND a.status='published'
                ORDER BY a.is_best DESC,a.score DESC,a.is_ai ASC,a.id ASC", [$id])->fetchAll();
  $myvotes = $me ? q('SELECT answer_id,value FROM votes WHERE user_id=? AND answer_id IN (SELECT id FROM answers WHERE question_id=?)', [$me['id'], $id])->fetchAll(PDO::FETCH_KEY_PAIR) : [];
  $hasAi = (bool)array_filter($answers, fn($a) => $a['is_ai']);
  $comments = [];
  foreach (q("SELECT c.*,u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.status='published' AND c.answer_id IN (SELECT id FROM answers WHERE question_id=?) ORDER BY c.id", [$id])->fetchAll() as $c) $comments[$c['answer_id']][] = $c;
  $jobPending = !$hasAi && $r['status'] === 'published' && (bool)q("SELECT 1 FROM jobs WHERE type='ai_answer' AND ref_id=? AND status IN ('pending','running')", [$id])->fetchColumn();
  $isMod = is_admin() || ($me['role'] ?? '') === 'collab';
  $edits = $isMod ? q("SELECT * FROM content_edits WHERE type='question' AND target_id=? ORDER BY id DESC LIMIT 5", [$id])->fetchAll() : [];
  $related = $r['status'] === 'published' ? related_questions($r, 5) : [];
  $noAi = !ai_providers() || !feature('ai_answers'); $canVote = feature('votes'); $canComment = feature('comments'); $tags = question_tags((int)$id); $qd = qotd(); $isQotd = $qd && (int)$qd['id'] === (int)$id;
  $desc = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($answers[0]['body'] ?? $r['body']))), 0, 155);
  render('question', compact('r', 'answers', 'myvotes', 'hasAi', 'own', 'comments', 'jobPending', 'isMod', 'edits', 'related', 'tags', 'isQotd', 'noAi', 'canVote', 'canComment'),
    $r['title'].' - '.cfg('site_name'), $desc, ['noindex' => $r['status'] !== 'published', 'cache' => $r['status'] === 'published' && $hasAi && !$jobPending, 'og' => ['title' => $r['title'], 'desc' => $desc, 'image' => url('/og/q/'.(int)$id.'.png'), 'type' => 'article']]);
});
route('POST', '#^/tra-loi$#', function () {
  $u = require_verified(); $qid = (int)($_POST['question_id'] ?? 0); $body = trim((string)($_POST['body'] ?? ''));
  $r = q("SELECT * FROM questions WHERE id=? AND status='published'", [$qid])->fetch(); if (!$r) not_found();
  if (!empty($_POST['hp_note'])) redirect('/');
  if (mb_strlen($body) < 10 || mb_strlen($body) > 5000) { flash('Câu trả lời cần từ 10 đến 5000 ký tự.', 'err'); redirect(qurl($r)); }
  if (over_limit('answers', 'user_id', $u['id'], (int)cfg('limits.answers_per_day', 20))) { flash('Bạn đã đạt giới hạn trả lời hôm nay.', 'err'); redirect(qurl($r)); }
  $status = 'published';
  if (low_trust($u)) {
    $m = ai_moderate($body, (int)$u['id']);
    if ($m['verdict'] === 'block') { flash('Nội dung có vẻ vi phạm quy định cộng đồng nên không thể đăng.', 'err'); redirect(qurl($r)); }
    if ($m['verdict'] === 'review') $status = 'pending';
  }
  q('INSERT INTO answers(question_id,user_id,body,status) VALUES(?,?,?,?)', [$qid, $u['id'], $body, $status]); $aid = (int)db()->lastInsertId();
  if ($status === 'published') { after_answer($u, $r, $aid); flash('Đã đăng câu trả lời.', 'ok'); } else flash('Câu trả lời đang chờ kiểm duyệt.');
  redirect(qurl($r));
});
route('POST', '#^/ai-tra-loi$#', function () {
  $u = require_login();
  $r = q("SELECT * FROM questions WHERE id=? AND status='published'", [(int)($_POST['question_id'] ?? 0)])->fetch(); if (!$r) not_found();
  if (q('SELECT 1 FROM answers WHERE question_id=? AND is_ai=1', [$r['id']])->fetchColumn()) redirect(qurl($r));
  if (over_limit('ai_log', 'user_id', $u['id'], ai_limit_for($u), 'AND ok=1')) flash('Bạn đã dùng hết lượt hỏi AI hôm nay.', 'err');
  elseif (!q("SELECT 1 FROM jobs WHERE type='ai_answer' AND ref_id=? AND status IN ('pending','running')", [$r['id']])->fetchColumn()) { job_add('ai_answer', (int)$r['id']); flash('Đang nhờ AI trả lời…', 'ok'); }
  redirect(qurl($r));
});
route('POST', '#^/vote$#', function () {
  $u = require_verified(); $aid = (int)($_POST['answer_id'] ?? 0); $val = ((int)($_POST['value'] ?? 0)) > 0 ? 1 : -1;
  $a = q("SELECT a.*,q.slug qslug,q.id qid FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.id=? AND a.status='published'", [$aid])->fetch(); if (!$a) not_found();
  $back = '/hoi/'.$a['qslug'].'-'.$a['qid'].'#a'.$aid;
  if ((int)$a['user_id'] === (int)$u['id']) { flash('Bạn không thể tự bình chọn câu trả lời của mình.', 'err'); redirect($back); }
  $old = q('SELECT value FROM votes WHERE user_id=? AND answer_id=?', [$u['id'], $aid])->fetchColumn();
  if ($old !== false && (int)$old === $val) { q('DELETE FROM votes WHERE user_id=? AND answer_id=?', [$u['id'], $aid]); $final = 0; }
  else { q('REPLACE INTO votes(user_id,answer_id,value) VALUES(?,?,?)', [$u['id'], $aid, $val]); $final = $val; }
  q('UPDATE answers SET score=(SELECT COALESCE(SUM(value),0) FROM votes WHERE answer_id=?) WHERE id=?', [$aid, $aid]);
  if ($a['user_id']) {
    $au = (int)$a['user_id'];
    if ($final > 0 && time() - strtotime($u['created_at']) >= (int)pc('points.min_voter_age_days') * 86400) { if (earn($au, 'upvote', $aid, (int)$u['id'])) check_badges($au); }
    elseif ($final <= 0) pts_reverse('upvote', $aid, $au, (int)$u['id']);
    $score = (int)q('SELECT score FROM answers WHERE id=?', [$aid])->fetchColumn();
    if ($score >= (int)pc('points.top_vote_threshold')) { if (earn($au, 'topvote', $aid)) notify($au, 'vote', 'Câu trả lời của bạn đạt '.$score.' bình chọn!', $back); } else pts_reverse('topvote', $aid, $au);
  }
  redirect($back);
});
route('POST', '#^/chon-tot-nhat$#', function () {
  $u = require_login();
  $a = q('SELECT a.id,a.user_id,a.question_id,q.user_id owner,q.slug,q.id qid FROM answers a JOIN questions q ON q.id=a.question_id WHERE a.id=?', [(int)($_POST['answer_id'] ?? 0)])->fetch();
  if (!$a || ((int)$a['owner'] !== (int)$u['id'] && !is_admin())) not_found();
  q('UPDATE answers SET is_best=0 WHERE question_id=?', [$a['question_id']]);
  q('UPDATE answers SET is_best=1 WHERE id=?', [$a['id']]);
  foreach (q('SELECT id FROM answers WHERE question_id=? AND id<>?', [$a['question_id'], $a['id']])->fetchAll(PDO::FETCH_COLUMN) as $oid) pts_reverse('best', (int)$oid);
  if ($a['user_id'] && (int)$a['user_id'] !== (int)$a['owner']) { if (earn((int)$a['user_id'], 'best', (int)$a['id'])) { notify((int)$a['user_id'], 'best', 'Câu trả lời của bạn được chọn là tốt nhất!', '/hoi/'.$a['slug'].'-'.$a['qid'].'#a'.$a['id'], true); check_badges((int)$a['user_id']); } }
  redirect('/hoi/'.$a['slug'].'-'.$a['qid'].'#a'.$a['id']);
});
route('POST', '#^/bao-cao$#', function () {
  $u = require_login(); $t = ($_POST['type'] ?? '') === 'answer' ? 'answer' : 'question';
  q('INSERT INTO reports(user_id,target_type,target_id,reason) VALUES(?,?,?,?)', [$u['id'], $t, (int)($_POST['id'] ?? 0), mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 255)]);
  flash('Cảm ơn bạn, chúng tôi sẽ xem xét báo cáo.', 'ok'); redirect(safe_path($_POST['back'] ?? '/'));
});

// ---------- Tài khoản ----------
route('GET', '#^/dang-ky$#', function () {
  if (!empty($_GET['ref'])) $_SESSION['ref'] = substr(preg_replace('/[^A-Za-z0-9]/', '', (string)$_GET['ref']), 0, 12);
  render('auth', ['mode' => 'register'], 'Đăng ký - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/dang-ky$#', function () {
  if (!empty($_POST['hp_note'])) redirect('/');
  $un = trim((string)($_POST['username'] ?? '')); $em = strtolower(trim((string)($_POST['email'] ?? ''))); $pw = (string)($_POST['password'] ?? ''); $ip = client_ip(); $err = null;
  if (!preg_match('/^[A-Za-z0-9_]{3,30}$/', $un)) $err = 'Tên đăng nhập 3-30 ký tự: chữ không dấu, số hoặc dấu _.';
  elseif (!filter_var($em, FILTER_VALIDATE_EMAIL)) $err = 'Email không hợp lệ.';
  elseif (strlen($pw) < 8) $err = 'Mật khẩu tối thiểu 8 ký tự.';
  elseif (empty($_POST['agree'])) $err = 'Bạn cần đồng ý Điều khoản và Chính sách bảo mật để đăng ký.';
  elseif (!turnstile_ok()) $err = 'Xác minh chống robot không thành công, hãy thử lại.';
  elseif (q('SELECT 1 FROM users WHERE username=? OR email=?', [$un, $em])->fetchColumn()) $err = 'Tên đăng nhập hoặc email đã tồn tại.';
  elseif ((int)q('SELECT COUNT(*) FROM users WHERE signup_ip=? AND created_at>=DATE_SUB(NOW(),INTERVAL 1 DAY)', [$ip])->fetchColumn() >= 3) $err = 'Có quá nhiều tài khoản được tạo từ mạng của bạn hôm nay. Hãy thử lại sau.';
  if ($err) { render('auth', ['mode' => 'register', 'err' => $err], 'Đăng ký', '', ['noindex' => true]); return; }
  $first = !q('SELECT 1 FROM users LIMIT 1')->fetchColumn();   // người đăng ký đầu tiên = quản trị viên (tự xác minh)
  $ref = !empty($_SESSION['ref']) ? (q('SELECT id FROM users WHERE ref_code=?', [$_SESSION['ref']])->fetchColumn() ?: null) : null;
  q('INSERT INTO users(username,email,pass_hash,role,signup_ip,last_ip,referred_by,email_verified) VALUES(?,?,?,?,?,?,?,?)',
    [$un, $em, password_hash($pw, PASSWORD_DEFAULT), $first ? 'admin' : 'user', $ip, $ip, $ref, $first ? 1 : 0]);
  $uid = (int)db()->lastInsertId(); q('INSERT IGNORE INTO terms_acceptance(user_id,doc,version,ip) VALUES(?,?,?,?)', [$uid, 'site', max(1, (int)setting('terms_site_ver', '1')), $ip]); session_regenerate_id(true); $_SESSION['uid'] = $uid; unset($_SESSION['ref']); log_login($uid, true);
  earn($uid, 'signup');
  if (!$first) { send_verification($uid, $em, $un); flash('Chào mừng bạn! Hãy kiểm tra email để xác minh tài khoản (xem cả thư mục spam).', 'ok'); }
  redirect('/');
});
route('GET', '#^/dang-nhap$#', fn() => render('auth', ['mode' => 'login'], 'Đăng nhập - '.cfg('site_name'), '', ['noindex' => true]));
route('POST', '#^/dang-nhap$#', function () {
  $ip = client_ip(); $fail = fn(string $m) => render('auth', ['mode' => 'login', 'err' => $m], 'Đăng nhập', '', ['noindex' => true]);
  if ((int)q('SELECT COUNT(*) FROM login_log WHERE ip=? AND ok=0 AND created_at>=DATE_SUB(NOW(),INTERVAL 10 MINUTE)', [$ip])->fetchColumn() >= 10) { $fail('Thử sai quá nhiều lần, hãy đợi vài phút.'); return; }
  if (!turnstile_ok()) { $fail('Xác minh chống robot không thành công, hãy thử lại.'); return; }
  $l = trim((string)($_POST['login'] ?? ''));
  $u = q('SELECT * FROM users WHERE (username=? OR email=?) AND banned=0', [$l, strtolower($l)])->fetch();
  if (!$u || !password_verify((string)($_POST['password'] ?? ''), $u['pass_hash'])) { log_login((int)($u['id'] ?? 0), false); usleep(300000); $fail('Sai tên đăng nhập hoặc mật khẩu.'); return; }
  log_login((int)$u['id'], true); q('UPDATE users SET last_ip=? WHERE id=?', [$ip, $u['id']]);
  $next = safe_path($_SESSION['next'] ?? '/');
  if (feature('2fa') && !empty($u['totp_enabled'])) { $_SESSION['p2fa'] = ['uid' => (int)$u['id'], 'ts' => time(), 'next' => $next, 'fails' => 0]; redirect('/dang-nhap/2fa'); }
  session_regenerate_id(true); $_SESSION['uid'] = (int)$u['id']; unset($_SESSION['next']); redirect($next);
});
route('POST', '#^/dang-xuat$#', function () { $_SESSION = []; session_destroy(); redirect('/'); });

// ---------- Kiểm duyệt (admin + cộng tác viên) ----------
function admin_only(): void { if (!is_admin()) not_found(); }
function mod_cats(): ?array {
  $u = me(); if (is_admin() || ($u['role'] ?? '') !== 'collab') return null;
  $c = q('SELECT category_id FROM mod_categories WHERE user_id=?', [$u['id']])->fetchAll(PDO::FETCH_COLUMN);
  return $c ? array_map('intval', $c) : null;
}
route('GET', '#^/admin$#', function () {
  mod_only(); $mc = mod_cats(); $cf = $mc ? ' AND q.category_id IN ('.implode(',', $mc).')' : ''; $reports = [];
  foreach (q("SELECT r.target_type,r.target_id,COUNT(*) n,MIN(r.created_at) first_at,GROUP_CONCAT(DISTINCT r.reason SEPARATOR ' | ') reasons,
      IF(r.target_type='question',r.target_id,(SELECT question_id FROM answers WHERE id=r.target_id)) qid,
      IF(r.target_type='question',(SELECT title FROM questions WHERE id=r.target_id),(SELECT LEFT(body,120) FROM answers WHERE id=r.target_id)) preview
      FROM reports r WHERE r.resolved=0 GROUP BY r.target_type,r.target_id ORDER BY n DESC,first_at LIMIT 60")->fetchAll() as $x) {
    if ($mc && !in_array((int)q('SELECT category_id FROM questions WHERE id=?', [$x['qid']])->fetchColumn(), $mc, true)) continue;
    $reports[] = $x;
  }
  $pending = q("SELECT q.id,q.title,q.slug,u.username FROM questions q JOIN users u ON u.id=q.user_id WHERE q.status='pending' $cf ORDER BY q.id DESC LIMIT 50")->fetchAll();
  $pans = q("SELECT a.id,a.body,u.username,q.id qid FROM answers a JOIN questions q ON q.id=a.question_id JOIN users u ON u.id=a.user_id WHERE a.status='pending' $cf ORDER BY a.id DESC LIMIT 50")->fetchAll();
  $prov = []; $log = []; $jobs = [];
  if (is_admin()) {
    foreach (ai_all_providers() as $p) {
      $cd = q('SELECT until_at,reason FROM ai_cooldown WHERE provider=? AND until_at>NOW()', [$p['name']])->fetch();
      $n = (int)q('SELECT COUNT(*) FROM ai_log WHERE provider=? AND ok=1 AND created_at>=CURDATE()', [$p['name']])->fetchColumn();
      $prov[] = ['p' => $p, 'cd' => $cd, 'n' => $n];
    }
    $log = q('SELECT * FROM ai_log ORDER BY id DESC LIMIT 15')->fetchAll(); $jobs = q('SELECT status,COUNT(*) n FROM jobs GROUP BY status')->fetchAll(PDO::FETCH_KEY_PAIR);
  }
  render('admin', compact('reports', 'pending', 'pans', 'prov', 'log', 'jobs'), 'Kiểm duyệt', '', ['noindex' => true]);
});
route('POST', '#^/admin/act$#', function () {
  mod_only(); $act = (string)($_POST['act'] ?? ''); if (in_array($act, ['reset_ai', 'retry_jobs'], true)) admin_only();
  $id = (int)($_POST['id'] ?? 0); $tt = ($_POST['ttype'] ?? '') === 'answer' ? 'answer' : 'question'; $tid = (int)($_POST['tid'] ?? 0);
  audit('mod:'.$act, "$tt#$tid/$id");
  switch ($act) {
    case 'hide_q': hide_question($id); break;
    case 'pub_q': publish_question($id); break;
    case 'hide_a': hide_answer($id); break;
    case 'pub_a': publish_answer($id); break;
    case 'hide_c': q("UPDATE comments SET status='hidden' WHERE id=?", [$id]); break;
    case 'resolve_t': q('UPDATE reports SET resolved=1 WHERE target_type=? AND target_id=?', [$tt, $tid]); break;
    case 'hide_t': $tt === 'question' ? hide_question($tid) : hide_answer($tid); q('UPDATE reports SET resolved=1 WHERE target_type=? AND target_id=?', [$tt, $tid]); break;
    case 'reset_ai': q('DELETE FROM ai_cooldown WHERE provider=?', [(string)($_POST['provider'] ?? '')]); break;
    case 'retry_jobs': q("UPDATE jobs SET status='pending',tries=0 WHERE status='failed'"); break;
  }
  if (in_array($act, ['hide_t', 'resolve_t'], true) && (me()['role'] ?? '') === 'collab') earn((int)me()['id'], 'modwork', $tid * 2 + ($tt === 'answer' ? 1 : 0));
  cache_clear(); flash('Đã thực hiện.', 'ok'); redirect(safe_path($_POST['back'] ?? '/admin'));
});

foreach (['routes_points', 'routes_account', 'routes_content', 'routes_ctv', 'routes_chat', 'routes_pay', 'routes_admin2', 'routes_admin3', 'routes_ops', 'routes_user2'] as $__f) require ROOT.'/app/'.$__f.'.php';
not_found();
