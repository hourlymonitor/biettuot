<?php
// Sao chép file này thành config.local.php rồi điền thông tin thật. KHÔNG chia sẻ file config.local.php.
// AI (Claude, OpenAI, Gemini, Groq, Puter...) được thêm/sửa tại Admin > AI, không cần khai báo ở đây.
return [
  'site_name' => 'Biết Tuốt',
  'base_url'  => 'https://test.biettuot.xyz',   // đổi thành https://biettuot.xyz khi chạy chính thức
  'noindex'   => true,                          // true = chặn Google khi đang thử nghiệm; chạy thật thì đổi false
  'db' => ['host' => 'localhost', 'name' => '', 'user' => '', 'pass' => ''],

  'setup_key' => '',   // chuỗi ngẫu nhiên dài: dùng để chạy /install.php (tạo/nâng cấp CSDL). Xóa file install.php hoặc khóa này sau khi xong
  'app_key'   => '',   // chuỗi bí mật cố định để mã hóa API key lưu trong CSDL (đặt một lần, đừng đổi)
  'cron_key'  => '',   // chuỗi ngẫu nhiên dài; dùng cho cron: https://tenmien/cron?key=...
  'admin_email' => '', // nhận cảnh báo hệ thống qua email

  'limits' => ['questions_per_day' => 5, 'answers_per_day' => 20, 'ai_per_user_day' => 10, 'ai_global_day' => 300],
  'turnstile' => ['site' => '', 'secret' => ''],   // Cloudflare Turnstile (miễn phí); để trống = tắt
  'mail' => ['from' => 'no-reply@biettuot.xyz', 'from_name' => 'Biết Tuốt',
    'smtp' => ['host' => '', 'port' => 465, 'user' => '', 'pass' => '', 'secure' => 'ssl']],   // host trống = dùng mail() của PHP

  // Các mục dưới đây có giá trị mặc định trong app/points.php; chỉ khai báo khi muốn ghi đè.
  'premium' => ['multiplier' => 1.5, 'ai_per_user_day' => 40, 'chat_per_day' => 150, 'caps_multiplier' => 2, 'redeem_max_per_day' => 4,
    'plans' => ['month' => ['name' => 'Gói tháng', 'days' => 30, 'price' => 49000], 'year' => ['name' => 'Gói năm', 'days' => 365, 'price' => 490000]]],   // giá chỉ là ví dụ
  'ctv' => ['pool_pct' => 0.2, 'w_xp' => 1.0, 'w_article' => 10.0, 'w_view' => 0.05, 'publish_directly' => true],
  'chat' => ['guest_per_day' => 5, 'user_per_day' => 30],
  'redeem' => ['min_age_days' => 7, 'min_contrib' => 3, 'max_per_day' => 2, 'budget_vnd_month' => 500000, 'require_verified' => true],
];
