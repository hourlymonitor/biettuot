<?php
// ---------- Thanh toán Premium: trang QR, webhook SePay/Casso, quản trị thanh toán & mã giảm giá ----------
route('GET', '#^/thanh-toan/([A-Z0-9]{8,20})$#', function ($code) {
  $u = require_login(); $o = q('SELECT * FROM payment_orders WHERE code=? AND user_id=?', [$code, $u['id']])->fetch(); if (!$o) not_found();
  if ($o['status'] === 'pending' && strtotime($o['expires_at']) < time()) { q("UPDATE payment_orders SET status='expired' WHERE id=?", [$o['id']]); $o['status'] = 'expired'; }
  render('pay_order', ['o' => $o, 'qr' => pay_enabled() ? pay_qr_url($o) : '', 'c' => pay_cfg(), 'plan' => premium_plans()[$o['plan']] ?? ['name' => $o['plan']]], 'Thanh toán Premium - '.cfg('site_name'), '', ['noindex' => true]);
});
route('GET', '#^/api/thanh-toan$#', function () {
  header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); $u = me();
  $st = $u ? q('SELECT status FROM payment_orders WHERE code=? AND user_id=?', [(string)($_GET['code'] ?? ''), $u['id']])->fetchColumn() : false;
  if ($st === 'pending') { /* hết hạn được xử lý khi mở trang */ }
  echo json_encode(['status' => $st ?: 'none']);
});
route('POST', '#^/thanh-toan/huy$#', function () {
  $u = require_login(); q("UPDATE payment_orders SET status='cancelled' WHERE code=? AND user_id=? AND status IN ('pending','expired')", [(string)($_POST['code'] ?? ''), $u['id']]);
  flash('Đã hủy đơn thanh toán.', 'ok'); redirect('/goi-thanh-vien');
});
// Webhook nhận biến động số dư. SePay: header "Authorization: Apikey <khóa>". Casso (webhook thủ công): header "secure-token".
route('POST', '#^/webhook/thanh-toan$#', function () {
  header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
  $prov = (string)setting('pay_provider', 'manual'); $secret = secret_dec((string)setting('pay_secret', ''));
  if (!feature('pay_auto') || !in_array($prov, ['sepay', 'casso'], true) || $secret === '') { http_response_code(503); echo '{"success":false,"message":"not configured"}'; return; }
  $hdr = function (string $n): string {
    $k = 'HTTP_'.strtoupper(str_replace('-', '_', $n)); if (!empty($_SERVER[$k])) return (string)$_SERVER[$k];
    if ($n === 'Authorization' && !empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) return (string)$_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    if (function_exists('getallheaders')) foreach (getallheaders() as $a => $b) if (strcasecmp($a, $n) === 0) return (string)$b;
    return '';
  };
  if ($prov === 'sepay') { $h = trim($hdr('Authorization')); $ok = $h !== '' && (hash_equals('Apikey '.$secret, $h) || hash_equals('Bearer Apikey '.$secret, $h)); }
  else $ok = hash_equals($secret, trim($hdr('secure-token')));
  if (!$ok) { http_response_code(401); echo '{"success":false,"message":"unauthorized"}'; return; }
  $body = (string)file_get_contents('php://input'); $j = json_decode($body, true); if (!is_array($j)) $j = $_POST; $n = 0;
  try {
    if ($prov === 'sepay') {
      if (($j['transferType'] ?? '') === 'in') {
        $tx = (string)($j['id'] ?? ($j['referenceCode'] ?? ''));
        if ($tx !== '') { pay_handle_tx('sepay', $tx, (int)($j['transferAmount'] ?? 0), trim(($j['content'] ?? '').' '.($j['code'] ?? '').' '.($j['description'] ?? '')), $body); $n++; }
      }
    } else {
      $items = $j['data'] ?? []; if (isset($items['amount']) || isset($items['id'])) $items = [$items];
      foreach ((array)$items as $it) {
        if (!is_array($it)) continue; $amt = (int)($it['amount'] ?? 0); $tx = (string)($it['id'] ?? ($it['tid'] ?? '')); if ($amt <= 0 || $tx === '') continue;
        pay_handle_tx('casso', $tx, $amt, (string)($it['description'] ?? ''), json_encode($it, JSON_UNESCAPED_UNICODE)); $n++;
      }
    }
  } catch (Throwable $e) { app_log('webhook thanh toán: '.$e->getMessage()); http_response_code(500); echo '{"success":false}'; return; }
  echo json_encode(['success' => true, 'error' => 0, 'processed' => $n]);
});

// ---------- Quản trị ----------
route('GET', '#^/admin/thanh-toan$#', function () {
  admin_only(); $ok = true; try { q('SELECT 1 FROM payment_orders LIMIT 1'); } catch (Throwable $e) { $ok = false; }
  $d = ['cfg' => pay_cfg(), 'hasSecret' => setting('pay_secret', '') !== '', 'dbOk' => $ok, 'orders' => [], 'txs' => [], 'coupons' => [], 'stats' => ['sum' => 0, 'n' => 0, 'pending' => 0], 'webhook' => url('/webhook/thanh-toan'), 'plans' => premium_plans()];
  if ($ok) {
    $d['orders'] = q('SELECT o.*,u.username FROM payment_orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 50')->fetchAll();
    $d['txs'] = q('SELECT * FROM payment_tx ORDER BY id DESC LIMIT 30')->fetchAll(); $d['coupons'] = q('SELECT * FROM coupons ORDER BY id DESC LIMIT 30')->fetchAll();
    $d['stats'] = ['sum' => (int)q("SELECT COALESCE(SUM(amount),0) FROM payment_orders WHERE status='paid' AND paid_at>=DATE_FORMAT(NOW(),'%Y-%m-01')")->fetchColumn(),
      'n' => (int)q("SELECT COUNT(*) FROM payment_orders WHERE status='paid' AND paid_at>=DATE_FORMAT(NOW(),'%Y-%m-01')")->fetchColumn(), 'pending' => (int)q("SELECT COUNT(*) FROM payment_orders WHERE status='pending' AND expires_at>NOW()")->fetchColumn()];
  }
  render('admin_pay', $d, 'Thanh toán - '.cfg('site_name'), '', ['noindex' => true]);
});
route('POST', '#^/admin/thanh-toan$#', function () {
  admin_only(); $act = (string)($_POST['act'] ?? ''); $id = (int)($_POST['id'] ?? 0); audit('pay:'.$act, '#'.$id);
  $txt = fn(string $k, int $n = 120) => mb_substr(trim((string)($_POST[$k] ?? '')), 0, $n);
  switch ($act) {
    case 'save_cfg':
      $bank = $txt('bank', 30); $acc = $txt('acc', 19); $tpl = $txt('tpl', 30) ?: 'compact2'; $prov = in_array($_POST['provider'] ?? '', ['manual', 'sepay', 'casso'], true) ? $_POST['provider'] : 'manual'; $exp = max(10, min(1440, (int)($_POST['expiry'] ?? 60)));
      if (!preg_match('/^[A-Za-z0-9]{2,30}$/', $bank) || !preg_match('/^[A-Za-z0-9]{3,19}$/', $acc) || !preg_match('/^[A-Za-z0-9_]{3,30}$/', $tpl)) { flash('Mã ngân hàng (ví dụ MB, VCB, ACB), số tài khoản (3-19 ký tự chữ/số) hoặc template chưa hợp lệ.', 'err'); break; }
      set_setting('pay_bank', $bank); set_setting('pay_account_no', $acc); set_setting('pay_account_name', $txt('name', 60)); set_setting('pay_template', $tpl); set_setting('pay_provider', $prov); set_setting('pay_expiry_min', (string)$exp);
      if ($txt('secret', 200) !== '') set_setting('pay_secret', secret_enc($txt('secret', 200)));
      flash('Đã lưu cấu hình thanh toán. Hãy bật "Thanh toán Premium tự động" ở Admin → Tính năng nếu chưa bật.', 'ok'); break;
    case 'mark_paid':
      $o = q('SELECT * FROM payment_orders WHERE id=?', [$id])->fetch();
      if ($o && pay_mark_paid((int)$o['id'], 'manual', 'admin-'.(int)me()['id'].'-'.time())) flash('Đã xác nhận thanh toán và kích hoạt Premium.', 'ok'); else flash('Không thể xác nhận (đơn đã thanh toán hoặc đã hủy).', 'err'); break;
    case 'cancel': q("UPDATE payment_orders SET status='cancelled' WHERE id=? AND status IN ('pending','expired')", [$id]); break;
    case 'coupon_add':
      $code = strtoupper($txt('code', 30)); $kind = ($_POST['kind'] ?? '') === 'fixed' ? 'fixed' : 'percent'; $val = (int)($_POST['value'] ?? 0); $plan = array_key_exists($_POST['plan'] ?? '', premium_plans()) ? $_POST['plan'] : '';
      $ex = $txt('expires', 10); $ex = ($ex !== '' && strtotime($ex)) ? $ex.' 23:59:59' : null;
      if (!preg_match('/^[A-Z0-9_-]{3,30}$/', $code) || ($kind === 'percent' && ($val < 1 || $val > 100)) || ($kind === 'fixed' && $val < 1000)) { flash('Mã 3-30 ký tự (A-Z, 0-9, -, _); phần trăm 1-100 hoặc số tiền ≥ 1.000đ.', 'err'); break; }
      if (!q('INSERT IGNORE INTO coupons(code,kind,value,max_uses,expires_at,plan) VALUES(?,?,?,?,?,?)', [$code, $kind, $val, max(0, (int)($_POST['max_uses'] ?? 0)), $ex, $plan])->rowCount()) flash('Mã đã tồn tại.', 'err'); break;
    case 'coupon_toggle': q('UPDATE coupons SET active=1-active WHERE id=?', [$id]); break;
  }
  redirect('/admin/thanh-toan');
});
