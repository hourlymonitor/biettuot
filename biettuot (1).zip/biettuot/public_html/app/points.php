<?php
// Hệ thống điểm: sổ cái, cấp bậc, điểm danh, thử thách, chia sẻ doanh thu. Mặc định bên dưới có thể ghi đè trong config.local.php.
function pdefaults(): array {
  static $d;
  return $d ??= [
    'points' => [
      'vnd_per_point' => 25,   // chi phí thật của 1 điểm (đồng)
      'earn' => ['signup' => 20, 'checkin' => 2, 'streak' => 10, 'question' => 1, 'answer' => 2, 'upvote' => 1, 'best' => 20, 'topvote' => 10, 'referral' => 30, 'qotd' => 3, 'quiz' => 2, 'modwork' => 1, 'article' => 20],
      'caps_per_day' => ['question' => 3, 'answer' => 10, 'upvote' => 30, 'referral' => 3, 'qotd' => 2, 'quiz' => 1, 'modwork' => 20, 'article' => 3],
      'hold_days' => ['signup' => 3, 'question' => 3, 'answer' => 3, 'upvote' => 7, 'best' => 7, 'topvote' => 7, 'challenge' => 3, 'referral' => 7, 'qotd' => 3, 'article' => 7],
      'top_vote_threshold' => 5, 'min_voter_age_days' => 3, 'collab_multiplier' => 1.2,
      'birthday' => ['bonus' => 30, 'premium_bonus' => 100],
      'tiers' => [['Thành viên mới', 0, 1.0], ['Đồng', 100, 1.0], ['Bạc', 500, 1.1], ['Vàng', 2000, 1.2], ['Kim cương', 5000, 1.3]],
    ],
    'redeem' => ['min_age_days' => 7, 'min_contrib' => 3, 'max_per_day' => 2, 'budget_vnd_month' => 500000, 'require_verified' => true],
    // Chương trình cộng tác viên: quỹ chia sẻ = doanh thu x pool_pct; điểm đóng góp = w_xp x điểm đóng góp trong tháng + w_article x số bài đăng + w_view x lượt xem bài
    'ctv' => ['pool_pct' => 0.2, 'w_xp' => 1.0, 'w_article' => 10.0, 'w_view' => 0.05, 'publish_directly' => true],
    'limits' => ['questions_per_day' => 5, 'answers_per_day' => 20, 'ai_per_user_day' => 10, 'ai_global_day' => 300, 'comments_per_day' => 30],
    'premium' => ['multiplier' => 1.5, 'ai_per_user_day' => 40, 'chat_per_day' => 150, 'caps_multiplier' => 2, 'redeem_max_per_day' => 4,
      'plans' => ['month' => ['name' => 'Gói tháng', 'days' => 30, 'price' => 49000], 'year' => ['name' => 'Gói năm', 'days' => 365, 'price' => 490000]]],
    'chat' => ['guest_per_day' => 5, 'user_per_day' => 30],
    'puter' => ['enabled' => true, 'models' => ['fast' => '', 'smart' => '', 'deep' => '']],
    'moderation' => ['ai' => true],
    'require_verified' => false,   // bật true khi email đã gửi ổn định; đổi quà luôn yêu cầu xác minh (redeem.require_verified)
    'mail' => ['from' => 'no-reply@'.(parse_url((string)cfg('base_url'), PHP_URL_HOST) ?: 'localhost'), 'from_name' => 'Biết Tuốt', 'smtp' => ['host' => '', 'port' => 465, 'user' => '', 'pass' => '', 'secure' => 'ssl']],
    'push' => ['enabled' => false], 'turnstile' => ['site' => '', 'secret' => ''], 'admin_email' => '', 'cron_key' => '',
  ];
}
function pc(string $path) {
  $v = pdefaults();
  foreach (explode('.', $path) as $k) { if (!is_array($v) || !array_key_exists($k, $v)) { $v = null; break; } $v = $v[$k]; }
  return cfg($path, $v);
}
function tiers(): array { $o = []; foreach ((array)pc('points.tiers') as $i => $t) $o[] = ['name' => $t[0], 'min' => (int)$t[1], 'mult' => (float)$t[2], 'idx' => $i]; return $o; }
function tier_of(int $xp): array { $cur = null; foreach (tiers() as $t) if ($xp >= $t['min']) $cur = $t; return $cur; }
function next_tier(int $xp): ?array { foreach (tiers() as $t) if ($xp < $t['min']) return $t; return null; }
function tier_badge(array $row): string {
  if (!isset($row['xp'])) return '';
  if (($row['role'] ?? '') === 'admin') return '<span class="badge adm">Quản trị</span>';
  $t = tier_of((int)$row['xp']);
  return (!empty($row['expert_title']) ? '<span class="badge exp">✔ '.e($row['expert_title']).'</span>' : '').(($row['role'] ?? '') === 'collab' ? '<span class="badge col">CTV</span>' : '').(is_premium($row) ? '<span class="badge prem">💎 Premium</span>' : '').'<span class="badge t'.$t['idx'].'">'.e($t['name']).'</span>';
}
function kind_label(string $k): string {
  return ['signup' => 'Thưởng đăng ký', 'checkin' => 'Điểm danh hằng ngày', 'streak' => 'Thưởng chuỗi 7 ngày', 'question' => 'Đặt câu hỏi', 'answer' => 'Đăng câu trả lời',
    'upvote' => 'Được bình chọn hữu ích', 'best' => 'Câu trả lời tốt nhất', 'topvote' => 'Câu trả lời nhiều bình chọn', 'challenge' => 'Thử thách', 'redeem' => 'Đổi quà',
    'refund' => 'Hoàn điểm', 'referral' => 'Mời bạn bè', 'qotd' => 'Trả lời câu hỏi của ngày', 'quiz' => 'Đố vui', 'modwork' => 'Xử lý báo cáo', 'birthday' => 'Quà sinh nhật', 'holiday' => 'Quà lễ tết', 'article' => 'Viết bài', 'share_buy' => 'Mua phần chia sẻ doanh thu', 'revshare' => 'Chia sẻ doanh thu', 'admin' => 'Điều chỉnh'][$k] ?? $k;
}
function apply_balance(int $uid, int $delta, bool $earned): void {
  q('UPDATE users SET points=points+?, xp=xp+? WHERE id=?', [$delta, ($earned && $delta > 0) ? $delta : 0, $uid]);
}
// Ghi 1 dòng vào sổ cái. Khóa UNIQUE chặn cộng trùng. hold>0 = điểm "đang giữ" vài ngày rồi mới thành điểm khả dụng.
function pts(int $uid, int $delta, string $kind, int $ref = 0, int $src = 0, string $note = '', ?int $hold = null, bool $earned = true): bool {
  if ($delta === 0) return false;
  $hold ??= (int)pc("points.hold_days.$kind"); $pending = $hold > 0;
  try {
    q('INSERT INTO point_ledger(user_id,delta,kind,ref_id,src_user_id,status,earned,available_at,note) VALUES(?,?,?,?,?,?,?,DATE_ADD(NOW(),INTERVAL ? DAY),?)',
      [$uid, $delta, $kind, $ref, $src, $pending ? 'pending' : 'confirmed', (int)$earned, $hold, mb_substr($note, 0, 190)]);
  } catch (PDOException $e) { if ((string)$e->getCode() === '23000') return false; throw $e; }
  if (!$pending) apply_balance($uid, $delta, $earned);
  return true;
}
// Cộng điểm theo luật cấu hình, có nhân hệ số cấp bậc/CTV và giới hạn theo ngày.
function earn(int $uid, string $kind, int $ref = 0, int $src = 0): bool {
  if (!feature('points')) return false;
  $fmap = ['checkin' => 'checkin', 'streak' => 'checkin', 'referral' => 'referral', 'qotd' => 'qotd', 'quiz' => 'quiz', 'article' => 'articles'];
  if (isset($fmap[$kind]) && !feature($fmap[$kind])) return false;
  $base = (int)pc("points.earn.$kind"); if ($base <= 0) return false;
  $u = q('SELECT role,xp,banned,premium_until FROM users WHERE id=?', [$uid])->fetch(); if (!$u || $u['banned']) return false;
  $prem = is_premium($u); $cap = pc("points.caps_per_day.$kind");
  if ($cap !== null) {
    $cap = (int)$cap * ($prem ? max(1, (int)pc('premium.caps_multiplier')) : 1);
    if ((int)q("SELECT COUNT(*) FROM point_ledger WHERE user_id=? AND kind=? AND status<>'reversed' AND created_at>=CURDATE()", [$uid, $kind])->fetchColumn() >= $cap) return false;
  }
  $mult = tier_of((int)$u['xp'])['mult'] * ($u['role'] === 'collab' ? (float)pc('points.collab_multiplier') : 1.0) * ($prem ? (float)pc('premium.multiplier') : 1.0);
  return pts($uid, max(1, (int)round($base * $mult)), $kind, $ref, $src);
}
function pts_reverse(string $kind, int $ref, ?int $uid = null, ?int $src = null): void {
  $sql = "SELECT * FROM point_ledger WHERE kind=? AND ref_id=? AND status<>'reversed'"; $p = [$kind, $ref];
  if ($uid !== null) { $sql .= ' AND user_id=?'; $p[] = $uid; }
  if ($src !== null) { $sql .= ' AND src_user_id=?'; $p[] = $src; }
  foreach (q($sql, $p)->fetchAll() as $r) {
    q("UPDATE point_ledger SET status='reversed' WHERE id=?", [$r['id']]);
    if ($r['status'] === 'confirmed') q('UPDATE users SET points=points-?, xp=xp-? WHERE id=?', [$r['delta'], ($r['earned'] && $r['delta'] > 0) ? $r['delta'] : 0, $r['user_id']]);
  }
}
function settle_due(?int $uid = null): void {
  $w = $uid ? 'AND user_id='.(int)$uid : '';
  $rows = q("SELECT id,user_id,delta,earned FROM point_ledger WHERE status='pending' AND available_at<=NOW() AND user_id NOT IN (SELECT id FROM users WHERE banned=1) $w LIMIT 500")->fetchAll();
  foreach ($rows as $r)
    if (q("UPDATE point_ledger SET status='confirmed' WHERE id=? AND status='pending'", [$r['id']])->rowCount()) apply_balance((int)$r['user_id'], (int)$r['delta'], (bool)$r['earned']);
}
function daily_checkin(array $u): void {
  if (!feature('points') || !feature('checkin')) return;
  if (($u['last_checkin'] ?? null) === date('Y-m-d')) return;
  $n = q('UPDATE users SET streak=IF(last_checkin=DATE_SUB(CURDATE(),INTERVAL 1 DAY),streak+1,1), last_checkin=CURDATE() WHERE id=? AND (last_checkin IS NULL OR last_checkin<CURDATE())', [$u['id']])->rowCount();
  if (!$n) return;
  $s = (int)q('SELECT streak FROM users WHERE id=?', [$u['id']])->fetchColumn(); $day = (int)date('Ymd');
  earn((int)$u['id'], 'checkin', $day);
  if ($s % 7 === 0) earn((int)$u['id'], 'streak', $day);
  if (feature('birthday_holiday')) { try { birthday_bonus($u); holiday_bonus($u); } catch (Throwable $e) { app_log('quà sinh nhật/lễ: '.$e->getMessage()); } }
  flash("Điểm danh thành công - chuỗi $s ngày liên tiếp.", 'ok');
}
function birthday_bonus(array $u): void {
  if (empty($u['birthday']) || date('m-d', strtotime($u['birthday'])) !== date('m-d') || time() - strtotime($u['created_at']) < 7 * 86400) return;
  $amt = (int)pc(is_premium($u) ? 'points.birthday.premium_bonus' : 'points.birthday.bonus');
  if ($amt > 0 && pts((int)$u['id'], $amt, 'birthday', (int)date('Y'), 0, 'Quà sinh nhật', 0, false)) {
    notify((int)$u['id'], 'gift', "🎂 Chúc mừng sinh nhật! Biết Tuốt tặng bạn $amt điểm.", '/vi'); flash("🎂 Chúc mừng sinh nhật! Bạn nhận $amt điểm.", 'ok');
  }
}
function holiday_bonus(array $u): void {
  if (time() - strtotime($u['created_at']) < 3 * 86400) return;
  $evs = q("SELECT * FROM holiday_events WHERE active=1 AND ((recurring=1 AND DATE_FORMAT(CURDATE(),'%m-%d') BETWEEN DATE_FORMAT(start_date,'%m-%d') AND DATE_FORMAT(end_date,'%m-%d'))
            OR (recurring=0 AND CURDATE() BETWEEN start_date AND end_date))")->fetchAll();
  foreach ($evs as $ev) {
    $amt = (int)$ev['bonus_points'] + (is_premium($u) ? (int)$ev['premium_bonus'] : 0);
    if ($amt > 0 && pts((int)$u['id'], $amt, 'holiday', (int)$ev['id'], (int)date('Y'), 'Quà dịp '.$ev['name'], 0, false)) {
      notify((int)$u['id'], 'gift', '🎁 Quà dịp '.$ev['name'].': +'.$amt.' điểm.', '/vi'); flash('🎁 Quà dịp '.$ev['name'].': +'.$amt.' điểm!', 'ok');
    }
  }
}
function ch_period(string $p): array {
  return match ($p) { 'daily' => [date('Y-m-d 00:00:00'), (int)date('Ymd')], 'weekly' => [date('Y-m-d 00:00:00', strtotime('monday this week')), (int)date('oW')], default => ['2000-01-01 00:00:00', 0] };
}
function ch_progress(array $c, int $uid): int {
  [$s] = ch_period($c['period']);
  $sql = match ($c['metric']) {
    'answers' => "SELECT COUNT(*) FROM answers WHERE user_id=? AND is_ai=0 AND status='published' AND created_at>=?",
    'questions' => "SELECT COUNT(*) FROM questions WHERE user_id=? AND status='published' AND created_at>=?",
    'upvotes' => 'SELECT COUNT(*) FROM votes v JOIN answers a ON a.id=v.answer_id WHERE a.user_id=? AND v.value=1 AND v.created_at>=?',
    'best' => "SELECT COUNT(*) FROM point_ledger WHERE user_id=? AND kind='best' AND status<>'reversed' AND created_at>=?",
    default => "SELECT COUNT(*) FROM point_ledger WHERE user_id=? AND kind='checkin' AND created_at>=?",
  };
  return (int)q($sql, [$uid, $s])->fetchColumn();
}
// Chia sẻ doanh thu cho cộng tác viên: quỹ = doanh thu x pool_pct / vnd_per_point; chia theo điểm đóng góp trong tháng.
function revshare_calc(string $ym, int $rev): array {
  $pool = (int)floor($rev * (float)pc('ctv.pool_pct') / max(1, (int)pc('points.vnd_per_point'))); $start = "$ym-01 00:00:00"; $rows = []; $total = 0.0;
  foreach (q("SELECT id,username FROM users WHERE role='collab' AND banned=0")->fetchAll() as $u) {
    $x = (int)q("SELECT COALESCE(SUM(delta),0) FROM point_ledger WHERE user_id=? AND earned=1 AND delta>0 AND status='confirmed' AND created_at>=? AND created_at<DATE_ADD(?,INTERVAL 1 MONTH)", [$u['id'], $start, $start])->fetchColumn();
    $art = (int)q("SELECT COUNT(*) FROM articles WHERE author_id=? AND status='published' AND published_at>=? AND published_at<DATE_ADD(?,INTERVAL 1 MONTH)", [$u['id'], $start, $start])->fetchColumn();
    $views = (int)q('SELECT COALESCE(SUM(s.views),0) FROM article_stats s JOIN articles a ON a.id=s.article_id WHERE a.author_id=? AND s.ym=?', [$u['id'], $ym])->fetchColumn();
    $score = $x * (float)pc('ctv.w_xp') + $art * (float)pc('ctv.w_article') + $views * (float)pc('ctv.w_view'); $total += $score;
    $rows[] = ['uid' => (int)$u['id'], 'name' => $u['username'], 'x' => $x, 'art' => $art, 'views' => $views, 'score' => $score, 'pts' => 0];
  }
  foreach ($rows as &$r) $r['pts'] = $total > 0 ? (int)floor($pool * $r['score'] / $total) : 0; unset($r);
  $rows = array_values(array_filter($rows, fn($r) => $r['pts'] > 0)); usort($rows, fn($a, $b) => $b['pts'] <=> $a['pts']);
  return ['pool' => $pool, 'total' => $total, 'rows' => $rows];
}
function mod_only(): void { if (!is_admin() && (me()['role'] ?? '') !== 'collab') not_found(); }
function admin_nav(): string {
  $l = '<a href="/admin">Kiểm duyệt</a>';
  if (is_admin()) {
    $l .= '<a href="/admin/tinh-nang">🎛 Tính năng</a><a href="/admin/ai">🤖 AI</a><a href="/admin/thanh-toan">💳 Thanh toán</a><a href="/admin/suc-khoe">🩺 Sức khỏe</a><a href="/admin/chi-phi-ai">💸 Chi phí AI</a><a href="/admin/ban-tin">✉️ Bản tin</a><a href="/admin/dieu-khoan">📜 Điều khoản</a>';
    foreach (['qua' => 'Đơn đổi quà', 'thuthach' => 'Thử thách', 'user' => 'Thành viên', 'doanhthu' => 'Chia doanh thu CTV'] as $k => $v) $l .= '<a href="/admin/diem?t='.$k.'">'.$v.'</a>';
    foreach (['thongke' => 'Thống kê', 'ctv' => 'Cộng tác viên', 'noidung' => 'Nội dung', 'chuyenmuc' => 'Chuyên mục', 'uudai' => 'Ưu đãi & Premium', 'gianlan' => 'Gian lận', 'doisoat' => 'Đối soát', 'quangcao' => 'Quảng cáo', 'nhatky' => 'Hệ thống'] as $k => $v) $l .= '<a href="/admin/he-thong?t='.$k.'">'.$v.'</a>';
  }
  return '<nav class="chips">'.$l.'</nav>';
}
