<?php
// Sức khỏe hệ thống, tự kiểm tra luồng chính (trong giao dịch rồi hoàn tác), sao lưu tự động.
function backup_dir(): string { $d = ROOT.'/app/backups'; if (!is_dir($d)) @mkdir($d, 0755, true); return $d; }
function backup_list(): array {
  $o = []; foreach (glob(backup_dir().'/*.sql.gz') ?: [] as $f) $o[] = ['name' => basename($f), 'size' => (int)filesize($f), 'time' => (int)filemtime($f)];
  usort($o, fn($a, $b) => $b['time'] <=> $a['time']); return $o;
}
function backup_run(): array {
  if (!function_exists('gzopen')) return [false, 'Máy chủ thiếu thư viện zlib (gzopen).', ''];
  $f = backup_dir().'/'.date('Ymd-His').'.sql.gz'; $gz = @gzopen($f, 'wb6'); if (!$gz) return [false, 'Không ghi được thư mục app/backups.', ''];
  try {
    gzwrite($gz, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n");
    foreach (db()->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN) as $t) {
      gzwrite($gz, "\nDROP TABLE IF EXISTS `$t`;\n".db()->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1].";\n"); $off = 0;
      do { $rows = db()->query("SELECT * FROM `$t` LIMIT 500 OFFSET $off")->fetchAll(PDO::FETCH_NUM);
        foreach ($rows as $r) gzwrite($gz, "INSERT INTO `$t` VALUES (".implode(',', array_map(fn($v) => $v === null ? 'NULL' : db()->quote((string)$v), $r)).");\n");
        $off += 500; } while (count($rows) === 500);
    }
  } catch (Throwable $e) { gzclose($gz); @unlink($f); return [false, 'Lỗi khi sao lưu: '.$e->getMessage(), '']; }
  gzclose($gz); backup_rotate((int)setting('backup_keep', '7')); set_setting('backup_last', (string)time());
  return [true, 'Đã sao lưu '.round(filesize($f) / 1024).' KB', basename($f)];
}
function backup_rotate(int $keep): void { $l = backup_list(); foreach (array_slice($l, max(1, $keep)) as $b) @unlink(backup_dir().'/'.$b['name']); }
function backup_maybe(): ?string {
  if (!feature('auto_backup')) return null; if (time() - (int)setting('backup_last', '0') < 86400) return null;
  [$ok, $msg] = backup_run(); if (!$ok && (string)pc('admin_email') !== '') send_mail((string)pc('admin_email'), '[Biết Tuốt] Sao lưu tự động thất bại', $msg);
  return ($ok ? '✔ ' : '✘ ').$msg;
}
function health_checks(): array {
  $out = []; $add = function (string $g, string $label, string $st, string $note = '') use (&$out) { $out[$g][] = [$label, $st, $note]; };
  $G = '🖥 Máy chủ & PHP';
  $add($G, 'Phiên bản PHP', version_compare(PHP_VERSION, '8.0.0', '>=') ? (version_compare(PHP_VERSION, '8.1.0', '>=') ? 'ok' : 'warn') : 'err', PHP_VERSION.(version_compare(PHP_VERSION, '8.1.0', '<') ? ' (nên dùng 8.1 trở lên)' : ''));
  foreach (['curl' => 'gọi AI/thanh toán', 'mbstring' => 'xử lý tiếng Việt', 'pdo_mysql' => 'cơ sở dữ liệu', 'openssl' => 'mã hóa khóa API, thông báo đẩy', 'zlib' => 'sao lưu nén', 'json' => 'JSON', 'gd' => 'ảnh chia sẻ (OG)'] as $ext => $why)
    $add($G, "Tiện ích $ext", extension_loaded($ext) ? 'ok' : ($ext === 'gd' || $ext === 'zlib' ? 'warn' : 'err'), $why);
  $add($G, 'GD hỗ trợ phông chữ (FreeType)', function_exists('imagettftext') ? 'ok' : 'warn', function_exists('imagettftext') ? 'tạo ảnh chia sẻ được' : 'không tạo được ảnh chia sẻ riêng, dùng ảnh mặc định');
  $add($G, 'Giới hạn thời gian / bộ nhớ', 'ok', ini_get('max_execution_time').'s / '.ini_get('memory_limit'));
  $free = @disk_free_space(ROOT); if ($free !== false) $add($G, 'Dung lượng trống', $free > 200 * 1048576 ? 'ok' : 'warn', round($free / 1048576).' MB');
  $W = '📁 Thư mục & bảo mật';
  foreach (['app/cache', 'app/logs', 'app/backups'] as $d) { $p = ROOT.'/'.$d; if (!is_dir($p)) @mkdir($p, 0755, true); $t = $p.'/.w'; $okw = is_dir($p) && @file_put_contents($t, '1') !== false; @unlink($t); $add($W, "Ghi được $d", $okw ? 'ok' : 'err', $okw ? '' : 'Cấp quyền ghi (chmod 755) cho thư mục này'); }
  $add($W, 'File install.php', is_file(ROOT.'/install.php') ? 'warn' : 'ok', is_file(ROOT.'/install.php') ? 'Hãy xóa install.php sau khi cài đặt xong' : 'đã xóa');
  $add($W, 'HTTPS', !empty($_SERVER['HTTPS']) ? 'ok' : 'warn', !empty($_SERVER['HTTPS']) ? '' : 'Bật SSL và "Force HTTPS" trong hPanel');
  $add($W, 'Chế độ noindex', cfg('noindex') ? 'warn' : 'ok', cfg('noindex') ? 'Đang chặn Google (đặt noindex=false khi chạy thật)' : 'cho phép lập chỉ mục');
  $D = '🗄 Cơ sở dữ liệu';
  try { $v = (string)db()->query('SELECT VERSION()')->fetchColumn(); $add($D, 'Kết nối MySQL', 'ok', $v); } catch (Throwable $e) { $add($D, 'Kết nối MySQL', 'err', $e->getMessage()); }
  $add($D, 'Phiên bản cấu trúc', schema_current() ? 'ok' : 'err', (int)setting('schema_version', '0').' / '.SCHEMA_VERSION.(schema_current() ? '' : ' - hãy chạy install.php'));
  $C = '⏱ Cron & tác vụ nền';
  $last = (int)setting('cron_last', '0'); $age = time() - $last;
  $add($C, 'Cron chạy lần cuối', $last === 0 ? 'err' : ($age < 900 ? 'ok' : ($age < 7200 ? 'warn' : 'err')), $last ? ago(date('Y-m-d H:i:s', $last)) : 'chưa từng - hãy tạo cron gọi /cron?key=...');
  $add($C, 'cron_key đã đặt', (string)pc('cron_key') !== '' ? 'ok' : 'err', '');
  try { $pend = (int)q("SELECT COUNT(*) FROM jobs WHERE status='pending'")->fetchColumn(); $fail = (int)q("SELECT COUNT(*) FROM jobs WHERE status='failed'")->fetchColumn();
    $old = (int)q("SELECT COUNT(*) FROM jobs WHERE status='pending' AND run_at<DATE_SUB(NOW(),INTERVAL 30 MINUTE)")->fetchColumn();
    $add($C, 'Tác vụ chờ / thất bại', ($old || $fail > 5) ? 'warn' : 'ok', "$pend chờ ($old quá 30 phút) / $fail thất bại"); } catch (Throwable $e) {}
  $M = '✉️ Email';
  $smtp = !empty(pc('mail.smtp')['host']); $add($M, 'Cách gửi', 'ok', $smtp ? 'SMTP '.pc('mail.smtp')['host'] : 'mail() của PHP (nên dùng SMTP của hộp thư tên miền)');
  $mt = setting('mail_test_result', ''); if ($mt !== '') $add($M, 'Lần gửi thử gần nhất', strncmp($mt, 'ok', 2) === 0 ? 'ok' : 'warn', $mt);
  $A = '🤖 AI';
  $act = ai_providers(); $add($A, 'AI đang hoạt động', $act ? 'ok' : 'err', count($act).' AI'.($act ? '' : ' - thêm tại Admin → AI'));
  foreach (ai_all_providers() as $p) { if (empty($p['key'])) continue; $note = $p['test_at'] ? ($p['test_ok'] ? 'kiểm tra OK' : 'kiểm tra lỗi: '.$p['test_note']) : 'chưa kiểm tra'; $add($A, $p['label'].' ('.$p['model'].')', ($p['test_at'] && !$p['test_ok']) ? 'warn' : 'ok', $note); }
  $add($A, 'Ngân sách AI', feature('ai_budget') ? 'ok' : 'warn', feature('ai_budget') ? 'đang áp dụng' : 'đang tắt');
  $P = '💳 Thanh toán';
  $pc = pay_cfg(); $add($P, 'Cấu hình nhận tiền', pay_enabled() ? 'ok' : 'warn', pay_enabled() ? $pc['bank'].' · '.$pc['acc'].' · '.$pc['provider'] : 'chưa bật hoặc chưa cấu hình');
  if (in_array($pc['provider'], ['sepay', 'casso'], true)) { $add($P, 'Khóa webhook', setting('pay_secret', '') !== '' ? 'ok' : 'err', ''); try { $lt = q('SELECT MAX(created_at) FROM payment_tx')->fetchColumn(); $add($P, 'Webhook nhận lần cuối', $lt ? 'ok' : 'warn', $lt ? ago((string)$lt) : 'chưa nhận giao dịch nào'); } catch (Throwable $e) {} }
  $B = '💾 Sao lưu';
  $bl = backup_list(); $add($B, 'Sao lưu gần nhất', $bl ? ((time() - $bl[0]['time']) < 3 * 86400 ? 'ok' : 'warn') : 'warn', $bl ? ago(date('Y-m-d H:i:s', $bl[0]['time'])).' ('.round($bl[0]['size'] / 1024).' KB)' : 'chưa có bản nào');
  $add($B, 'Sao lưu tự động', feature('auto_backup') ? 'ok' : 'warn', feature('auto_backup') ? 'bật (cần cron)' : 'tắt');
  return $out;
}
// Chạy thử các luồng chính trong một giao dịch rồi HOÀN TÁC (không để lại dữ liệu). Không gọi AI/email thật.
function selftest_run(): array {
  $log = []; $bad = 0;
  $step = function (string $label, callable $fn) use (&$log, &$bad) {
    try { $r = $fn(); if ($r === false) { $log[] = "✘ $label"; $bad++; } else $log[] = "✔ $label".(is_string($r) && $r !== '' ? " - $r" : ''); }
    catch (Throwable $e) { $log[] = "✘ $label - ".get_class($e).': '.$e->getMessage(); $bad++; }
  };
  $pdo = db(); if ($pdo->inTransaction()) return ['✘ Đang có giao dịch khác, thử lại sau.'];
  $pdo->beginTransaction(); $S = []; $tag = substr(bin2hex(random_bytes(3)), 0, 6);
  try {
    $step('Tạo 2 thành viên thử', function () use (&$S, $tag) { foreach (['a', 'b'] as $k) { q('INSERT INTO users(username,email,pass_hash,email_verified,created_at) VALUES(?,?,?,1,DATE_SUB(NOW(),INTERVAL 30 DAY))', ["st_{$k}_$tag", "st_{$k}_$tag@invalid.local", password_hash('x', PASSWORD_DEFAULT)]); $S[$k] = fresh_user((int)db()->lastInsertId()); } return true; });
    if (count($S) === 2) {
      $step('Đặt câu hỏi + thẻ + theo dõi + điểm', function () use (&$S, $tag) {
        $cid = (int)q('SELECT id FROM categories WHERE active=1 ORDER BY id LIMIT 1')->fetchColumn(); if (!$cid) return false;
        q("INSERT INTO questions(user_id,category_id,title,slug,body,status) VALUES(?,?,?,?,?,'published')", [$S['a']['id'], $cid, "Câu hỏi kiểm tra tự động $tag", slugify("Câu hỏi kiểm tra tự động $tag"), 'Nội dung thử']);
        $S['q'] = q('SELECT * FROM questions WHERE id=?', [db()->lastInsertId()])->fetch(); set_tags((int)$S['q']['id'], 'kiểm tra, thử'); follow_set((int)$S['a']['id'], 'question', (int)$S['q']['id']);
        earn((int)$S['a']['id'], 'question', (int)$S['q']['id']); return feature('points') ? ((int)q("SELECT COUNT(*) FROM point_ledger WHERE user_id=? AND kind='question'", [$S['a']['id']])->fetchColumn() === 1 ? '' : false) : 'tính năng điểm đang tắt';
      });
      $step('Trả lời + thông báo + đếm câu trả lời', function () use (&$S) {
        q("INSERT INTO answers(question_id,user_id,body,status) VALUES(?,?,?,'published')", [$S['q']['id'], $S['b']['id'], 'Câu trả lời thử nghiệm tự động']); $S['aid'] = (int)db()->lastInsertId();
        after_answer($S['b'], $S['q'], $S['aid']); if ((int)q('SELECT answers_count FROM questions WHERE id=?', [$S['q']['id']])->fetchColumn() !== 1) return false;
        return feature('notifications') ? ((int)q('SELECT COUNT(*) FROM notifications WHERE user_id=?', [$S['a']['id']])->fetchColumn() >= 1 ? '' : false) : 'thông báo đang tắt';
      });
      $step('Bình chọn + thưởng + thu hồi', function () use (&$S) { q('REPLACE INTO votes(user_id,answer_id,value) VALUES(?,?,1)', [$S['a']['id'], $S['aid']]); earn((int)$S['b']['id'], 'upvote', $S['aid'], (int)$S['a']['id']); pts_reverse('upvote', $S['aid'], (int)$S['b']['id'], (int)$S['a']['id']); return true; });
      $step('Chọn câu trả lời tốt nhất + đối soát điểm đang giữ', function () use (&$S) {
        q('UPDATE answers SET is_best=1 WHERE id=?', [$S['aid']]); earn((int)$S['b']['id'], 'best', $S['aid']); q("UPDATE point_ledger SET available_at=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE user_id=?", [$S['b']['id']]);
        settle_due((int)$S['b']['id']); return feature('points') ? ((int)q('SELECT points FROM users WHERE id=?', [$S['b']['id']])->fetchColumn() > 0 ? '' : false) : 'điểm đang tắt';
      });
      $step('Bình luận', function () use (&$S) { q("INSERT INTO comments(answer_id,user_id,body) VALUES(?,?,'bình luận thử')", [$S['aid'], $S['a']['id']]); return true; });
      $step('Tìm kiếm / liên quan / nguồn cho trợ lý', function () use (&$S) { search_questions('kiểm tra tự động', 1, 5); related_questions(q('SELECT * FROM questions WHERE id=?', [$S['q']['id']])->fetch(), 3); rag_sources('kiểm tra tự động câu hỏi'); return true; });
      $step('Lưu lịch sử chat + chia sẻ', function () use (&$S) { $t = chat_save((int)$S['b']['id'], 0, 'smart', 'chung', 'Tiêu đề thử', 'xin chào', 'chào bạn'); q('UPDATE chat_threads SET share_token=? WHERE id=?', [bin2hex(random_bytes(16)), $t]); return (int)q('SELECT COUNT(*) FROM chat_messages WHERE thread_id=?', [$t])->fetchColumn() === 2 ? '' : false; });
      $step('Thanh toán Premium (đơn → webhook → kích hoạt, chống trùng)', function () use (&$S, $tag) {
        $plans = premium_plans(); $plan = (string)array_key_first($plans); if (!$plan) return false; $o = pay_create_order((int)$S['b']['id'], $plan, ''); if (is_string($o)) return $o;
        $r1 = pay_handle_tx('selftest', "tx$tag", (int)$o['amount'], 'CK '.$o['code'], '{}'); $r2 = pay_handle_tx('selftest', "tx$tag", (int)$o['amount'], 'CK '.$o['code'], '{}');
        $prem = q('SELECT premium_until FROM users WHERE id=?', [$S['b']['id']])->fetchColumn(); return ($r1 === 'đã kích hoạt' && $r2 === 'trùng' && $prem) ? '' : "kết quả: $r1 / $r2";
      });
      $step('Bản tin: tổng hợp nội dung tuần', function () { news_digest(); return true; });
      $step('Trợ lý: ngân sách AI & quy tắc lĩnh vực', function () { $st = ai_budget_state('chat'); category_rules(['ai_prompt' => 'x', 'is_sensitive' => 1]); return "trạng thái ngân sách: $st"; });
    }
    $step('Ảnh chia sẻ (OG)', function () { if (!og_available()) return 'GD/FreeType chưa sẵn sàng - dùng ảnh mặc định'; $p = og_png('Tiêu đề thử nghiệm có dấu: Hỏi đáp tiếng Việt', 'mô tả', 'Thẻ'); return ($p !== null && strncmp($p, "\x89PNG", 4) === 0) ? '' : false; });
    $step('Xác thực hai lớp (TOTP)', function () { $s = b32_encode(random_bytes(20)); return totp_verify($s, totp_code(b32_decode($s), (int)floor(time() / 30))) ? '' : false; });
    $step('Mã hóa khóa bí mật', function () { return secret_dec(secret_enc('khoa-thu-123')) === 'khoa-thu-123' ? '' : false; });
    $step('Tất cả công tắc tính năng đọc được', function () { foreach (array_keys(feature_defs()) as $k) feature($k); return count(feature_defs()).' công tắc'; });
    $step('Cấu trúc CSDL đầy đủ', function () { return schema_current() ? '' : 'phiên bản chưa khớp - chạy install.php'; });
  } finally { if ($pdo->inTransaction()) $pdo->rollBack(); }
  cache_clear(); array_unshift($log, $bad ? "⚠ Có $bad bước lỗi. (Mọi dữ liệu thử đã được hoàn tác.)" : '✅ Tất cả các bước đều qua. (Mọi dữ liệu thử đã được hoàn tác.)');
  return $log;
}
