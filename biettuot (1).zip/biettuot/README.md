# Biết Tuốt - PHP 8 + MySQL (bản V5)

## Cài đặt / nâng cấp (làm theo thứ tự)
1. **Sao lưu** database (hPanel → Databases → phpMyAdmin → Export) và thư mục web.
2. Tải toàn bộ nội dung thư mục `public_html/` lên máy chủ (ghi đè). **Giữ nguyên** `app/config.local.php`. Mới cài: sao chép `app/config.sample.php` → `app/config.local.php` và điền `db`, `base_url`.
3. Mở `app/config.local.php`, thêm hai dòng (chuỗi ngẫu nhiên dài, đặt một lần):
   `'setup_key' => '...',` và `'app_key' => '...',`
4. Mở **`https://tenmien/install.php`**, nhập `setup_key`, bấm "Chạy cài đặt". Trình này tạo bảng/cột còn thiếu, thêm chuyên mục và dữ liệu mẫu; **chạy lại nhiều lần được**. Các dòng ✘ (nếu có) là lỗi cần xử lý.
5. Xóa file `install.php` (hoặc xóa `setup_key`). Đăng ký tài khoản đầu tiên → tự là quản trị viên.
6. Vào **Admin → AI** thêm API key (xem dưới) và **Admin → Tính năng** để bật/tắt tính năng.

> Khi code mới đã tải lên nhưng CSDL chưa nâng cấp, khách sẽ thấy trang "đang nâng cấp" (tránh lỗi 500). Quản trị viên vẫn đăng nhập được và thấy cảnh báo chạy `install.php`. Không còn dùng file `.sql`.

## Quản lý AI (Admin → AI)
- Chọn nhà cung cấp (Claude, OpenAI, Gemini, Groq, DeepSeek, OpenRouter, Mistral, Together, Puter, tùy chỉnh) → dán API key → **Lưu & kiểm tra**. Hệ thống gọi thử ngay; nếu thành công, AI được bật và **tự tích hợp** vào Trợ lý chat, AI trả lời câu hỏi, kiểm duyệt, tóm tắt (có thể tắt từng mục ở Admin → Tính năng).
- Khóa API được **mã hóa** trong CSDL (khóa mã hóa lấy từ `app_key` + thông tin DB: đừng đổi `app_key`/mật khẩu DB sau khi đã lưu khóa, nếu đổi phải nhập lại khóa).
- Chiến lược: **ưu tiên theo thứ tự** hoặc **xoay vòng đều**. AI hết hạn mức/lỗi tự "nghỉ" rồi chuyển sang AI khác; có "Danh sách model", "Kiểm tra", đặt giới hạn lượt/ngày cho từng AI.
- **Puter (dự phòng)**: Puter **không có API key riêng**; hệ thống dùng **auth token của tài khoản Puter của admin**. Cách lấy: đăng nhập puter.com bằng tài khoản admin → mở puter.com/dashboard → bấm **Copy** ở mục auth token (hoặc mở Console trình duyệt khi đã đăng nhập puter.com và gõ `localStorage.getItem("puter.auth.token.v2")`). Ở Admin → AI chọn preset **Puter**, dán token vào ô "Puter auth token", **để trống ô Model** (hệ thống tự thử và chọn model dùng được), bấm "Lưu & kiểm tra". Puter chỉ được gọi **khi tất cả AI chính hết hạn mức hoặc lỗi**; người dùng chat qua tài khoản Puter này (không cần đăng nhập Puter), chi phí/hạn mức tính vào tài khoản đó. Nếu báo HTTP 401: token sai hoặc hết hạn → lấy token mới.
- AI khai báo cũ trong `config.local.php` vẫn chạy; bấm "Nhập các AI trong config vào bảng này" để chuyển sang Admin → AI.

## Bật/tắt tính năng (Admin → Tính năng)
33 công tắc: đăng ký, đặt câu hỏi, trả lời, bình luận, bình chọn, bảo trì, Trợ lý chat, AI (trả lời/kiểm duyệt/tóm tắt/viết bài/đố vui), bài viết, câu hỏi và đố vui hằng ngày, điểm, điểm danh, thử thách, đổi quà, xếp hạng, huy hiệu, giới thiệu bạn bè, quà sinh nhật/lễ Tết, cộng tác viên, Premium, theo dõi, thông báo, hồ sơ, quảng cáo, liên kết tiếp thị, PWA, thông báo đẩy... Tắt tính năng nào thì menu, trang và logic liên quan đều ẩn; quản trị viên vẫn truy cập để kiểm tra.

## Cron (khuyên dùng)
Mỗi 5 phút: `curl -s "https://tenmien/cron?key=CRON_KEY" >/dev/null` (đặt `cron_key` trong config). Xử lý tác vụ nền, email, cảnh báo.


## Mới ở bản V6
- **Cài đặt:** chạy lại `install.php` (lên phiên bản CSDL 6: thêm bảng lịch sử chat, đơn thanh toán, giao dịch webhook, mã giảm giá). Trước khi chạy, khách sẽ thấy trang "đang nâng cấp".
- **Trợ lý dựa trên kho nội dung** (tính năng `chat_rag`): với mỗi câu hỏi, trợ lý tìm câu hỏi/câu trả lời tốt nhất và bài viết liên quan trên site, đưa vào ngữ cảnh và **trích dẫn nguồn** [1], [2]. Nội dung nguồn được coi là dữ liệu (chống chèn lệnh), có thể tắt ở Admin → Tính năng.
- **Lịch sử chat lưu vào tài khoản** (`chat_history`): thành viên xem lại trên mọi thiết bị, xóa từng cuộc hoặc tất cả; khách vẫn lưu trên thiết bị. Tự xóa cuộc trò chuyện không hoạt động sau 180 ngày (cron; đổi bằng khóa cài đặt `chat_retention_days`). **Chia sẻ bằng liên kết** (`chat_share`): bấm ↗ ở lịch sử, bấm lại để thu hồi; liên kết công khai, không hiển thị tên người dùng. Hãy cập nhật Chính sách bảo mật về việc lưu hội thoại.
- **Thanh toán Premium tự động** (`pay_auto`, Admin → Thanh toán):
  1. Nhập mã ngân hàng theo VietQR (MB, VCB, ACB...), số tài khoản, tên chủ tài khoản.
  2. Chọn dịch vụ đối soát và đặt khóa bí mật: **SePay** (webhook, header `Authorization: Apikey KHÓA`), **Casso** (webhook thủ công, header `secure-token`) hoặc **Thủ công**.
  3. Trong SePay/Casso tạo webhook trỏ tới `https://tenmien/webhook/thanh-toan`, cùng khóa; SePay: Content-Type JSON và tắt "bỏ qua nếu không có mã thanh toán".
  4. Bật "Thanh toán Premium tự động" ở Admin → Tính năng.
  Thành viên chọn gói (+ mã giảm giá) → thấy mã QR và nội dung chuyển khoản dạng `BTxxxxxxxx` → khi tiền về, hệ thống tự khớp mã và kích hoạt Premium (cộng dồn thời hạn). Giao dịch trùng bị bỏ qua; chuyển thiếu tiền hoặc sai nội dung hiện ở Admin → Thanh toán để xử lý tay. Ảnh QR lấy từ VietQR Quick Link; VietQR khuyến nghị tạo template riêng cho dự án chính thức.
- Thanh toán và thuế: tiền Premium là doanh thu của bạn; hãy dùng tài khoản phù hợp và hỏi kế toán về hóa đơn/thuế. Webhook Casso V2 (chữ ký) chưa được hỗ trợ.

## Mới ở bản V7
**Nâng cấp:** tải đè `public_html/`, chạy lại `install.php` (CSDL lên phiên bản 7), đặt cron mỗi 5 phút gọi `/cron?key=...`, rồi bật các công tắc mới ở Admin → Tính năng.
1. **Vận hành** - Admin → **Sức khỏe** (kiểm tra PHP, tiện ích, thư mục ghi được, cron, tác vụ nền, email, AI, thanh toán, sao lưu; nút "Chạy kiểm tra luồng tự động" chạy thử đăng ký → hỏi → trả lời → điểm → thanh toán trong một giao dịch rồi hoàn tác; "Gửi thư thử"; "Sao lưu ngay"; khối "Báo cáo gửi hỗ trợ"). **Sao lưu tự động** mỗi ngày (nén .gz trong `app/backups`, giữ N bản, tải về từ trang Sức khỏe).
2. **Chi phí AI** - Admin → AI: nhập giá token (USD/1 triệu), giới hạn lượt/tháng và ngân sách tháng cho từng AI. Admin → **Chi phí AI**: ngân sách ngày/tháng chung, hành động khi chạm trần (chỉ dùng AI dự phòng hoặc dừng), trần lượt/ngày theo tính năng, thống kê theo AI/tính năng/thành viên. Chi phí là **ước tính**. **Chống lạm dụng chat**: đếm theo IP + thiết bị, giãn cách 2 giây, tối đa 12 tin/giờ cho khách, chặn tin trùng lặp, và (nếu đã cấu hình Turnstile) khách phải xác minh trước khi chat.
3. **Nội dung** - **Nhu cầu nội dung** (`/ctv/nhu-cau`): câu hỏi gửi trợ lý/tìm kiếm mà site chưa có nội dung; CTV nhận viết hoặc bấm "Soạn nháp bằng AI" (bản nháp có dùng nguồn trên site, **phải kiểm chứng trước khi đăng**). **Quy tắc AI theo lĩnh vực** (Admin → Hệ thống → Chuyên mục) áp dụng cho chat, AI trả lời, soạn bài; lĩnh vực nhạy cảm tự thêm cảnh báo. **Chia doanh thu** tự cộng doanh thu Premium đã thanh toán trong tháng + doanh thu khác nhập tay.
4. **Tăng trưởng** - **Ảnh chia sẻ** 1200x630 riêng cho từng câu hỏi/bài viết (cần PHP GD + FreeType; không có thì dùng ảnh mặc định; phông DejaVu kèm theo), thẻ Open Graph/Twitter, nút chia sẻ. **Bản tin email hằng tuần** (đăng ký 2 bước, hủy 1 chạm, gửi dần qua hàng đợi, tự gửi sáng thứ Hai khi bật; Admin → Bản tin). **Trang chuyên mục** có giới thiệu, bài nổi bật, câu hỏi cần trả lời, CTV phụ trách. **Hỏi bằng ảnh** (mặc định TẮT): bật tính năng + đánh dấu "hỗ trợ ảnh" cho AI phù hợp ở Admin → AI; chỉ thành viên đăng nhập, giới hạn lượt/ngày.
5. **CTV & pháp lý** - **Danh bạ chuyên gia** (`/chuyen-gia`) và **huy hiệu chuyên gia đã xác minh** (admin đặt danh hiệu ở trang Thành viên). **Điều khoản CTV** có phiên bản, ghi nhận thời điểm/IP đồng ý, buộc CTV đồng ý lại khi bạn tăng phiên bản (Admin → Điều khoản; **văn bản mặc định chỉ là bản mẫu, cần luật sư rà soát**). **Bảng kê thu nhập** cho từng CTV (`/ctv/thu-nhap`, CSV, in) và bảng kê toàn bộ CTV theo tháng cho admin (`/admin/xuat-ctv?m=YYYY-MM`). **Xác thực hai lớp (TOTP)** cho mọi tài khoản + tùy chọn **bắt buộc cho admin/CTV**; có mã khôi phục dùng một lần. Mã QR 2FA tạo ngay trên trình duyệt bằng thư viện qrcodejs từ cdnjs (khóa không gửi cho bên thứ ba); luôn có khóa nhập thủ công. **Tải/xóa dữ liệu cá nhân** (xóa = ẩn danh hóa, giữ nội dung đã đăng dưới tên ẩn danh) và ô đồng ý Điều khoản/Chính sách bảo mật khi đăng ký.

Lưu ý: bản tin email và thu thập dữ liệu có quy định pháp lý riêng; hãy hỏi tư vấn. Chưa thử trên máy chủ thật.


## Mới ở bản V7 (nhóm 1-5)
**Chạy lại `install.php`** (CSDL lên phiên bản 7). Thêm cột chi phí cho nhật ký AI, bảng nhu cầu nội dung, đăng ký bản tin, ghi nhận đồng ý điều khoản, cột 2FA/chuyên gia.

1. **Ổn định & vận hành** - Admin → 🩺 Sức khỏe: kiểm tra PHP/tiện ích/thư mục ghi/cron/email/AI/thanh toán/sao lưu; **"Chạy kiểm tra luồng tự động"** chạy thử đăng ký → hỏi → trả lời → bình chọn → điểm → thanh toán (đơn → webhook → kích hoạt, chống trùng)... trong một giao dịch rồi **hoàn tác** (không gọi AI/email thật); gửi thư thử; báo cáo gửi hỗ trợ. **Sao lưu tự động** hằng ngày (cần cron; nén .sql.gz trong `app/backups`, giữ N bản, tải/xóa ngay trong trang). *Tải bản sao lưu về máy định kỳ.*
2. **Chi phí AI** - Admin → 💸 Chi phí AI: ghi nhận token và chi phí ước tính (nhập giá USD/1 triệu token cho từng AI ở Admin → AI); đặt ngân sách ngày/tháng, trần lượt/ngày theo tính năng (chat, trả lời, kiểm duyệt, tóm tắt, soạn bài, đố vui), hạn mức/ngân sách tháng cho từng AI; chạm ngân sách thì chỉ dùng AI dự phòng (Puter) hoặc dừng. **Chống lạm dụng chat**: giới hạn tốc độ (2 giây/tin), 12 tin/giờ cho khách, đếm theo IP **và thiết bị** (cookie), chặn tin trùng lặp, yêu cầu Turnstile một lần cho khách (nếu đã cấu hình Turnstile).
3. **Nội dung** - 📌 *Nhu cầu nội dung*: câu hỏi gửi trợ lý/tìm kiếm mà site chưa có nội dung được gom lại theo số lượt hỏi, CTV "nhận viết" (`/ctv/nhu-cau`); 🤖 *Soạn bản nháp bằng AI* (dùng nguồn trên site để tránh trùng, kèm quy tắc lĩnh vực); **quy tắc/tính cách AI riêng cho từng lĩnh vực** + mô tả dài SEO (Admin → Hệ thống → Chuyên mục); doanh thu chia CTV **tự cộng doanh thu Premium** đã thanh toán trong tháng (Admin → Chia doanh thu CTV; vẫn nhập thêm doanh thu quảng cáo/tiếp thị).
4. **Tăng trưởng** - **Ảnh xem trước (Open Graph)** riêng cho từng câu hỏi/bài viết, nút chia sẻ (Facebook, X, sao chép, chia sẻ gốc của điện thoại); **bản tin email hằng tuần** (đăng ký 2 bước, hủy một chạm, gửi dần, thứ Hai sáng khi bật tính năng và có cron; Admin → ✉️ Bản tin); **trang đích chuyên mục** (mô tả dài, bài nổi bật, câu hỏi cần trả lời, CTV phụ trách); **hỏi trợ lý bằng ảnh** (tính năng `chat_image`, tắt mặc định; đánh dấu "hỗ trợ đọc ảnh" cho AI tương ứng ở Admin → AI; chỉ thành viên đăng nhập, 10 ảnh/ngày, 40 với Premium).
5. **CTV & pháp lý** - hồ sơ CTV công khai và **chuyên gia được xác minh** (admin gán danh hiệu ở Admin → Thành viên) + danh bạ `/chuyen-gia`; **điều khoản CTV** có phiên bản, lưu thời điểm + IP khi đồng ý, đổi điều khoản quan trọng thì CTV phải đồng ý lại (Admin → 📜 Điều khoản); đăng ký thành viên phải tích đồng ý Điều khoản/Bảo mật; **bảng kê thu nhập CTV** (xem/CSV/in) và bảng kê toàn bộ CTV theo tháng cho admin (`/admin/xuat-ctv?m=YYYY-MM`); **2FA (TOTP)** cho mọi thành viên, có thể bắt buộc cho admin/CTV (tính năng `enforce_2fa`), có mã khôi phục; **tải dữ liệu cá nhân (JSON) và xóa/ẩn danh tài khoản** ở Cài đặt.

Lưu ý: văn bản điều khoản mặc định chỉ là bản mẫu, hãy nhờ luật sư rà soát; email bản tin/quảng cáo cần tuân thủ quy định hiện hành; dữ liệu cá nhân (điểm danh, hội thoại, thanh toán) cần được nêu trong Chính sách bảo mật. Mã QR 2FA dùng thư viện qrcodejs tải từ cdnjs (khóa không rời trình duyệt); luôn có khóa nhập thủ công.

## Gỡ lỗi
- **Sau mỗi lần cập nhật mã, chạy lại `install.php` một lần** (hoặc Admin → Hệ thống → Cập nhật cơ sở dữ liệu): trình này cũng thống nhất collation các bảng (sửa lỗi "Illegal mix of collations").
- Nhật ký lỗi có nút "Xóa nhật ký"; hệ thống tự kết nối lại MySQL nếu bị ngắt ("server has gone away").
- Admin → Hệ thống → **Nhật ký lỗi PHP** (hoặc file `app/logs/error.log`), nút **Cập nhật cơ sở dữ liệu**, **Kiểm tra các AI**.
- Nguyên nhân lỗi bản trước: cột `sensitive` trùng **từ khóa dành riêng của MySQL**, làm file SQL V4 thất bại; V5 dùng `is_sensitive`.

## Lưu ý
- Chưa thể chạy thử PHP trong môi trường phát triển; hãy thử trên subdomain trước.
- Chương trình cộng tác viên và Premium liên quan thu nhập/thuế: cần hợp đồng/thỏa thuận và tư vấn kế toán. Puter, Claude, OpenAI... là dịch vụ bên thứ ba: cập nhật Chính sách bảo mật.
